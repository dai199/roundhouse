require_relative "test_helper"
require_relative "fixtures/articles"
require_relative "fixtures/comments"
require_relative "fixtures/articles"
require_relative "fixtures/comments"

class CommentTest < TestBase
#<SPINEL_SOURCE>app/test/models/comment_test.rb:5
  def test_creates_a_comment_on_an_article
    comment = CommentsFixtures.one
#<SPINEL_SOURCE>app/test/models/comment_test.rb:6
    raise "refute_nil failed" if comment.id.nil?
#<SPINEL_SOURCE>app/test/models/comment_test.rb:7
    raise "assert_equal failed" if ArticlesFixtures.one.id != comment.article_id
  end

#<SPINEL_SOURCE>app/test/models/comment_test.rb:11
  def test_belongs_to_article_association
    article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/models/comment_test.rb:12
    comment = Comment.create({ commenter: "Commenter", body: "Comment body text.", article: article })
#<SPINEL_SOURCE>app/test/models/comment_test.rb:13
    raise "assert_equal failed" if article.id != comment.article_id
  end

#<SPINEL_SOURCE>app/test/models/comment_test.rb:17
  def test_requires_commenter
    article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/models/comment_test.rb:18
    comment = Comment.new({ body: "Comment without commenter", article: article })
#<SPINEL_SOURCE>app/test/models/comment_test.rb:19
    raise "refute failed" if comment.save
  end

#<SPINEL_SOURCE>app/test/models/comment_test.rb:23
  def test_requires_body
    article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/models/comment_test.rb:24
    comment = Comment.new({ commenter: "Someone", article: article })
#<SPINEL_SOURCE>app/test/models/comment_test.rb:25
    raise "refute failed" if comment.save
  end

#<SPINEL_SOURCE>app/test/models/comment_test.rb:29
  def test_requires_valid_article
    comment = Comment.new({ commenter: "Test", body: "A test comment.", article_id: 999999 })
#<SPINEL_SOURCE>app/test/models/comment_test.rb:30
    raise "refute failed" if comment.save
  end
end

# Spinel AOT autorun shim — see emit/ruby.rs::render_autorun_shim.
class CommentTest
  def __txn_test_creates_a_comment_on_an_article
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_creates_a_comment_on_an_article
      end
    else
      test_creates_a_comment_on_an_article
    end
  end
  def __txn_test_belongs_to_article_association
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_belongs_to_article_association
      end
    else
      test_belongs_to_article_association
    end
  end
  def __txn_test_requires_commenter
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_requires_commenter
      end
    else
      test_requires_commenter
    end
  end
  def __txn_test_requires_body
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_requires_body
      end
    else
      test_requires_body
    end
  end
  def __txn_test_requires_valid_article
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_requires_valid_article
      end
    else
      test_requires_valid_article
    end
  end
end
__failed = 0
__skipped = 0
__t = CommentTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_creates_a_comment_on_an_article
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentTest#test_creates_a_comment_on_an_article: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentTest#test_creates_a_comment_on_an_article: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentTest#test_creates_a_comment_on_an_article: " + __e.message
  end
end
__t = CommentTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_belongs_to_article_association
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentTest#test_belongs_to_article_association: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentTest#test_belongs_to_article_association: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentTest#test_belongs_to_article_association: " + __e.message
  end
end
__t = CommentTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_requires_commenter
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentTest#test_requires_commenter: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentTest#test_requires_commenter: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentTest#test_requires_commenter: " + __e.message
  end
end
__t = CommentTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_requires_body
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentTest#test_requires_body: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentTest#test_requires_body: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentTest#test_requires_body: " + __e.message
  end
end
__t = CommentTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_requires_valid_article
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentTest#test_requires_valid_article: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentTest#test_requires_valid_article: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentTest#test_requires_valid_article: " + __e.message
  end
end
if __failed > 0
  raise "CommentTest: " + __failed.to_s + " of 5 tests failed"
end
if __skipped > 0
  puts "CommentTest: " + __skipped.to_s + " tests skipped"
end
puts "CommentTest: " + (5 - __skipped).to_s + " tests passed"
