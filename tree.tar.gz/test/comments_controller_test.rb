require_relative "test_helper"
require_relative "fixtures/articles"
require_relative "fixtures/comments"
require_relative "../app/route_helpers"
require_relative "fixtures/articles"
require_relative "fixtures/comments"

class CommentsControllerTest < ActionDispatch::IntegrationTest
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:5
  def test_should_create_comment
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:6
    @comment = CommentsFixtures.one
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:10
    __diff_before = Comment.count
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:11
    post(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_comments_path(@article.id)), params: { comment: { commenter: "Test", body: "A test comment." } })
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:10
    __diff_after = Comment.count
    raise "Comment.count didn't change by 1" if __diff_after - __diff_before != 1
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:13
    assert_redirected_to(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)))
  end

#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:5
  def test_should_not_create_comment_with_invalid_params
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:6
    @comment = CommentsFixtures.one
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:17
    __diff_before = Comment.count
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:18
    post(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_comments_path(@article.id)), params: { comment: { commenter: "", body: "" } })
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:17
    __diff_after = Comment.count
    raise "Comment.count didn't change by 0" if __diff_after - __diff_before != 0
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:20
    assert_redirected_to(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)))
  end

#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:5
  def test_should_destroy_comment
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:6
    @comment = CommentsFixtures.one
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:24
    __diff_before = Comment.count
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:25
    delete(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_comment_path(@article.id, @comment.id)))
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:24
    __diff_after = Comment.count
    raise "Comment.count didn't change by -1" if __diff_after - __diff_before != -1
#<SPINEL_SOURCE>app/test/controllers/comments_controller_test.rb:27
    assert_redirected_to(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)))
  end
end

# Spinel AOT autorun shim — see emit/ruby.rs::render_autorun_shim.
class CommentsControllerTest
  def __txn_test_should_create_comment
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_create_comment
      end
    else
      test_should_create_comment
    end
  end
  def __txn_test_should_not_create_comment_with_invalid_params
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_not_create_comment_with_invalid_params
      end
    else
      test_should_not_create_comment_with_invalid_params
    end
  end
  def __txn_test_should_destroy_comment
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_destroy_comment
      end
    else
      test_should_destroy_comment
    end
  end
end
__failed = 0
__skipped = 0
__t = CommentsControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_create_comment
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentsControllerTest#test_should_create_comment: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentsControllerTest#test_should_create_comment: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentsControllerTest#test_should_create_comment: " + __e.message
  end
end
__t = CommentsControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_not_create_comment_with_invalid_params
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentsControllerTest#test_should_not_create_comment_with_invalid_params: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentsControllerTest#test_should_not_create_comment_with_invalid_params: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentsControllerTest#test_should_not_create_comment_with_invalid_params: " + __e.message
  end
end
__t = CommentsControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_destroy_comment
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP CommentsControllerTest#test_should_destroy_comment: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL CommentsControllerTest#test_should_destroy_comment: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL CommentsControllerTest#test_should_destroy_comment: " + __e.message
  end
end
if __failed > 0
  raise "CommentsControllerTest: " + __failed.to_s + " of 3 tests failed"
end
if __skipped > 0
  puts "CommentsControllerTest: " + __skipped.to_s + " tests skipped"
end
puts "CommentsControllerTest: " + (3 - __skipped).to_s + " tests passed"
