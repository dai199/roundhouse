require_relative "test_helper"
require_relative "fixtures/articles"
require_relative "fixtures/comments"
require_relative "../app/route_helpers"
require_relative "fixtures/articles"

class ArticlesControllerTest < ActionDispatch::IntegrationTest
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_get_index
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:9
    get(ActionView::ViewHelpers.url_for_path(RouteHelpers.articles_path))
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:10
    assert_response(:success)
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:11
    assert_select("h1", "Articles")
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:12
    assert_select("#articles") do assert_select("h2", minimum: 1) end
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_get_new
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:18
    get(ActionView::ViewHelpers.url_for_path(RouteHelpers.new_article_path))
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:19
    assert_response(:success)
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:20
    assert_select("form")
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_create_article
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:24
    __diff_before = Article.count
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:25
    post(ActionView::ViewHelpers.url_for_path(RouteHelpers.articles_path), params: { article: { body: "A sufficiently long body for validation.", title: "New Title" } })
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:24
    __diff_after = Article.count
    raise "Article.count didn't change by 1" if __diff_after - __diff_before != 1

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:28
    assert_redirected_to(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(Article.last.id)))
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:29
    raise "assert_equal failed" if "New Title" != Article.last.title
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_not_create_article_with_invalid_params
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:33
    __diff_before = Article.count
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:34
    post(ActionView::ViewHelpers.url_for_path(RouteHelpers.articles_path), params: { article: { title: "", body: "" } })
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:33
    __diff_after = Article.count
    raise "Article.count didn't change by 0" if __diff_after - __diff_before != 0

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:37
    assert_response(:unprocessable_entity)
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_show_article
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:41
    get(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)))
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:42
    assert_response(:success)
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:43
    assert_select("h1", @article.title)
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:44
    assert_select("h2", "Comments")
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:45
    assert_select("#comments .p-4", minimum: 1)
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_get_edit
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:49
    get(ActionView::ViewHelpers.url_for_path(RouteHelpers.edit_article_path(@article.id)))
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:50
    assert_response(:success)
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:51
    assert_select("form")
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_update_article
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:55
    patch(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)), params: { article: { body: @article.body, title: "Updated Title" } })
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:56
    assert_redirected_to(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)))
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:57
    @article.reload
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:58
    raise "assert_equal failed" if "Updated Title" != @article.title
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_not_update_article_with_invalid_params
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:62
    patch(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)), params: { article: { title: "", body: "" } })
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:63
    assert_response(:unprocessable_entity)
  end

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:5
  def test_should_destroy_article
    @article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:67
    __diff_before = Article.count
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:68
    delete(ActionView::ViewHelpers.url_for_path(RouteHelpers.article_path(@article.id)))
#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:67
    __diff_after = Article.count
    raise "Article.count didn't change by -1" if __diff_after - __diff_before != -1

#<SPINEL_SOURCE>app/test/controllers/articles_controller_test.rb:71
    assert_redirected_to(ActionView::ViewHelpers.url_for_path(RouteHelpers.articles_path))
  end
end

# Spinel AOT autorun shim — see emit/ruby.rs::render_autorun_shim.
class ArticlesControllerTest
  def __txn_test_should_get_index
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_get_index
      end
    else
      test_should_get_index
    end
  end
  def __txn_test_should_get_new
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_get_new
      end
    else
      test_should_get_new
    end
  end
  def __txn_test_should_create_article
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_create_article
      end
    else
      test_should_create_article
    end
  end
  def __txn_test_should_not_create_article_with_invalid_params
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_not_create_article_with_invalid_params
      end
    else
      test_should_not_create_article_with_invalid_params
    end
  end
  def __txn_test_should_show_article
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_show_article
      end
    else
      test_should_show_article
    end
  end
  def __txn_test_should_get_edit
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_get_edit
      end
    else
      test_should_get_edit
    end
  end
  def __txn_test_should_update_article
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_update_article
      end
    else
      test_should_update_article
    end
  end
  def __txn_test_should_not_update_article_with_invalid_params
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_not_update_article_with_invalid_params
      end
    else
      test_should_not_update_article_with_invalid_params
    end
  end
  def __txn_test_should_destroy_article
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_should_destroy_article
      end
    else
      test_should_destroy_article
    end
  end
end
__failed = 0
__skipped = 0
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_get_index
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_get_index: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_get_index: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_get_index: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_get_new
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_get_new: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_get_new: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_get_new: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_create_article
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_create_article: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_create_article: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_create_article: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_not_create_article_with_invalid_params
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_not_create_article_with_invalid_params: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_not_create_article_with_invalid_params: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_not_create_article_with_invalid_params: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_show_article
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_show_article: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_show_article: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_show_article: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_get_edit
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_get_edit: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_get_edit: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_get_edit: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_update_article
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_update_article: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_update_article: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_update_article: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_not_update_article_with_invalid_params
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_not_update_article_with_invalid_params: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_not_update_article_with_invalid_params: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_not_update_article_with_invalid_params: " + __e.message
  end
end
__t = ArticlesControllerTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_should_destroy_article
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticlesControllerTest#test_should_destroy_article: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_destroy_article: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticlesControllerTest#test_should_destroy_article: " + __e.message
  end
end
if __failed > 0
  raise "ArticlesControllerTest: " + __failed.to_s + " of 9 tests failed"
end
if __skipped > 0
  puts "ArticlesControllerTest: " + __skipped.to_s + " tests skipped"
end
puts "ArticlesControllerTest: " + (9 - __skipped).to_s + " tests passed"
