module ArticlesFixtures
  def self.one
    @__fx_one = Article.find(1) if @__fx_one.nil?
    @__fx_one
  end

  def self.two
    @__fx_two = Article.find(2) if @__fx_two.nil?
    @__fx_two
  end

  def self._fixtures_load!
    @__fx_one = nil
    @__fx_two = nil
    instance = Article.new
    instance.id = 1
    instance.title = "Getting Started with Rails"
    instance.body = "Rails is a web application framework running on the Ruby programming language."
    instance._insert_row
    instance = Article.new
    instance.id = 2
    instance.title = "Understanding MVC Architecture"
    instance.body = "MVC stands for Model-View-Controller. Models handle data and business logic."
    instance._insert_row
  end
end
