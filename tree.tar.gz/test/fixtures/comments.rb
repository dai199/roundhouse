module CommentsFixtures
  def self.one
    @__fx_one = Comment.find(1) if @__fx_one.nil?
    @__fx_one
  end

  def self.two
    @__fx_two = Comment.find(2) if @__fx_two.nil?
    @__fx_two
  end

  def self._fixtures_load!
    @__fx_one = nil
    @__fx_two = nil
    instance = Comment.new
    instance.id = 1
    instance.article_id = 1
    instance.commenter = "Alice"
    instance.body = "Great introduction! Rails really does make development faster."
    instance._insert_row
    instance = Comment.new
    instance.id = 2
    instance.article_id = 2
    instance.commenter = "Bob"
    instance.body = "This pattern really helps keep code organized!"
    instance._insert_row
  end
end
