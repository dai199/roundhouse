require_relative "test_helper"
require_relative "fixtures/articles"
require_relative "fixtures/comments"
require_relative "fixtures/articles"

class ArticleTest < TestBase
#<SPINEL_SOURCE>app/test/models/article_test.rb:5
  def test_creates_an_article_with_valid_attributes
    article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/models/article_test.rb:6
    raise "refute_nil failed" if article.id.nil?
#<SPINEL_SOURCE>app/test/models/article_test.rb:7
    raise "assert_equal failed" if "Getting Started with Rails" != article.title
  end

#<SPINEL_SOURCE>app/test/models/article_test.rb:11
  def test_validates_title_presence
    article = Article.new({ title: "", body: "Valid body content here." })
#<SPINEL_SOURCE>app/test/models/article_test.rb:12
    raise "refute failed" if article.save
  end

#<SPINEL_SOURCE>app/test/models/article_test.rb:16
  def test_validates_body_minimum_length
    article = Article.new({ title: "Valid Title", body: "Short" })
#<SPINEL_SOURCE>app/test/models/article_test.rb:17
    raise "refute failed" if article.save
  end

#<SPINEL_SOURCE>app/test/models/article_test.rb:21
  def test_destroys_comments_when_article_is_destroyed
    article = ArticlesFixtures.one
#<SPINEL_SOURCE>app/test/models/article_test.rb:22
    __diff_before = Comment.count
#<SPINEL_SOURCE>app/test/models/article_test.rb:23
    article.destroy
#<SPINEL_SOURCE>app/test/models/article_test.rb:22
    __diff_after = Comment.count
    raise "Comment.count didn't change by -1" if __diff_after - __diff_before != -1
  end
end

# Spinel AOT autorun shim — see emit/ruby.rs::render_autorun_shim.
class ArticleTest
  def __txn_test_creates_an_article_with_valid_attributes
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_creates_an_article_with_valid_attributes
      end
    else
      test_creates_an_article_with_valid_attributes
    end
  end
  def __txn_test_validates_title_presence
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_validates_title_presence
      end
    else
      test_validates_title_presence
    end
  end
  def __txn_test_validates_body_minimum_length
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_validates_body_minimum_length
      end
    else
      test_validates_body_minimum_length
    end
  end
  def __txn_test_destroys_comments_when_article_is_destroyed
    if self.class.use_transactional_tests
      ActiveRecord::Base.transaction(joinable: false) do
        test_destroys_comments_when_article_is_destroyed
      end
    else
      test_destroys_comments_when_article_is_destroyed
    end
  end
end
__failed = 0
__skipped = 0
__t = ArticleTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_creates_an_article_with_valid_attributes
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticleTest#test_creates_an_article_with_valid_attributes: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_creates_an_article_with_valid_attributes: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_creates_an_article_with_valid_attributes: " + __e.message
  end
end
__t = ArticleTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_validates_title_presence
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticleTest#test_validates_title_presence: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_validates_title_presence: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_validates_title_presence: " + __e.message
  end
end
__t = ArticleTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_validates_body_minimum_length
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticleTest#test_validates_body_minimum_length: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_validates_body_minimum_length: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_validates_body_minimum_length: " + __e.message
  end
end
__t = ArticleTest.new
__ok = true
begin
  FixtureLoader.with_foreign_keys_deferred do
    Article._adapter_truncate
    Comment._adapter_truncate
    ArticlesFixtures._fixtures_load!
    CommentsFixtures._fixtures_load!
  end
  __t.setup
  __t.__txn_test_destroys_comments_when_article_is_destroyed
rescue Exception => __e
  if __e.class.name == "TestSkipped"
    __ok = false
    __skipped = __skipped + 1
    puts "SKIP ArticleTest#test_destroys_comments_when_article_is_destroyed: " + __e.message
  else
    __ok = false
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_destroys_comments_when_article_is_destroyed: " + __e.message
  end
end
begin
  __t.teardown
rescue Exception => __e
  if __ok
    __failed = __failed + 1
    puts "FAIL ArticleTest#test_destroys_comments_when_article_is_destroyed: " + __e.message
  end
end
if __failed > 0
  raise "ArticleTest: " + __failed.to_s + " of 4 tests failed"
end
if __skipped > 0
  puts "ArticleTest: " + __skipped.to_s + " tests skipped"
end
puts "ArticleTest: " + (4 - __skipped).to_s + " tests passed"
