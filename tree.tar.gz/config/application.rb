module Rails
  class Application
    def action_controller_escape_json_responses
      return false
    end

    def active_support_escape_html_entities_in_json
      true
    end

    def active_support_escape_js_separators_in_json
      return false
    end

    def public_file_server_headers
      env = Rails.env.to_s
      if env == "development"
        return { "cache-control" => "public, max-age=172800" } if Rails.root.join("tmp/caching-dev.txt").exist?
      end
      return { "cache-control" => "public, max-age=31556952" } if env == "production"
      return { "cache-control" => "public, max-age=3600" } if env == "test"
      return {}
    end

    def action_controller_perform_caching
      env = Rails.env.to_s
      if env == "development"
        if Rails.root.join("tmp/caching-dev.txt").exist?
          return true
        else
          return false
        end
      end
      return true if env == "production"
      return true
    end

    def active_job_queue_adapter
      env = Rails.env.to_s
      return :solid_queue.to_s if env == "production"
      return "async"
    end

    def session_cookie_key
      key = "_real_blog_session"
      key
    end

    def global_id_app
      "real-blog"
    end

    def config_filter_parameters
      ["passw", "email", "secret", "token", "_key", "crypt", "salt", "certificate", "otp", "ssn", "cvv", "cvc"]
    end

    def importmap_json
      "{\n  \"imports\": {\n    \"application\": \"/assets/application.js\",\n    \"@hotwired/turbo-rails\": \"/assets/turbo.min.js\",\n    \"@hotwired/stimulus\": \"/assets/stimulus.min.js\",\n    \"@hotwired/stimulus-loading\": \"/assets/stimulus-loading.js\",\n    \"controllers/application\": \"/assets/controllers/application.js\",\n    \"controllers/hello_controller\": \"/assets/controllers/hello_controller.js\",\n    \"controllers\": \"/assets/controllers/index.js\"\n  }\n}"
    end

    def propshaft_asset_path(source)
      case source
      when "app.css"
        "/assets/tailwind-ff8c430f.css"
      when "application.css"
        "/assets/application-8b441ae0.css"
      when "tailwind.css"
        "/assets/tailwind-ff8c430f.css"
      else
        "/assets/#{source}"
      end
    end
  end
end
