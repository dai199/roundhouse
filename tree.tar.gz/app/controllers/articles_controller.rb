require_relative "application_controller"
require_relative "../route_helpers"
require_relative "../views"

class ArticlesController < ApplicationController
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:6
  def process_action(action_name)
    @params = Params.wrap(@params, request, "article", true, ["id", "title", "body", "created_at", "updated_at"], [])
    self.verify_authenticity_token
    return if self.performed?
    case action_name
    when :index
      self.index
    when :show
      self.show
    when :new
      self.new_action
    when :edit
      self.edit
    when :create
      self.create
    when :update
      self.update
    when :destroy
      self.destroy
    end
  end

  def index
    stmt = Db.prepare("SELECT id, title, body, created_at, updated_at FROM articles ORDER BY created_at DESC")
    begin
      results = []
      while Db.step?(stmt)
        results << Article.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    __comments_ids = results.map { |a| a.id }
    __comments_stmt = Db.prepare("SELECT id, article_id, commenter, body, created_at, updated_at FROM comments WHERE article_id IN (" + Db.escape_int_list(__comments_ids) + ") ORDER BY article_id, id")
    begin
      __comments_loaded = []
      while Db.step?(__comments_stmt)
        __comments_loaded << Comment.from_stmt(__comments_stmt)
      end
    ensure
      Db.finalize(__comments_stmt)
    end
    __comments_fks = __comments_loaded.map { |r| r.article_id }
    results.each { |a| __comments_group = []
    __comments_j = ActiveRecord.lower_bound(__comments_fks, a.id)
    __comments_stop = ActiveRecord.lower_bound(__comments_fks, a.id + 1)
    while __comments_j < __comments_stop
      __comments_group << __comments_loaded[__comments_j]
      __comments_j = __comments_j + 1
    end
    a._preload_comments(__comments_group) }
    @articles = results
    if self.request_format == :json
      render(Views::Articles.index_json(@articles), content_type: "application/json")
    else
      render(Views::Layouts.application(Views::Articles.index(@articles, @flash[:notice], @flash[:alert]), @flash[:notice], @flash[:alert]))
    end
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:63
  def show
    @article = Article.find(@params.fetch("id", "0").to_s.to_i)
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:10
    if self.request_format == :json
      render(Views::Articles.show_json(@article), content_type: "application/json")
    else
      render(Views::Layouts.application(Views::Articles.show(@article, @flash[:notice], @flash[:alert]), @flash[:notice], @flash[:alert]))
    end
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:15
  def new_action
    @article = Article.new
    render(Views::Layouts.application(Views::Articles._new(@article, @flash[:notice], @flash[:alert]), @flash[:notice], @flash[:alert]))
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:63
  def edit
    @article = Article.find(@params.fetch("id", "0").to_s.to_i)
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:19
    render(Views::Layouts.application(Views::Articles.edit(@article, @flash[:notice], @flash[:alert]), @flash[:notice], @flash[:alert]))
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:24
  def create
    @article = Article.from_params(self.article_params)
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:27
    if @article.save
      if self.request_format == :json
        render(Views::Articles.show_json(@article), status: :created, location: RouteHelpers.article_path(@article.id), content_type: "application/json")
      else
        redirect_to(RouteHelpers.article_path(@article.id), notice: "Article was successfully created.")
      end
    else
      render(Views::Layouts.application(Views::Articles._new(@article, @flash[:notice], @flash[:alert]), @flash[:notice], @flash[:alert]), status: :unprocessable_content)
    end
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:63
  def update
    @article = Article.find(@params.fetch("id", "0").to_s.to_i)
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:40
    if @article.update_from_article_params(self.article_params)
      if self.request_format == :json
        render(Views::Articles.show_json(@article), status: :ok, location: RouteHelpers.article_path(@article.id), content_type: "application/json")
      else
        redirect_to(RouteHelpers.article_path(@article.id), notice: "Article was successfully updated.", status: :see_other)
      end
    else
      render(Views::Layouts.application(Views::Articles.edit(@article, @flash[:notice], @flash[:alert]), @flash[:notice], @flash[:alert]), status: :unprocessable_content)
    end
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:63
  def destroy
    @article = Article.find(@params.fetch("id", "0").to_s.to_i)
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:52
    @article.destroy
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:55
    if self.request_format == :json
      head(:no_content, content_type: "application/json")
    else
      redirect_to(RouteHelpers.articles_path, notice: "Article was successfully destroyed.", status: :see_other)
    end
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:68
  def article_params
    ArticleParams.from_raw(Params.expect_present(@params, "article", ["title", "body"], [], [], []))
  end

#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:6
  def controller_name
    "articles"
  end

  def controller_path
    "articles"
  end
end
