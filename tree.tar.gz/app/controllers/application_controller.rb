require_relative "../../runtime/action_controller"

class ApplicationController < ActionController::Base
#<SPINEL_SOURCE>app/app/controllers/application_controller.rb:1
  def controller_name
    "application"
  end

  def controller_path
    "application"
  end
end
