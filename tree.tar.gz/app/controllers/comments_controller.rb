require_relative "application_controller"
require_relative "../route_helpers"

class CommentsController < ApplicationController
#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:5
  def process_action(action_name)
    @params = Params.wrap(@params, request, "comment", true, ["id", "article_id", "commenter", "body", "created_at", "updated_at"], [])
    self.verify_authenticity_token
    return if self.performed?
    case action_name
    when :create
      self.create
    when :destroy
      self.destroy
    end
  end

#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:22
  def create
    @article = Article.find(@params.fetch("article_id", "0").to_s.to_i)
#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:5
    rh_build_owner_0 = @article
    rh_build_record_0 = Comment.from_params(self.comment_params)
    rh_build_record_0.article_id = rh_build_owner_0.id
    @comment = rh_build_record_0
#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:6
    if @comment.save
      redirect_to(RouteHelpers.article_path(@article.id), notice: "Comment was successfully created.")
    else
      redirect_to(RouteHelpers.article_path(@article.id), alert: "Could not create comment.")
    end
  end

#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:22
  def destroy
    @article = Article.find(@params.fetch("article_id", "0").to_s.to_i)
#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:14
    @comment = Comment.find(@params.fetch("id", "0").to_s.to_i)
    if @comment.article_id != @article.id
      head(:not_found)
      return
    end
#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:15
    @comment.destroy
#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:16
    redirect_to(RouteHelpers.article_path(@article.id), notice: "Comment was successfully deleted.")
  end

#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:26
  def comment_params
    CommentParams.from_raw(Params.expect_present(@params, "comment", ["commenter", "body"], [], [], []))
  end

#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:5
  def controller_name
    "comments"
  end

  def controller_path
    "comments"
  end
end
