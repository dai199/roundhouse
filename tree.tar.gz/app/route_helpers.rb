module RouteHelpers
  def self.root_path
    "/"
  end

  def self.article_comments_path(article_id)
    if article_id.to_s.empty?
      raise ActionController::UrlGenerationError.missing_segments("comments", "create", ["article_id"], [if article_id.nil?
        nil
      else
        article_id.to_s
      end])
    end
    "/articles/#{article_id}/comments"
  end

  def self.article_comment_path(article_id, id)
    if article_id.to_s.empty? || id.to_s.empty?
      raise ActionController::UrlGenerationError.missing_segments("comments", "destroy", ["article_id", "id"], [if article_id.nil?
        nil
      else
        article_id.to_s
      end, if id.nil?
        nil
      else
        id.to_s
      end])
    end
    "/articles/#{article_id}/comments/#{id}"
  end

  def self.articles_path
    "/articles"
  end

  def self.new_article_path
    "/articles/new"
  end

  def self.article_path(id)
    if id.to_s.empty?
      raise ActionController::UrlGenerationError.missing_segments("articles", "show", ["id"], [if id.nil?
        nil
      else
        id.to_s
      end])
    end
    "/articles/#{id}"
  end

  def self.edit_article_path(id)
    if id.to_s.empty?
      raise ActionController::UrlGenerationError.missing_segments("articles", "edit", ["id"], [if id.nil?
        nil
      else
        id.to_s
      end])
    end
    "/articles/#{id}/edit"
  end

  def self.article_json_path(id)
    if id.to_s.empty?
      raise ActionController::UrlGenerationError.missing_segments("articles", "show", ["id"], [if id.nil?
        nil
      else
        id.to_s
      end])
    end
    "/articles/#{id}" + ".json"
  end
end
