require_relative "../../route_helpers"

module Views
  module Articles
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:1
    def self.show_into(io, article, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      ActionView::ViewHelpers.content_for_set(:title, "Showing article")
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:2
      io << "\n"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:8
      cf_head = String.new
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:9
      cf_head << "  "
      ActionView::ViewHelpers.content_for_set(:head, "<meta name=\"turbo-cache-control\" content=\"no-preview\">")
      cf_head << "\n  <meta name=\"article-id\" content=\""
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:10
      cf_head << ActionView::ViewHelpers.html_escape(article.id.to_s)
      cf_head << "\">\n"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:8
      ActionView::ViewHelpers.content_for_set(:head, cf_head)
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:12
      io << "\n<div class=\"md:w-2/3 w-full\">\n"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:14
      if ! (notice || "").empty?
        io << "    <p class=\"py-2 px-3 bg-green-50 mb-5 text-green-500 font-medium rounded-md inline-block\" id=\"notice\">"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:15
        io << ActionView::ViewHelpers.html_escape(notice.to_s)
        io << "</p>\n"
      end
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:17
      io << "\n  <h1 class=\"font-bold text-4xl\">"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:18
      io << ActionView::ViewHelpers.html_escape(article.title.to_s)
      io << "</h1>\n\n  <div class=\"my-4\">\n    <p class=\"text-gray-700\">"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:21
      io << ActionView::ViewHelpers.html_escape(article.body.to_s)
      io << "</p>\n  </div>\n\n  "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:24
      io << "<a class=\"#{"w-full sm:w-auto text-center rounded-md px-3.5 py-2.5 bg-gray-100 hover:bg-gray-50 inline-block font-medium"}\" href=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.edit_article_path(article.id))}\">#{"Edit this article"}</a>"
      io << "\n  "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:25
      io << "<a class=\"#{"w-full sm:w-auto text-center mt-2 sm:mt-0 sm:ml-2 rounded-md px-3.5 py-2.5 bg-gray-100 hover:bg-gray-50 inline-block font-medium"}\" href=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.articles_path)}\">#{"Back to articles"}</a>"
      io << "\n  "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:26
      io << "<form action=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.article_path(article.id))}\" method=\"post\" class=\"#{"sm:inline-block mt-2 sm:mt-0 sm:ml-2"}\">#{ActionView::ViewHelpers.method_override_input(:delete)}<button type=\"submit\" class=\"#{"w-full rounded-md px-3.5 py-2.5 text-white bg-red-600 hover:bg-red-500 font-medium cursor-pointer"}\" data-turbo-confirm=\"#{"Are you sure?"}\">#{"Destroy this article"}</button>#{ActionView::ViewHelpers.csrf_token_hidden_input}</form>"
      io << "\n</div>\n\n<hr class=\"my-8\">\n\n<h2 class=\"text-xl font-bold mb-4\">Comments</h2>\n\n"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:33
      io << ActionView::ViewHelpers.turbo_stream_from("article_#{article.id}_comments", "Turbo::StreamsChannel")
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:34
      io << "\n\n<div id=\"comments\" class=\"space-y-4 mb-8\">\n  "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:37
      __collection_started0 = ActiveSupport::Notifications.collection_start
      article.comments.each { |c| Views::Comments.comment_into(io, c, notice, alert) }
      ActiveSupport::Notifications.collection_finish("app/views/comments/_comment.html.erb", __collection_started0)
      io << "\n</div>\n\n<h3 class=\"text-lg font-semibold mb-2\">Add a Comment</h3>\n\n"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:42
      ActionView::Base.new.form_with
      form_record = Comment.new
      form_method = :post
      io << "<form action=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.article_comments_path(article.id))}\" accept-charset=\"UTF-8\" method=\"post\" class=\"#{"space-y-4"}\">"
      io << ActionView::ViewHelpers.method_override_input(form_method)
      io << ActionView::ViewHelpers.csrf_token_hidden_input
      io << "\n  <div>\n    "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:44
      rh_form_commenter_errors = form_record.error_messages_for("commenter").any?
      io << "<div class=\"field_with_errors\">" if rh_form_commenter_errors
      io << "<label for=\"comment_commenter\" class=\"#{"block font-medium"}\">Commenter</label>"
      io << "</div>" if rh_form_commenter_errors
      io << "\n    "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:45
      rh_form_commenter_errors = form_record.error_messages_for("commenter").any?
      io << "<div class=\"field_with_errors\">" if rh_form_commenter_errors
      io << "<input type=\"text\" name=\"comment[commenter]\" id=\"comment_commenter\"#{ActionView::ViewHelpers.optional_value_attr(form_record[:commenter])} class=\"#{"block w-full border rounded p-2"}\">"
      io << "</div>" if rh_form_commenter_errors
      io << "\n  </div>\n  <div>\n    "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:48
      rh_form_body_errors = form_record.error_messages_for("body").any?
      io << "<div class=\"field_with_errors\">" if rh_form_body_errors
      io << "<label for=\"comment_body\" class=\"#{"block font-medium"}\">Body</label>"
      io << "</div>" if rh_form_body_errors
      io << "\n    "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:49
      rh_form_body_errors = form_record.error_messages_for("body").any?
      io << "<div class=\"field_with_errors\">" if rh_form_body_errors
      io << "<textarea name=\"comment[body]\" id=\"comment_body\" rows=\"#{ActionView::ViewHelpers.html_escape(3.to_s)}\" class=\"#{"block w-full border rounded p-2"}\">\n#{ActionView::ViewHelpers.escape_or_empty(form_record[:body])}</textarea>"
      io << "</div>" if rh_form_body_errors
      io << "\n  </div>\n  "
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:51
      io << "<input type=\"submit\" name=\"commit\" value=\"#{"Add Comment"}\" data-disable-with=\"#{"Add Comment"}\" class=\"#{"bg-blue-600 text-white px-4 py-2 rounded"}\">"
      io << "\n"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:42
      io << "</form>"
#<SPINEL_SOURCE>app/app/views/articles/show.html.erb:1
      ActiveSupport::Notifications.render_finish("render_template.action_view", "app/views/articles/show.html.erb", __render_started)
      nil
    end

    def self.show(article, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Articles_show)
      Views::Articles.show_into(io, article, notice, alert)
      ViewBufferCap.store(:cap_Views_Articles_show, io.bytesize)
      io
    end
  end
end
