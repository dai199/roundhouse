require_relative "../../route_helpers"

module Views
  module Articles
#<SPINEL_SOURCE>app/app/views/articles/edit.html.erb:1
    def self.edit_into(io, article, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      ActionView::ViewHelpers.content_for_set(:title, "Editing article")
#<SPINEL_SOURCE>app/app/views/articles/edit.html.erb:2
      io << "\n<div class=\"md:w-2/3 w-full\">\n  <h1 class=\"font-bold text-4xl\">Editing article</h1>\n\n  "
#<SPINEL_SOURCE>app/app/views/articles/edit.html.erb:6
      Views::Articles.form_into(io, article, notice, alert)
      io << "\n\n  "
#<SPINEL_SOURCE>app/app/views/articles/edit.html.erb:8
      io << "<a class=\"#{"w-full sm:w-auto text-center mt-2 sm:mt-0 sm:ml-2 rounded-md px-3.5 py-2.5 bg-gray-100 hover:bg-gray-50 inline-block font-medium"}\" href=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.article_path(article.id))}\">#{"Show this article"}</a>"
      io << "\n  "
#<SPINEL_SOURCE>app/app/views/articles/edit.html.erb:9
      io << "<a class=\"#{"w-full sm:w-auto text-center mt-2 sm:mt-0 sm:ml-2 rounded-md px-3.5 py-2.5 bg-gray-100 hover:bg-gray-50 inline-block font-medium"}\" href=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.articles_path)}\">#{"Back to articles"}</a>"
      io << "\n</div>\n"
#<SPINEL_SOURCE>app/app/views/articles/edit.html.erb:1
      ActiveSupport::Notifications.render_finish("render_template.action_view", "app/views/articles/edit.html.erb", __render_started)
      nil
    end

    def self.edit(article, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Articles_edit)
      Views::Articles.edit_into(io, article, notice, alert)
      ViewBufferCap.store(:cap_Views_Articles_edit, io.bytesize)
      io
    end
  end
end
