require_relative "../../route_helpers"

module Views
  module Articles
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:1
    def self.index_into(io, articles, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << ActionView::ViewHelpers.turbo_stream_from("articles", "Turbo::StreamsChannel")
      io << "\n\n"
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:3
      ActionView::ViewHelpers.content_for_set(:title, "Articles")
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:4
      io << "\n"
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:12
      ActionView::ViewHelpers.content_for_set(:head, "<meta name=\"turbo-cache-control\" content=\"no-cache\">")
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:13
      io << "\n<div class=\"w-full\">\n"
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:15
      if ! (notice || "").empty?
        io << "    <p class=\"py-2 px-3 bg-green-50 mb-5 text-green-500 font-medium rounded-md inline-block\" id=\"notice\">"
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:16
        io << ActionView::ViewHelpers.html_escape(notice.to_s)
        io << "</p>\n"
      end
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:18
      io << "\n  <div class=\"flex justify-between items-center\">\n    <h1 class=\"font-bold text-4xl\">Articles</h1>\n    "
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:21
      io << "<a class=\"#{"rounded-md px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white block font-medium"}\" href=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.new_article_path)}\">#{"New article"}</a>"
      io << "\n  </div>\n\n  <div id=\"articles\" class=\"min-w-full divide-y divide-gray-200 space-y-5\">\n"
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:25
      if ! articles.empty?
        io << "      "
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:26
        __collection_started0 = ActiveSupport::Notifications.collection_start
        articles.each { |a| Views::Articles.article_into(io, a, notice, alert) }
        ActiveSupport::Notifications.collection_finish("app/views/articles/_article.html.erb", __collection_started0)
        io << "\n"
      else
        io << "      <p class=\"text-center my-10\">No articles found.</p>\n"
      end
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:30
      io << "  </div>\n</div>\n"
#<SPINEL_SOURCE>app/app/views/articles/index.html.erb:1
      ActiveSupport::Notifications.render_finish("render_template.action_view", "app/views/articles/index.html.erb", __render_started)
      nil
    end

    def self.index(articles, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Articles_index)
      Views::Articles.index_into(io, articles, notice, alert)
      ViewBufferCap.store(:cap_Views_Articles_index, io.bytesize)
      io
    end
  end
end
