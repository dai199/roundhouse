require_relative "../../route_helpers"

module Views
  module Articles
#<SPINEL_SOURCE>app/app/views/articles/new.html.erb:1
    def self._new_into(io, article, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      ActionView::ViewHelpers.content_for_set(:title, "New article")
#<SPINEL_SOURCE>app/app/views/articles/new.html.erb:2
      io << "\n<div class=\"md:w-2/3 w-full\">\n  <h1 class=\"font-bold text-4xl\">New article</h1>\n\n  "
#<SPINEL_SOURCE>app/app/views/articles/new.html.erb:6
      Views::Articles.form_into(io, article, notice, alert)
      io << "\n\n  "
#<SPINEL_SOURCE>app/app/views/articles/new.html.erb:8
      io << "<a class=\"#{"w-full sm:w-auto text-center mt-2 sm:mt-0 sm:ml-2 rounded-md px-3.5 py-2.5 bg-gray-100 hover:bg-gray-50 inline-block font-medium"}\" href=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.articles_path)}\">#{"Back to articles"}</a>"
      io << "\n</div>\n"
#<SPINEL_SOURCE>app/app/views/articles/new.html.erb:1
      ActiveSupport::Notifications.render_finish("render_template.action_view", "app/views/articles/new.html.erb", __render_started)
      nil
    end

    def self._new(article, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Articles__new)
      Views::Articles._new_into(io, article, notice, alert)
      ViewBufferCap.store(:cap_Views_Articles__new, io.bytesize)
      io
    end
  end
end
