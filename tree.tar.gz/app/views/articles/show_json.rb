module Views
  module Articles
#<SPINEL_SOURCE>app/app/views/articles/show.json.jbuilder:1
    def self.show_json(article)
      io = String.new
      io << Views::Articles.article_json(article)
      io
    end
  end
end
