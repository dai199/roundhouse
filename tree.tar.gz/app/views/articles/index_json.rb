module Views
  module Articles
#<SPINEL_SOURCE>app/app/views/articles/index.json.jbuilder:1
    def self.index_json(articles)
      io = String.new
      io << "["
      io << articles.map { |article| Views::Articles.article_json(article) }.join(",")
      io << "]"
      io
    end
  end
end
