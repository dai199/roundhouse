require_relative "../../../runtime/inflector"
require_relative "../../route_helpers"

module Views
  module Articles
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:1
    def self.form_into(io, article, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      ActionView::Base.new.form_with
      form_method = if article.persisted?
        :patch
      else
        :post
      end
      io << "<form action=\"#{ActionView::ViewHelpers.html_escape(if article.persisted?
        RouteHelpers.article_path(article.id)
      else
        RouteHelpers.articles_path
      end)}\" accept-charset=\"UTF-8\" method=\"post\" class=\"#{"contents"}\">"
      io << ActionView::ViewHelpers.method_override_input(form_method)
      io << ActionView::ViewHelpers.csrf_token_hidden_input
      io << "\n"
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:2
      if ! article.errors.empty?
        io << "    <div id=\"error_explanation\" class=\"bg-red-50 text-red-500 px-3 py-2 font-medium rounded-md mt-3\">\n      <h2>"
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:4
        io << ActionView::ViewHelpers.html_escape(Inflector.pluralize_formatted(article.errors.count.to_s, "error"))
        io << " prohibited this article from being saved:</h2>\n\n      <ul class=\"list-disc ml-6\">\n"
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:7
        article.error_details.each do |error|
          io << "          <li>"
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:8
          io << ActionView::ViewHelpers.html_escape(error.full_message.to_s)
          io << "</li>\n"
        end
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:10
        io << "      </ul>\n    </div>\n"
      end
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:13
      io << "\n  <div class=\"my-5\">\n    "
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:15
      rh_form_title_errors = article.error_messages_for("title").any?
      io << "<div class=\"field_with_errors\">" if rh_form_title_errors
      io << "<label for=\"article_title\">Title</label>"
      io << "</div>" if rh_form_title_errors
      io << "\n    "
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:16
      rh_form_title_errors = article.error_messages_for("title").any?
      io << "<div class=\"field_with_errors\">" if rh_form_title_errors
      io << "<input type=\"text\" name=\"article[title]\" id=\"article_title\"#{ActionView::ViewHelpers.optional_value_attr(article[:title])} class=\"#{ActionView::ViewHelpers.html_escape("block shadow-sm rounded-md border px-3 py-2 mt-2 w-full#{if article.error_messages_for("title").none?
        " border-gray-400 focus:outline-blue-600"
      else
        ""
      end}#{if article.error_messages_for("title").any?
        " border-red-400 focus:outline-red-600"
      else
        ""
      end}".to_s)}\">"
      io << "</div>" if rh_form_title_errors
      io << "\n  </div>\n\n  <div class=\"my-5\">\n    "
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:20
      rh_form_body_errors = article.error_messages_for("body").any?
      io << "<div class=\"field_with_errors\">" if rh_form_body_errors
      io << "<label for=\"article_body\">Body</label>"
      io << "</div>" if rh_form_body_errors
      io << "\n    "
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:21
      rh_form_body_errors = article.error_messages_for("body").any?
      io << "<div class=\"field_with_errors\">" if rh_form_body_errors
      io << "<textarea name=\"article[body]\" id=\"article_body\" rows=\"#{ActionView::ViewHelpers.html_escape(4.to_s)}\" class=\"#{ActionView::ViewHelpers.html_escape("block shadow-sm rounded-md border px-3 py-2 mt-2 w-full#{if article.error_messages_for("body").none?
        " border-gray-400 focus:outline-blue-600"
      else
        ""
      end}#{if article.error_messages_for("body").any?
        " border-red-400 focus:outline-red-600"
      else
        ""
      end}".to_s)}\">\n#{ActionView::ViewHelpers.escape_or_empty(article[:body])}</textarea>"
      io << "</div>" if rh_form_body_errors
      io << "\n  </div>\n\n  <div class=\"inline\">\n    "
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:25
      io << "<input type=\"submit\" name=\"commit\" value=\"#{ActionView::ViewHelpers.html_escape(if form_method == :patch
        "Update Article"
      else
        "Create Article"
      end)}\" data-disable-with=\"#{ActionView::ViewHelpers.html_escape(if form_method == :patch
        "Update Article"
      else
        "Create Article"
      end)}\" class=\"#{"w-full sm:w-auto rounded-md px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white inline-block font-medium cursor-pointer"}\">"
      io << "\n  </div>\n"
#<SPINEL_SOURCE>app/app/views/articles/_form.html.erb:1
      io << "</form>"
      ActiveSupport::Notifications.render_finish("render_partial.action_view", "app/views/articles/_form.html.erb", __render_started)
      nil
    end

    def self.form(article, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Articles_form)
      Views::Articles.form_into(io, article, notice, alert)
      ViewBufferCap.store(:cap_Views_Articles_form, io.bytesize)
      io
    end
  end
end
