module Views
  module Layouts
#<SPINEL_SOURCE>app/app/views/layouts/mailer.text.erb:1
    def self.mailer_text_into(io, body, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << body
      io << "\n"
      ActiveSupport::Notifications.render_finish("render_layout.action_view", "app/views/layouts/mailer.text.erb", __render_started)
      nil
    end

    def self.mailer_text(body, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Layouts_mailer_text)
      Views::Layouts.mailer_text_into(io, body, notice, alert)
      ViewBufferCap.store(:cap_Views_Layouts_mailer_text, io.bytesize)
      io
    end
  end
end
