module Views
  module Layouts
    HOISTED_STYLESHEET_LINK_TAG_APPLICATION = ActionView::ViewHelpers.stylesheet_link_tag("application", { "data-turbo-track": "reload" })
    HOISTED_STYLESHEET_LINK_TAG_TAILWIND = ActionView::ViewHelpers.stylesheet_link_tag("tailwind", { "data-turbo-track": "reload" })
    HOISTED_CONCAT = HOISTED_STYLESHEET_LINK_TAG_APPLICATION + "\n" + HOISTED_STYLESHEET_LINK_TAG_TAILWIND
    HOISTED_JAVASCRIPT_IMPORTMAP_TAGS = ActionView::ViewHelpers.javascript_importmap_tags(Importmap.pins, Importmap.entry)

#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:1
    def self.application_into(io, body, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << "<!DOCTYPE html>\n<html>\n  <head>\n    <title>"
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:4
      io << ActionView::ViewHelpers.html_escape((ActionView::ViewHelpers.content_for_get(:title) || "Real Blog").to_s)
      io << "</title>\n    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n    <meta name=\"application-name\" content=\"Real Blog\">\n    <meta name=\"mobile-web-app-capable\" content=\"yes\">\n    "
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:9
      io << ActionView::ViewHelpers.csrf_meta_tags
      io << "\n    "
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:10
      io << ActionView::ViewHelpers.csp_meta_tag
      io << "\n\n    "
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:12
      io << ActionView::ViewHelpers.get_slot(:head)
      io << "\n\n\n    <link rel=\"icon\" href=\"/icon.png\" type=\"image/png\">\n    <link rel=\"icon\" href=\"/icon.svg\" type=\"image/svg+xml\">\n    <link rel=\"apple-touch-icon\" href=\"/icon.png\">\n\n    "
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:22
      io << HOISTED_CONCAT
      io << "\n    "
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:23
      io << HOISTED_JAVASCRIPT_IMPORTMAP_TAGS
      io << "\n  </head>\n\n  <body>\n    <main class=\"container mx-auto mt-28 px-5 flex flex-col\">\n      "
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:28
      io << body
      io << "\n    </main>\n  </body>\n</html>\n"
#<SPINEL_SOURCE>app/app/views/layouts/application.html.erb:1
      ActiveSupport::Notifications.render_finish("render_layout.action_view", "app/views/layouts/application.html.erb", __render_started)
      nil
    end

    def self.application(body, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Layouts_application)
      Views::Layouts.application_into(io, body, notice, alert)
      ViewBufferCap.store(:cap_Views_Layouts_application, io.bytesize)
      io
    end
  end
end
