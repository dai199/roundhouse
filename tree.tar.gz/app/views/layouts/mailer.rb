module Views
  module Layouts
#<SPINEL_SOURCE>app/app/views/layouts/mailer.html.erb:1
    def self.mailer_into(io, body, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << "<!DOCTYPE html>\n<html>\n  <head>\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n    <style>\n      /* Email styles need to be inline */\n    </style>\n  </head>\n\n  <body>\n    "
#<SPINEL_SOURCE>app/app/views/layouts/mailer.html.erb:11
      io << body
      io << "\n  </body>\n</html>\n"
#<SPINEL_SOURCE>app/app/views/layouts/mailer.html.erb:1
      ActiveSupport::Notifications.render_finish("render_layout.action_view", "app/views/layouts/mailer.html.erb", __render_started)
      nil
    end

    def self.mailer(body, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Layouts_mailer)
      Views::Layouts.mailer_into(io, body, notice, alert)
      ViewBufferCap.store(:cap_Views_Layouts_mailer, io.bytesize)
      io
    end
  end
end
