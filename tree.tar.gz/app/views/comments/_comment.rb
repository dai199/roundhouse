require_relative "../../route_helpers"

module Views
  module Comments
#<SPINEL_SOURCE>app/app/views/comments/_comment.html.erb:1
    def self.comment_into(io, comment, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << "<div id=\""
      io << ActionView::ViewHelpers.dom_id(comment)
      io << "\" class=\"p-4 bg-gray-50 rounded\">\n  <p class=\"font-semibold\">"
#<SPINEL_SOURCE>app/app/views/comments/_comment.html.erb:2
      io << ActionView::ViewHelpers.html_escape(comment.commenter.to_s)
      io << "</p>\n  <p class=\"text-gray-700\">"
#<SPINEL_SOURCE>app/app/views/comments/_comment.html.erb:3
      io << ActionView::ViewHelpers.html_escape(comment.body.to_s)
      io << "</p>\n  "
#<SPINEL_SOURCE>app/app/views/comments/_comment.html.erb:4
      io << "<form action=\"#{ActionView::ViewHelpers.html_escape(RouteHelpers.article_comment_path(comment.article_id, comment.id))}\" method=\"post\" class=\"#{"button_to"}\">#{ActionView::ViewHelpers.method_override_input(:delete)}<button type=\"submit\" class=\"#{"text-red-600 text-sm mt-2"}\" data-turbo-confirm=\"#{"Are you sure?"}\">#{"Delete"}</button>#{ActionView::ViewHelpers.csrf_token_hidden_input}</form>"
#<SPINEL_SOURCE>app/app/views/comments/_comment.html.erb:6
      io << "\n</div>\n"
#<SPINEL_SOURCE>app/app/views/comments/_comment.html.erb:1
      ActiveSupport::Notifications.render_finish("render_partial.action_view", "app/views/comments/_comment.html.erb", __render_started)
      nil
    end

    def self.comment(comment, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Comments_comment)
      Views::Comments.comment_into(io, comment, notice, alert)
      ViewBufferCap.store(:cap_Views_Comments_comment, io.bytesize)
      io
    end
  end
end
