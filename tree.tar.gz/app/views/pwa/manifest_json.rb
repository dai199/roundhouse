module Views
  module Pwa
#<SPINEL_SOURCE>app/app/views/pwa/manifest.json.erb:1
    def self.manifest_json_into(io, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << "{\n  \"name\": \"RealBlog\",\n  \"icons\": [\n    {\n      \"src\": \"/icon.png\",\n      \"type\": \"image/png\",\n      \"sizes\": \"512x512\"\n    },\n    {\n      \"src\": \"/icon.png\",\n      \"type\": \"image/png\",\n      \"sizes\": \"512x512\",\n      \"purpose\": \"maskable\"\n    }\n  ],\n  \"start_url\": \"/\",\n  \"display\": \"standalone\",\n  \"scope\": \"/\",\n  \"description\": \"RealBlog.\",\n  \"theme_color\": \"red\",\n  \"background_color\": \"red\"\n}\n"
      ActiveSupport::Notifications.render_finish("render_template.action_view", "app/views/pwa/manifest.json.erb", __render_started)
      nil
    end

    def self.manifest_json(notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_Pwa_manifest_json)
      Views::Pwa.manifest_json_into(io, notice, alert)
      ViewBufferCap.store(:cap_Views_Pwa_manifest_json, io.bytesize)
      io
    end
  end
end
