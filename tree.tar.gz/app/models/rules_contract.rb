require_relative "dry/validation/contract"

class RulesContract < Dry::Validation::Contract
  LIMIT = 3

  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    dry_rule_schema_errors = ::Dry::Schema::Lowered.deep_dup(errors)
    if ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:name])
      nil
    else
      dry_rule_0(values, errors, dry_rule_schema_errors)
    end
    if ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:nick])
      nil
    else
      dry_rule_1(values, errors, dry_rule_schema_errors)
    end
    if ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:a]) || ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:b])
      nil
    else
      dry_rule_2(values, errors, dry_rule_schema_errors)
    end
    if ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:addr, :city])
      nil
    else
      dry_rule_3(values, errors, dry_rule_schema_errors)
    end
    if ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:a])
      nil
    else
      dry_rule_4(values, errors, dry_rule_schema_errors)
    end
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_1(input, values, errors)
    if input.key?("city") || input.key?(:city)
      dry_schema_value = if input.key?("city")
        input["city"]
      else
        input[:city]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:city] = dry_schema_value
      errors[:city] = [dry_schema_message_0] if dry_schema_message_0
    end
    values
  end
  private :dry_schema_1

  def dry_schema_0(input, values, errors)
    if input.key?("name") || input.key?(:name)
      dry_schema_value = if input.key?("name")
        input["name"]
      else
        input[:name]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:name] = dry_schema_value
      errors[:name] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:name] = ["is missing"]
    end
    if input.key?("nick") || input.key?(:nick)
      dry_schema_value = if input.key?("nick")
        input["nick"]
      else
        input[:nick]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_nil(dry_schema_value)
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a string" if !(dry_schema_value.is_a?(String)))
      end
      values[:nick] = dry_schema_value
      errors[:nick] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("a") || input.key?(:a)
      dry_schema_value = if input.key?("a")
        input["a"]
      else
        input[:a]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
      dry_schema_message_0 = ("must be an integer" if !(dry_schema_value.is_a?(Integer)))
      values[:a] = dry_schema_value
      errors[:a] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("b") || input.key?(:b)
      dry_schema_value = if input.key?("b")
        input["b"]
      else
        input[:b]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
      dry_schema_message_0 = ("must be an integer" if !(dry_schema_value.is_a?(Integer)))
      values[:b] = dry_schema_value
      errors[:b] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("addr") || input.key?(:addr)
      dry_schema_value = if input.key?("addr")
        input["addr"]
      else
        input[:addr]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_hash(dry_schema_value)
      dry_schema_message_0 = ("must be a hash" if !(dry_schema_value.is_a?(Hash)))
      if dry_schema_message_0
        values[:addr] = dry_schema_value
        errors[:addr] = [dry_schema_message_0]
      else
        dry_schema_values_0 = {}
        dry_schema_errors_0 = {}
        dry_schema_1(dry_schema_value, dry_schema_values_0, dry_schema_errors_0)
        values[:addr] = dry_schema_values_0
        if dry_schema_errors_0.empty?
          nil
        else
          errors[:addr] = dry_schema_errors_0
        end
      end
    end
    values
  end
  private :dry_schema_0

  def dry_rule_0(dry_rule_values, dry_rule_errors, dry_rule_schema_errors)
    ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:name], "too short") if dry_rule_values[:name].length < 2
    if dry_rule_values[:name].match?(/\A[a-z]+\z/)
      nil
    else
      ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:name], "bad char")
    end
  end
  private :dry_rule_0

  def dry_rule_1(dry_rule_values, dry_rule_errors, dry_rule_schema_errors)
    if dry_rule_values[:nick].nil?
      nil
    else
      ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:nick], "nick long") if dry_rule_values[:nick].size > LIMIT
      ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:nick], "nick \#@x \#$y \#{z}") if dry_rule_values[:nick] == "hsh"
    end
  end
  private :dry_rule_1

  def dry_rule_2(dry_rule_values, dry_rule_errors, dry_rule_schema_errors)
    ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:b], "b must exceed a") if ::Dry::Schema::Lowered.key_at?(dry_rule_values, [:b]) && dry_rule_values[:a] && dry_rule_values[:b] <= dry_rule_values[:a]
    ::Dry::Schema::Lowered.add_error(dry_rule_errors, [nil], "both zero") if dry_rule_values[:a] == 0 && dry_rule_values[:b] == 0
  end
  private :dry_rule_2

  def dry_rule_3(dry_rule_values, dry_rule_errors, dry_rule_schema_errors)
    ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:addr, :city], "no Moscow") if ::Dry::Schema::Lowered.key_at?(dry_rule_values, [:addr, :city]) && forbidden?(dry_rule_values.dig(:addr, :city))
  end
  private :dry_rule_3

  def dry_rule_4(dry_rule_values, dry_rule_errors, dry_rule_schema_errors)
    ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:a], "a schema err") if ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:name])
  end
  private :dry_rule_4

#<SPINEL_SOURCE>app/app/contracts/rules_contract.rb:39
  def forbidden?(city)
#<SPINEL_SOURCE>app/app/contracts/rules_contract.rb:40
    city == "Moscow"
  end
end
