require_relative "application_record"
require_relative "../../runtime/broadcasts"
require_relative "../views"

class Article < ApplicationRecord
#<SPINEL_SOURCE>app/app/models/article.rb:1
  def id
    @id
  end

  def id=(value)
    @id = value
  end

  def title
    @title
  end

  def title=(value)
    @title = value
  end

  def body
    @body
  end

  def body=(value)
    @body = value
  end

  def created_at
    ActiveSupport.present_db(@__t_created_at ||= ActiveSupport.parse_db_time(@created_at_raw))
  end

  def created_at_raw
    @created_at_raw
  end

  def created_at=(value)
    self.created_at_raw = ActiveSupport.format_db_time(value)
  end

  def created_at_raw=(value)
    @__t_created_at = nil
    @created_at_raw = value
  end

  def updated_at
    ActiveSupport.present_db(@__t_updated_at ||= ActiveSupport.parse_db_time(@updated_at_raw))
  end

  def updated_at_raw
    @updated_at_raw
  end

  def updated_at=(value)
    self.updated_at_raw = ActiveSupport.format_db_time(value)
  end

  def updated_at_raw=(value)
    @__t_updated_at = nil
    @updated_at_raw = value
  end

  def self.table_name
    "articles"
  end

  def self._table_sql
    "articles"
  end

  def self.schema_columns
    [:id, :title, :body, :created_at, :updated_at]
  end

  def self.schema_column_types
    { id: :integer, title: :string, body: :text, created_at: :datetime, updated_at: :datetime }
  end

  def self.schema_time_columns
    [:created_at, :updated_at]
  end

  def self.schema_date_columns
    []
  end

  def self.schema_boolean_columns
    []
  end

  def self.schema_decimal_columns
    []
  end

  def self.instantiate(row)
    instance = Article.from_row(ArticleRow.from_raw(row))
    instance.mark_persisted!
    instance
  end

  def self.from_row(row)
    instance = Article.new
    instance.id = row.id
    instance.title = row.title&.to_s
    instance.body = row.body&.to_s
    instance.created_at_raw = row.created_at
    instance.updated_at_raw = row.updated_at
    instance._note_hydrated
    instance
  end

  def self.from_stmt(stmt)
    instance = Article.new
    instance.id = Db.column_int(stmt, 0)
    instance.title = Db.column_text_opt(stmt, 1)
    instance.body = Db.column_text_opt(stmt, 2)
    instance.created_at_raw = Db.column_text(stmt, 3)
    instance.updated_at_raw = Db.column_text(stmt, 4)
    instance.mark_persisted!
    instance._note_hydrated
    instance
  end

  def initialize(attrs = ActiveRecord::Base::EMPTY_ATTRS)
    super(attrs)
    self.id = (attrs[:id] || 0).to_i
    self.title = attrs[:title]&.to_s
    self.body = attrs[:body]&.to_s
    self.created_at_raw = "".freeze
    self.created_at_raw = ActiveSupport.format_db_time(attrs[:created_at]) if !(attrs[:created_at].nil?)
    self.updated_at_raw = "".freeze
    self.updated_at_raw = ActiveSupport.format_db_time(attrs[:updated_at]) if !(attrs[:updated_at].nil?)
    @comments_cache = nil
    @comments_loaded = false
  end
  private :initialize

  def attributes
    { "title" => @title, "body" => @body, "created_at" => @created_at_raw, "updated_at" => @updated_at_raw }
  end

  def serializable_hash
    { "id" => self.id, "title" => self.title, "body" => self.body, "created_at" => self.created_at, "updated_at" => self.updated_at }
  end

  def [](name)
    case name.to_s
    when "id"
      @id
    when "title"
      @title&.to_s
    when "body"
      @body&.to_s
    when "created_at"
      @created_at_raw
    when "updated_at"
      @updated_at_raw
    end
  end

  def []=(name, value)
    case name
    when :id
      @id = (value).to_i
    when :title
      @title = value&.to_s
    when :body
      @body = value&.to_s
    when :created_at
      self.created_at_raw = ActiveSupport.format_db_time(value)
    when :updated_at
      self.updated_at_raw = ActiveSupport.format_db_time(value)
    end
  end

  def _assign_mass_attribute(name, value)
    if name == "id"
      if respond_to?(:id=)
        self.id = ActiveSupport.cast_integer(value)
      else
        _unknown_mass_attribute(name)
      end
    else
      if name == "title"
        if respond_to?(:title=)
          self.title = ActiveSupport.cast_string(value)
        else
          _unknown_mass_attribute(name)
        end
      else
        if name == "body"
          if respond_to?(:body=)
            self.body = ActiveSupport.cast_string(value)
          else
            _unknown_mass_attribute(name)
          end
        else
          if name == "created_at"
            if respond_to?(:created_at=)
              self.created_at = value
            else
              _unknown_mass_attribute(name)
            end
          else
            if name == "updated_at"
              if respond_to?(:updated_at=)
                self.updated_at = value
              else
                _unknown_mass_attribute(name)
              end
            else
              _unknown_mass_attribute(name)
            end
          end
        end
      end
    end
    nil
  end

  def update(attrs)
    self.title = attrs[:title]&.to_s if attrs.key?(:title)
    self.body = attrs[:body]&.to_s if attrs.key?(:body)
    self.created_at_raw = (attrs[:created_at]).to_s if attrs.key?(:created_at)
    self.created_at_raw = ActiveSupport.format_db_time(attrs[:created_at]) if attrs.key?(:created_at)
    self.updated_at_raw = (attrs[:updated_at]).to_s if attrs.key?(:updated_at)
    self.updated_at_raw = ActiveSupport.format_db_time(attrs[:updated_at]) if attrs.key?(:updated_at)
    self.save
  end

  def update!(attrs)
    self.title = attrs[:title]&.to_s if attrs.key?(:title)
    self.body = attrs[:body]&.to_s if attrs.key?(:body)
    self.created_at_raw = (attrs[:created_at]).to_s if attrs.key?(:created_at)
    self.created_at_raw = ActiveSupport.format_db_time(attrs[:created_at]) if attrs.key?(:created_at)
    self.updated_at_raw = (attrs[:updated_at]).to_s if attrs.key?(:updated_at)
    self.updated_at_raw = ActiveSupport.format_db_time(attrs[:updated_at]) if attrs.key?(:updated_at)
    self.save!
    self
  end

  def fill_timestamps(creating)
    now = ActiveSupport.db_now
    if !(creating) || @updated_at_raw.nil? || @updated_at_raw.empty?
      @__t_updated_at = nil
      @updated_at_raw = now
    end
    if creating && (@created_at_raw.nil? || @created_at_raw.empty?)
      @__t_created_at = nil
      @created_at_raw = now
    end
  end

  def self._find_primary_key_input(id)
    cast = ActiveRecord::IntegerKeyCast.parse(id)
    _adapter_find_by_id(cast.value) if cast.valid
  end

  def self._exists_primary_key_input(id)
    cast = ActiveRecord::IntegerKeyCast.parse(id)
    if cast.valid
      _adapter_exists_by_id?(cast.value)
    else
      false
    end
  end

  def self._adapter_find_by_id(id)
    stmt = Db.prepare("SELECT id, title, body, created_at, updated_at FROM articles WHERE id = ? LIMIT 1")
    begin
      Db.bind_int(stmt, 1, id)
      result = nil
      if Db.step?(stmt)
        result = Article.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_all
    stmt = Db.prepare("SELECT id, title, body, created_at, updated_at FROM articles")
    begin
      results = []
      while Db.step?(stmt)
        results << Article.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    results
  end

  def self._adapter_last
    stmt = Db.prepare("SELECT id, title, body, created_at, updated_at FROM articles ORDER BY id DESC LIMIT 1")
    begin
      result = nil
      if Db.step?(stmt)
        result = Article.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def _adapter_insert
    if @id.to_i != 0
      Db.exec("INSERT INTO articles (id, title, body, created_at, updated_at) VALUES (" + Db.escape_int(@id) + ", " + Db.escape_string_opt(@title) + ", " + Db.escape_string_opt(@body) + ", " + Db.escape_string(@created_at_raw) + ", " + Db.escape_string(@updated_at_raw) + ")")
      @id
    else
      Db.exec("INSERT INTO articles (title, body, created_at, updated_at) VALUES (" + Db.escape_string_opt(@title) + ", " + Db.escape_string_opt(@body) + ", " + Db.escape_string(@created_at_raw) + ", " + Db.escape_string(@updated_at_raw) + ")")
      Db.last_insert_rowid
    end
  end

  def _adapter_update
    cols = _columns_to_write
    sets = ""
    sets = sets + ", title = " + Db.escape_string_opt(@title) if cols.include?("title")
    sets = sets + ", body = " + Db.escape_string_opt(@body) if cols.include?("body")
    sets = sets + ", created_at = " + Db.escape_string(@created_at_raw) if cols.include?("created_at")
    sets = sets + ", updated_at = " + Db.escape_string(@updated_at_raw) if cols.include?("updated_at")
    if sets.empty?
      nil
    else
      Db.exec("UPDATE articles SET " + sets[2, sets.length - 2] + " WHERE id = " + Db.escape_int(@id))
    end
  end

  def _adapter_touch
    Db.exec("UPDATE articles SET updated_at = " + Db.escape_string(@updated_at_raw) + " WHERE id = " + Db.escape_int(@id))
  end

  def _adapter_delete
    Db.exec("DELETE FROM articles WHERE id = " + Db.escape_int(@id))
  end

  def self._adapter_count
    stmt = Db.prepare("SELECT COUNT(*) FROM articles")
    begin
      Db.step?(stmt)
      result = Db.column_int(stmt, 0)
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_any?
    stmt = Db.prepare("SELECT 1 FROM articles LIMIT 1")
    begin
      result = Db.step?(stmt)
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_exists_by_id?(id)
    stmt = Db.prepare("SELECT 1 FROM articles WHERE id = ? LIMIT 1")
    begin
      Db.bind_int(stmt, 1, id)
      result = Db.step?(stmt)
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_truncate
    Db.exec("DELETE FROM articles")
    Db.exec("DELETE FROM sqlite_sequence WHERE name = 'articles'")
  end

  def self.delete_all
    Db.exec("DELETE FROM articles")
    Db.changes
  end

  def _adapter_reload
    @comments_loaded = false
    stmt = Db.prepare("SELECT id, title, body, created_at, updated_at FROM articles WHERE id = ? LIMIT 1")
    begin
      Db.bind_int(stmt, 1, @id)
      if Db.step?(stmt)
        @id = Db.column_int(stmt, 0)
        @title = Db.column_text_opt(stmt, 1)
        @body = Db.column_text_opt(stmt, 2)
        @__t_created_at = nil
        @created_at_raw = Db.column_text(stmt, 3)
        @__t_updated_at = nil
        @updated_at_raw = Db.column_text(stmt, 4)
        self.mark_persisted!
      end
    ensure
      Db.finalize(stmt)
    end
    self
  end

  def self._columns_sql
    "\"articles\".\"id\" AS id, \"articles\".\"title\" AS title, \"articles\".\"body\" AS body, \"articles\".\"created_at\" AS created_at, \"articles\".\"updated_at\" AS updated_at"
  end

  def self._hydrate_all(sql)
    stmt = Db.prepare(sql)
    begin
      results = []
      while Db.step?(stmt)
        results << Article.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    results
  end

  def self.from_params(p)
    raise("Article creating from a multiparameter key (`attr(N)`) is not modeled for this attribute or value: roundhouse reproduces Rails' value only for a String or Text attribute whose parts are plain text or integers") if p.rh_multiparameter_unsupported
    instance = Article.new
    instance.title = p.title if p.title_provided
    instance.body = p.body if p.body_provided
    instance
  end

  def update_from_article_params(p)
    raise("Article updating from a multiparameter key (`attr(N)`) is not modeled for this attribute or value: roundhouse reproduces Rails' value only for a String or Text attribute whose parts are plain text or integers") if p.rh_multiparameter_unsupported
    if !(p.title_provided)
      nil
    else
      self.title = p.title
    end
    if !(p.body_provided)
      nil
    else
      self.body = p.body
    end
    self.save
  end

  def update_from_article_params!(p)
    raise("Article updating from a multiparameter key (`attr(N)`) is not modeled for this attribute or value: roundhouse reproduces Rails' value only for a String or Text attribute whose parts are plain text or integers") if p.rh_multiparameter_unsupported
    if !(p.title_provided)
      nil
    else
      self.title = p.title
    end
    if !(p.body_provided)
      nil
    else
      self.body = p.body
    end
    self.save!
    self
  end

  def validate
    __held_comments_valid
#<SPINEL_SOURCE>app/app/models/article.rb:8
    if @title.nil? || /\A[[:space:]]*\z/.match?(@title.to_s)
      self.errors << "Title can't be blank"
      self.error_details << ActiveRecord::ErrorDetail.new("title", "blank", "can't be blank", "Title can't be blank", true, true)
    end
#<SPINEL_SOURCE>app/app/models/article.rb:9
    if @body.nil? || /\A[[:space:]]*\z/.match?(@body.to_s)
      self.errors << "Body can't be blank"
      self.error_details << ActiveRecord::ErrorDetail.new("body", "blank", "can't be blank", "Body can't be blank", true, true)
    end
    if @body.nil?
      self.errors << "Body is too short (minimum is 10 characters)"
      self.error_details << ActiveRecord::ErrorDetail.new("body", "too_short", "is too short (minimum is 10 characters)", "Body is too short (minimum is 10 characters)", true, false)
    else
      len = @body.length
      if len < 10
        self.errors << "Body is too short (minimum is 10 characters)"
        self.error_details << ActiveRecord::ErrorDetail.new("body", "too_short", "is too short (minimum is 10 characters)", "Body is too short (minimum is 10 characters)", true, false)
      end
    end
  end

#<SPINEL_SOURCE>app/app/models/article.rb:2
  def comments
    return __comments_cache if @comments_loaded
    if new_record? && (@id.nil? || @id == 0)
      return (if @__held_comments.nil?
        []
      else
        @__held_comments
      end)
    end
    stmt = Db.prepare("SELECT id, article_id, commenter, body, created_at, updated_at FROM comments WHERE article_id = ?")
    begin
      Db.bind_int(stmt, 1, @id)
      results = []
      while Db.step?(stmt)
        results << Comment.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    results
  end

  def _preload_comments(list)
    @comments_cache = list
    @comments_loaded = true
  end

  def comments_loaded?
    @comments_loaded
  end

  def reload_comments
    @comments_loaded = false
    self.comments
  end

  def comments_target
    __comments_cache
  end

  def comment_ids
    self.comments.map { |rh_id_record| rh_id_record.id }
  end

#<SPINEL_SOURCE>app/app/models/article.rb:1
  def self._association_names
    [:comments]
  end

#<SPINEL_SOURCE>app/app/models/article.rb:2
  def before_destroy
    self.comments.each { |c| c.destroy }
  end

  def __hold_comments(record)
    @__held_comments = [] if @__held_comments.nil?
    @__held_comments << record
    record
  end

  def __push_comments(record)
    if new_record?
      record.article = self
      __hold_comments(record)
      self.comments
    else
      record.article_id = self.id
      self.comments if record.save
    end
  end

  def __push_all_comments(records)
    if new_record?
      records.each { |record| __push_comments(record) }
      return self.comments
    end
    pushed = true
    Article.transaction do
      records.each do |record|
        if __push_comments(record).nil?
          nil
        else
          next
        end
        pushed = false
        raise ActiveRecord::Rollback
      end
    end
    self.comments if pushed
  end

  def __held_comments_list
    if @__held_comments.nil?
      []
    else
      @__held_comments
    end
  end

#<SPINEL_SOURCE>app/app/models/article.rb:1
  def __held_comments_valid
    if @__held_comments.nil?
      nil
    else
      invalid = false
      self.__held_comments_list.each do |child|
        next if child.valid?
        child.error_details.each { |error| if error.attribute.to_sym.to_s == "article"
          nil
        else
          invalid = true
        end }
      end
      if invalid
        self.errors << "Comments is invalid"
        self.error_details << ActiveRecord::ErrorDetail.new("comments", "invalid", "is invalid", "Comments is invalid", true, true)
      end
    end
  end

  def __held_comments_save
    if @__held_comments.nil? || @__held_comments_saving
      nil
    else
      @__held_comments_saving = true
      begin
        self.__held_comments_list.each do |child|
          child.article_id = self.id
          child.save!
        end
      ensure
        @__held_comments_saving = false
      end
    end
  end

  def __held_comments_committed
    @__held_comments = nil
  end

  def dom_prefix
    "article"
  end

  def to_param
    @id.to_s
  end

  def dom_record_key
    @id.to_s
  end

  def cache_key
    if self.persisted?
      "articles/#{@id}"
    else
      "articles/new"
    end
  end

  def cache_key_with_version
    if self.persisted?
      "articles/#{@id}-#{@updated_at_raw}"
    else
      "articles/new-#{@updated_at_raw}"
    end
  end

#<SPINEL_SOURCE>app/app/models/article.rb:6
  def after_create_commit
    Broadcasts.prepend(stream: "articles", target: "articles", html: ActionView::ViewHelpers.broadcast_render(ActionView::ViewHelpers.begin_broadcast_render, Views::Articles.article(self)))
  end

  def after_update_commit
    Broadcasts.replace(stream: "articles", target: "#{self.dom_prefix}_#{self.dom_record_key}", html: ActionView::ViewHelpers.broadcast_render(ActionView::ViewHelpers.begin_broadcast_render, Views::Articles.article(self)))
  end

  def after_destroy_commit
    Broadcasts.remove(stream: "articles", target: "#{self.dom_prefix}_#{self.dom_record_key}")
  end

  def after_save
    __held_comments_save
  end

  def after_save_commit
    __held_comments_committed
  end

  def reload(options = nil)
    super(options)
    self
  end

  def lock!(lock = true)
    super(lock)
    self
  end

  def to_gid_param
    GlobalID.param("Article", self.id)
  end

  def to_gid_uri
    GlobalID.uri("Article", self.id)
  end

  def self._preload_batch_comments(records)
    ids = []
    records.each do |r| ids << r.id end
    loaded = []
    loaded = ActiveRecord::Relation.new(Comment).where(article_id: ids).to_a if ids.length > 0
    grouped = {}
    loaded.each do |rec|
      k = rec.article_id
      grouped[k] = [] if grouped[k].nil?
      grouped[k] << rec
    end
    records.each do |r| r._preload_comments(grouped[r.id] || []) end
    loaded
  end

  def self._preload_dispatch(records, name, nested)
    case name
    when :comments
      loaded = _preload_batch_comments(records)
      if nested.nil?
        nil
      else
        Comment.preload_associations(loaded, [nested])
      end
    end
    nil
  end

  def self._eager_dispatch(records, name, filter)
    case name
    when :comments
      ids = []
      records.each do |r| ids << r.id end
      loaded = []
      if ids.length > 0
        rel = ActiveRecord::Relation.new(Comment).where(article_id: ids)
        filter.conditions.each do |c| rel = rel.where(c) end
        filter.negations.each do |c| rel = rel.where.not(c) end
        filter.orders.each do |o| rel = rel.order(o) end
        loaded = rel.to_a
      end
      grouped = {}
      loaded.each do |rec|
        k = rec.article_id
        grouped[k] = [] if grouped[k].nil?
        grouped[k] << rec
      end
      records.each do |r| r._preload_comments(grouped[r.id] || []) end
      if filter.nested.nil?
        nil
      else
        Comment.preload_associations(loaded, [filter.nested])
      end
    end
    nil
  end

  def self.preload_associations(records, specs)
    return if records.length == 0
    specs.each do |spec|
      if spec.is_a?(Hash)
        spec.each do |name, nested|
          if nested.is_a?(ActiveRecord::EagerFilter)
            _eager_dispatch(records, name, nested)
          else
            _preload_dispatch(records, name, nested)
          end
        end
      else
        if spec.is_a?(Array)
          preload_associations(records, spec)
        else
          _preload_dispatch(records, spec, nil) if !(spec.nil?)
        end
      end
    end
    nil
  end

  def __comments_cache
    c = @comments_cache
    if c.nil?
      c = []
      @comments_cache = c
    end
    c
  end
end
