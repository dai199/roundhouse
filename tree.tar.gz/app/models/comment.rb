require_relative "application_record"
require_relative "../../runtime/broadcasts"
require_relative "../views"

class Comment < ApplicationRecord
#<SPINEL_SOURCE>app/app/models/comment.rb:1
  def id
    @id
  end

  def id=(value)
    @id = value
  end

  def article_id
    @article_id
  end

  def article_id=(value)
    @article_loaded = false
    @article_id = ActiveSupport.cast_integer(value)
  end

  def commenter
    @commenter
  end

  def commenter=(value)
    @commenter = value
  end

  def body
    @body
  end

  def body=(value)
    @body = value
  end

  def created_at
    ActiveSupport.present_db(@__t_created_at ||= ActiveSupport.parse_db_time(@created_at_raw))
  end

  def created_at_raw
    @created_at_raw
  end

  def created_at=(value)
    self.created_at_raw = ActiveSupport.format_db_time(value)
  end

  def created_at_raw=(value)
    @__t_created_at = nil
    @created_at_raw = value
  end

  def updated_at
    ActiveSupport.present_db(@__t_updated_at ||= ActiveSupport.parse_db_time(@updated_at_raw))
  end

  def updated_at_raw
    @updated_at_raw
  end

  def updated_at=(value)
    self.updated_at_raw = ActiveSupport.format_db_time(value)
  end

  def updated_at_raw=(value)
    @__t_updated_at = nil
    @updated_at_raw = value
  end

  def self.table_name
    "comments"
  end

  def self._table_sql
    "comments"
  end

  def self.schema_columns
    [:id, :article_id, :commenter, :body, :created_at, :updated_at]
  end

  def self.schema_column_types
    { id: :integer, article_id: :integer, commenter: :string, body: :text, created_at: :datetime, updated_at: :datetime }
  end

  def self.schema_time_columns
    [:created_at, :updated_at]
  end

  def self.schema_date_columns
    []
  end

  def self.schema_boolean_columns
    []
  end

  def self.schema_decimal_columns
    []
  end

  def self.instantiate(row)
    instance = Comment.from_row(CommentRow.from_raw(row))
    instance.mark_persisted!
    instance
  end

  def self.from_row(row)
    instance = Comment.new
    instance.id = row.id
    instance.article_id = row.article_id
    instance.commenter = row.commenter&.to_s
    instance.body = row.body&.to_s
    instance.created_at_raw = row.created_at
    instance.updated_at_raw = row.updated_at
    instance._note_hydrated
    instance
  end

  def self.from_stmt(stmt)
    instance = Comment.new
    instance.id = Db.column_int(stmt, 0)
    instance.article_id = Db.column_int(stmt, 1)
    instance.commenter = Db.column_text_opt(stmt, 2)
    instance.body = Db.column_text_opt(stmt, 3)
    instance.created_at_raw = Db.column_text(stmt, 4)
    instance.updated_at_raw = Db.column_text(stmt, 5)
    instance.mark_persisted!
    instance._note_hydrated
    instance
  end

  def initialize(attrs = ActiveRecord::Base::EMPTY_ATTRS)
    super(attrs)
    self.id = (attrs[:id] || 0).to_i
    self.article_id = attrs[:article_id] || 0
    self.commenter = attrs[:commenter]&.to_s
    self.body = attrs[:body]&.to_s
    self.created_at_raw = "".freeze
    self.created_at_raw = ActiveSupport.format_db_time(attrs[:created_at]) if !(attrs[:created_at].nil?)
    self.updated_at_raw = "".freeze
    self.updated_at_raw = ActiveSupport.format_db_time(attrs[:updated_at]) if !(attrs[:updated_at].nil?)
    self.article = attrs[:article] if !(attrs[:article].nil?)
  end
  private :initialize

  def attributes
    { "article_id" => @article_id, "commenter" => @commenter, "body" => @body, "created_at" => @created_at_raw, "updated_at" => @updated_at_raw }
  end

  def serializable_hash
    { "id" => self.id, "article_id" => self.article_id, "commenter" => self.commenter, "body" => self.body, "created_at" => self.created_at, "updated_at" => self.updated_at }
  end

  def [](name)
    case name.to_s
    when "id"
      @id
    when "article_id"
      @article_id
    when "commenter"
      @commenter&.to_s
    when "body"
      @body&.to_s
    when "created_at"
      @created_at_raw
    when "updated_at"
      @updated_at_raw
    end
  end

  def []=(name, value)
    case name
    when :id
      @id = (value).to_i
    when :article_id
      @article_id = (value).to_i
    when :commenter
      @commenter = value&.to_s
    when :body
      @body = value&.to_s
    when :created_at
      self.created_at_raw = ActiveSupport.format_db_time(value)
    when :updated_at
      self.updated_at_raw = ActiveSupport.format_db_time(value)
    end
  end

  def _assign_mass_attribute(name, value)
    if name == "id"
      if respond_to?(:id=)
        self.id = ActiveSupport.cast_integer(value)
      else
        _unknown_mass_attribute(name)
      end
    else
      if name == "article_id"
        if respond_to?(:article_id=)
          self.article_id = ActiveSupport.cast_integer(value)
        else
          _unknown_mass_attribute(name)
        end
      else
        if name == "commenter"
          if respond_to?(:commenter=)
            self.commenter = ActiveSupport.cast_string(value)
          else
            _unknown_mass_attribute(name)
          end
        else
          if name == "body"
            if respond_to?(:body=)
              self.body = ActiveSupport.cast_string(value)
            else
              _unknown_mass_attribute(name)
            end
          else
            if name == "created_at"
              if respond_to?(:created_at=)
                self.created_at = value
              else
                _unknown_mass_attribute(name)
              end
            else
              if name == "updated_at"
                if respond_to?(:updated_at=)
                  self.updated_at = value
                else
                  _unknown_mass_attribute(name)
                end
              else
                if name == "article"
                  if respond_to?(:article=)
                    self.article = value
                  else
                    _unknown_mass_attribute(name)
                  end
                else
                  _unknown_mass_attribute(name)
                end
              end
            end
          end
        end
      end
    end
    nil
  end

  def update(attrs)
    self.article_id = (attrs[:article_id]).to_i if attrs.key?(:article_id)
    self.commenter = attrs[:commenter]&.to_s if attrs.key?(:commenter)
    self.body = attrs[:body]&.to_s if attrs.key?(:body)
    self.created_at_raw = (attrs[:created_at]).to_s if attrs.key?(:created_at)
    self.created_at_raw = ActiveSupport.format_db_time(attrs[:created_at]) if attrs.key?(:created_at)
    self.updated_at_raw = (attrs[:updated_at]).to_s if attrs.key?(:updated_at)
    self.updated_at_raw = ActiveSupport.format_db_time(attrs[:updated_at]) if attrs.key?(:updated_at)
    self.save
  end

  def update!(attrs)
    self.article_id = (attrs[:article_id]).to_i if attrs.key?(:article_id)
    self.commenter = attrs[:commenter]&.to_s if attrs.key?(:commenter)
    self.body = attrs[:body]&.to_s if attrs.key?(:body)
    self.created_at_raw = (attrs[:created_at]).to_s if attrs.key?(:created_at)
    self.created_at_raw = ActiveSupport.format_db_time(attrs[:created_at]) if attrs.key?(:created_at)
    self.updated_at_raw = (attrs[:updated_at]).to_s if attrs.key?(:updated_at)
    self.updated_at_raw = ActiveSupport.format_db_time(attrs[:updated_at]) if attrs.key?(:updated_at)
    self.save!
    self
  end

  def fill_timestamps(creating)
    now = ActiveSupport.db_now
    if !(creating) || @updated_at_raw.nil? || @updated_at_raw.empty?
      @__t_updated_at = nil
      @updated_at_raw = now
    end
    if creating && (@created_at_raw.nil? || @created_at_raw.empty?)
      @__t_created_at = nil
      @created_at_raw = now
    end
  end

  def self._find_primary_key_input(id)
    cast = ActiveRecord::IntegerKeyCast.parse(id)
    _adapter_find_by_id(cast.value) if cast.valid
  end

  def self._exists_primary_key_input(id)
    cast = ActiveRecord::IntegerKeyCast.parse(id)
    if cast.valid
      _adapter_exists_by_id?(cast.value)
    else
      false
    end
  end

  def self._adapter_find_by_id(id)
    stmt = Db.prepare("SELECT id, article_id, commenter, body, created_at, updated_at FROM comments WHERE id = ? LIMIT 1")
    begin
      Db.bind_int(stmt, 1, id)
      result = nil
      if Db.step?(stmt)
        result = Comment.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_all
    stmt = Db.prepare("SELECT id, article_id, commenter, body, created_at, updated_at FROM comments")
    begin
      results = []
      while Db.step?(stmt)
        results << Comment.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    results
  end

  def self._adapter_last
    stmt = Db.prepare("SELECT id, article_id, commenter, body, created_at, updated_at FROM comments ORDER BY id DESC LIMIT 1")
    begin
      result = nil
      if Db.step?(stmt)
        result = Comment.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def _adapter_insert
    if @id.to_i != 0
      Db.exec("INSERT INTO comments (id, article_id, commenter, body, created_at, updated_at) VALUES (" + Db.escape_int(@id) + ", " + Db.escape_int(@article_id) + ", " + Db.escape_string_opt(@commenter) + ", " + Db.escape_string_opt(@body) + ", " + Db.escape_string(@created_at_raw) + ", " + Db.escape_string(@updated_at_raw) + ")")
      @id
    else
      Db.exec("INSERT INTO comments (article_id, commenter, body, created_at, updated_at) VALUES (" + Db.escape_int(@article_id) + ", " + Db.escape_string_opt(@commenter) + ", " + Db.escape_string_opt(@body) + ", " + Db.escape_string(@created_at_raw) + ", " + Db.escape_string(@updated_at_raw) + ")")
      Db.last_insert_rowid
    end
  end

  def _adapter_update
    cols = _columns_to_write
    sets = ""
    sets = sets + ", article_id = " + Db.escape_int(@article_id) if cols.include?("article_id")
    sets = sets + ", commenter = " + Db.escape_string_opt(@commenter) if cols.include?("commenter")
    sets = sets + ", body = " + Db.escape_string_opt(@body) if cols.include?("body")
    sets = sets + ", created_at = " + Db.escape_string(@created_at_raw) if cols.include?("created_at")
    sets = sets + ", updated_at = " + Db.escape_string(@updated_at_raw) if cols.include?("updated_at")
    if sets.empty?
      nil
    else
      Db.exec("UPDATE comments SET " + sets[2, sets.length - 2] + " WHERE id = " + Db.escape_int(@id))
    end
  end

  def _adapter_touch
    Db.exec("UPDATE comments SET updated_at = " + Db.escape_string(@updated_at_raw) + " WHERE id = " + Db.escape_int(@id))
  end

  def _adapter_delete
    Db.exec("DELETE FROM comments WHERE id = " + Db.escape_int(@id))
  end

  def self._adapter_count
    stmt = Db.prepare("SELECT COUNT(*) FROM comments")
    begin
      Db.step?(stmt)
      result = Db.column_int(stmt, 0)
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_any?
    stmt = Db.prepare("SELECT 1 FROM comments LIMIT 1")
    begin
      result = Db.step?(stmt)
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_exists_by_id?(id)
    stmt = Db.prepare("SELECT 1 FROM comments WHERE id = ? LIMIT 1")
    begin
      Db.bind_int(stmt, 1, id)
      result = Db.step?(stmt)
    ensure
      Db.finalize(stmt)
    end
    result
  end

  def self._adapter_truncate
    Db.exec("DELETE FROM comments")
    Db.exec("DELETE FROM sqlite_sequence WHERE name = 'comments'")
  end

  def self.delete_all
    Db.exec("DELETE FROM comments")
    Db.changes
  end

  def _adapter_reload
    @article_loaded = false
    stmt = Db.prepare("SELECT id, article_id, commenter, body, created_at, updated_at FROM comments WHERE id = ? LIMIT 1")
    begin
      Db.bind_int(stmt, 1, @id)
      if Db.step?(stmt)
        @id = Db.column_int(stmt, 0)
        @article_id = Db.column_int(stmt, 1)
        @commenter = Db.column_text_opt(stmt, 2)
        @body = Db.column_text_opt(stmt, 3)
        @__t_created_at = nil
        @created_at_raw = Db.column_text(stmt, 4)
        @__t_updated_at = nil
        @updated_at_raw = Db.column_text(stmt, 5)
        self.mark_persisted!
      end
    ensure
      Db.finalize(stmt)
    end
    self
  end

  def self._columns_sql
    "\"comments\".\"id\" AS id, \"comments\".\"article_id\" AS article_id, \"comments\".\"commenter\" AS commenter, \"comments\".\"body\" AS body, \"comments\".\"created_at\" AS created_at, \"comments\".\"updated_at\" AS updated_at"
  end

  def self._hydrate_all(sql)
    stmt = Db.prepare(sql)
    begin
      results = []
      while Db.step?(stmt)
        results << Comment.from_stmt(stmt)
      end
    ensure
      Db.finalize(stmt)
    end
    results
  end

  def self.from_params(p)
    raise("Comment creating from a multiparameter key (`attr(N)`) is not modeled for this attribute or value: roundhouse reproduces Rails' value only for a String or Text attribute whose parts are plain text or integers") if p.rh_multiparameter_unsupported
    instance = Comment.new
    instance.commenter = p.commenter if p.commenter_provided
    instance.body = p.body if p.body_provided
    instance
  end

  def update_from_comment_params(p)
    raise("Comment updating from a multiparameter key (`attr(N)`) is not modeled for this attribute or value: roundhouse reproduces Rails' value only for a String or Text attribute whose parts are plain text or integers") if p.rh_multiparameter_unsupported
    if !(p.commenter_provided)
      nil
    else
      self.commenter = p.commenter
    end
    if !(p.body_provided)
      nil
    else
      self.body = p.body
    end
    self.save
  end

  def update_from_comment_params!(p)
    raise("Comment updating from a multiparameter key (`attr(N)`) is not modeled for this attribute or value: roundhouse reproduces Rails' value only for a String or Text attribute whose parts are plain text or integers") if p.rh_multiparameter_unsupported
    if !(p.commenter_provided)
      nil
    else
      self.commenter = p.commenter
    end
    if !(p.body_provided)
      nil
    else
      self.body = p.body
    end
    self.save!
    self
  end

#<SPINEL_SOURCE>app/app/models/comment.rb:2
  def validate
    if @article_id.nil? || @article_id == 0 || self.article.nil?
      self.errors << "Article must exist"
      self.error_details << ActiveRecord::ErrorDetail.new("article", "blank", "must exist", "Article must exist", true, true)
    end
#<SPINEL_SOURCE>app/app/models/comment.rb:4
    if @commenter.nil? || /\A[[:space:]]*\z/.match?(@commenter.to_s)
      self.errors << "Commenter can't be blank"
      self.error_details << ActiveRecord::ErrorDetail.new("commenter", "blank", "can't be blank", "Commenter can't be blank", true, true)
    end
#<SPINEL_SOURCE>app/app/models/comment.rb:5
    if @body.nil? || /\A[[:space:]]*\z/.match?(@body.to_s)
      self.errors << "Body can't be blank"
      self.error_details << ActiveRecord::ErrorDetail.new("body", "blank", "can't be blank", "Body can't be blank", true, true)
    end
  end

  def article
    return @article_cache if @article_loaded
#<SPINEL_SOURCE>app/app/models/comment.rb:2
    @article_cache = if @article_id.nil? || @article_id == 0
      nil
    else
      stmt = Db.prepare("SELECT id, title, body, created_at, updated_at FROM articles WHERE id = ? LIMIT 1")
      begin
        Db.bind_int(stmt, 1, @article_id)
        result = nil
        if Db.step?(stmt)
          result = Article.from_stmt(stmt)
        end
      ensure
        Db.finalize(stmt)
      end
      result
    end
    @article_loaded = true
    @article_cache
  end

  def article=(value)
    @article_loaded = false
    if value.nil?
      @article_id = nil
    else
      @article_id = value.id
      @article_cache = value
      @article_loaded = true
    end
  end

  def article_loaded?
    @article_loaded
  end

#<SPINEL_SOURCE>app/app/models/comment.rb:1
  def self._association_names
    [:article]
  end

  def dom_prefix
    "comment"
  end

  def to_param
    @id.to_s
  end

  def dom_record_key
    @id.to_s
  end

  def cache_key
    if self.persisted?
      "comments/#{@id}"
    else
      "comments/new"
    end
  end

  def cache_key_with_version
    if self.persisted?
      "comments/#{@id}-#{@updated_at_raw}"
    else
      "comments/new-#{@updated_at_raw}"
    end
  end

#<SPINEL_SOURCE>app/app/models/comment.rb:9
  def after_create_commit
    Broadcasts.append(stream: "article_#{@article_id}_comments", target: "comments", html: ActionView::ViewHelpers.broadcast_render(ActionView::ViewHelpers.begin_broadcast_render, Views::Comments.comment(self)))
#<SPINEL_SOURCE>app/app/models/comment.rb:13
    parent = self.article
    return if parent.nil?
    Broadcasts.replace(stream: "articles", target: "#{parent.dom_prefix}_#{parent.dom_record_key}", html: ActionView::ViewHelpers.broadcast_render(ActionView::ViewHelpers.begin_broadcast_render, Views::Articles.article(parent)))
  end

#<SPINEL_SOURCE>app/app/models/comment.rb:9
  def after_update_commit
    Broadcasts.replace(stream: "article_#{@article_id}_comments", target: "#{self.dom_prefix}_#{self.dom_record_key}", html: ActionView::ViewHelpers.broadcast_render(ActionView::ViewHelpers.begin_broadcast_render, Views::Comments.comment(self)))
  end

  def after_destroy_commit
    Broadcasts.remove(stream: "article_#{@article_id}_comments", target: "#{self.dom_prefix}_#{self.dom_record_key}")
#<SPINEL_SOURCE>app/app/models/comment.rb:14
    parent = self.article
    return if parent.nil?
    Broadcasts.replace(stream: "articles", target: "#{parent.dom_prefix}_#{parent.dom_record_key}", html: ActionView::ViewHelpers.broadcast_render(ActionView::ViewHelpers.begin_broadcast_render, Views::Articles.article(parent)))
  end

  def reload(options = nil)
    super(options)
    self
  end

  def lock!(lock = true)
    super(lock)
    self
  end

  def to_gid_param
    GlobalID.param("Comment", self.id)
  end

  def to_gid_uri
    GlobalID.uri("Comment", self.id)
  end

  def _autosave_article
    if @article_loaded && @article_id == 0 && !(@article_cache.nil?)
      @article_cache.save
      @article_id = @article_cache.id
    end
  end

  def _autosave_belongs_to
    _autosave_article
  end

  def self._preload_batch_article(records)
    ids = []
    records.each do |r|
      v = r.article_id
      if v.nil? || v == 0
        nil
      else
        ids << v
      end
    end
    ids.uniq!
    by_id = {}
    Article._hydrate_all("SELECT " + Article._columns_sql + " FROM articles WHERE articles.id IN (" + Db.escape_int_list(ids) + ")").each do |rec| by_id[rec.id] = rec end if ids.length > 0
    records.each do |r| r._preload_article(by_id[r.article_id]) end
    by_id.values
  end

  def _preload_article(rec)
    @article_cache = rec
    @article_loaded = true
    nil
  end

  def self._preload_dispatch(records, name, nested)
    case name
    when :article
      loaded = _preload_batch_article(records)
      if nested.nil?
        nil
      else
        Article.preload_associations(loaded, [nested])
      end
    end
    nil
  end

  def self._eager_dispatch(records, name, filter)
    nil
  end

  def self.preload_associations(records, specs)
    return if records.length == 0
    specs.each do |spec|
      if spec.is_a?(Hash)
        spec.each do |name, nested|
          if nested.is_a?(ActiveRecord::EagerFilter)
            _eager_dispatch(records, name, nested)
          else
            _preload_dispatch(records, name, nested)
          end
        end
      else
        if spec.is_a?(Array)
          preload_associations(records, spec)
        else
          _preload_dispatch(records, spec, nil) if !(spec.nil?)
        end
      end
    end
    nil
  end
end
