require_relative "../localized_contract"

module Users
  class GuestContract < LocalizedContract
    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      ::Dry::Validation::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_0(input, values, errors)
      if input.key?("login") || input.key?(:login)
        dry_schema_value = if input.key?("login")
          input["login"]
        else
          input[:login]
        end
        dry_schema_value = dry_schema_value
        dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
          raise(::Dry::Schema::MissingMessageError, "Message template for :login under \"\" was not found")
        else
          raise(::Dry::Schema::MissingMessageError, "Message template for :login under \"\" was not found") if !(dry_schema_value.is_a?(String))
        end
        values[:login] = dry_schema_value
        errors[:login] = [dry_schema_message_0] if dry_schema_message_0
      else
        errors[:login] = [raise(::Dry::Schema::MissingMessageError, "Message template for :login under \"\" was not found")]
      end
      values
    end
    private :dry_schema_0
  end
end
