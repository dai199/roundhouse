require_relative "../localized_contract"

module Users
  class SignupContract < LocalizedContract
    NAMESPACE = "users"

    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      dry_rule_schema_errors = ::Dry::Schema::Lowered.deep_dup(errors)
      if ::Dry::Schema::Lowered.error_at?(dry_rule_schema_errors, [:login])
        nil
      else
        dry_rule_0(values, errors, dry_rule_schema_errors)
      end
      ::Dry::Validation::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_0(input, values, errors)
      if input.key?("login") || input.key?(:login)
        dry_schema_value = if input.key?("login")
          input["login"]
        else
          input[:login]
        end
        dry_schema_value = dry_schema_value
        dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
          "Логин обязателен"
        else
          if !(dry_schema_value.is_a?(String))
            "Должно быть строкой"
          else
            "не больше #{dry_schema_token(3)} символов" if !(dry_schema_value.size <= 3)
          end
        end
        values[:login] = dry_schema_value
        errors[:login] = [dry_schema_message_0] if dry_schema_message_0
      else
        errors[:login] = ["Обязательный параметр"]
      end
      if input.key?("age") || input.key?(:age)
        dry_schema_value = if input.key?("age")
          input["age"]
        else
          input[:age]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
        dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
          "Должно быть заполнено"
        else
          "Должно быть целым числом" if !(dry_schema_value.is_a?(Integer))
        end
        values[:age] = dry_schema_value
        errors[:age] = [dry_schema_message_0] if dry_schema_message_0
      else
        errors[:age] = ["Обязательный параметр"]
      end
      if input.key?("tags") || input.key?(:tags)
        dry_schema_value = if input.key?("tags")
          input["tags"]
        else
          input[:tags]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
        dry_schema_message_0 = ("Должен быть массивом" if !(dry_schema_value.is_a?(Array)))
        if dry_schema_message_0
          values[:tags] = dry_schema_value
          errors[:tags] = [dry_schema_message_0]
        else
          dry_schema_members_0 = []
          dry_schema_member_errors_0 = {}
          dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
            dry_schema_member_0 = dry_schema_member_0
            dry_schema_message_1 = ("Должно быть строкой" if !(dry_schema_member_0.is_a?(String)))
            dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
            dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
          end
          values[:tags] = dry_schema_members_0
          if dry_schema_member_errors_0.empty?
            nil
          else
            errors[:tags] = dry_schema_member_errors_0
          end
        end
      end
      values
    end
    private :dry_schema_0

    def dry_rule_0(dry_rule_values, dry_rule_errors, dry_rule_schema_errors)
      ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:login], "Логин занят (#{dry_schema_token(%w[admin root])})") if dry_rule_values[:login] == "adm"
      ::Dry::Schema::Lowered.add_error(dry_rule_errors, [nil], "Регистрация закрыта") if dry_rule_values[:login] == "zzz"
      ::Dry::Schema::Lowered.add_error(dry_rule_errors, [:login], "тег  и #{$y}") if dry_rule_values[:login] == "hsh"
    end
    private :dry_rule_0
  end
end
