module Shop
  module Types
  end
end
