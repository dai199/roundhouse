module Shop
  class User
  end
end
