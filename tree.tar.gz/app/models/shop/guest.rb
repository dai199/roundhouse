module Shop
  class Guest
  end
end
