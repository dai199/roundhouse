require "bigdecimal"
require_relative "dry/validation/contract"

class UserContract < Dry::Validation::Contract
  KINDS = %w[admin guest].freeze

  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_1(input, values, errors)
    if input.key?("city") || input.key?(:city)
      dry_schema_value = if input.key?("city")
        input["city"]
      else
        input[:city]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:city] = dry_schema_value
      errors[:city] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:city] = ["is missing"]
    end
    if input.key?("zip") || input.key?(:zip)
      dry_schema_value = if input.key?("zip")
        input["zip"]
      else
        input[:zip]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(::Dry::Schema::Lowered.params_nil(dry_schema_value))
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be an integer" if !(dry_schema_value.is_a?(Integer)))
      end
      values[:zip] = dry_schema_value
      errors[:zip] = [dry_schema_message_0] if dry_schema_message_0
    end
    values
  end
  private :dry_schema_1

  def dry_schema_2(input, values, errors)
    if input.key?("t") || input.key?(:t)
      dry_schema_value = if input.key?("t")
        input["t"]
      else
        input[:t]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:t] = dry_schema_value
      errors[:t] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:t] = ["is missing"]
    end
    values
  end
  private :dry_schema_2

  def dry_schema_0(input, values, errors)
    if input.key?("name") || input.key?(:name)
      dry_schema_value = if input.key?("name")
        input["name"]
      else
        input[:name]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:name] = dry_schema_value
      errors[:name] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:name] = ["is missing"]
    end
    if input.key?("age") || input.key?(:age)
      dry_schema_value = if input.key?("age")
        input["age"]
      else
        input[:age]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
      dry_schema_message_0 = if !(dry_schema_value.is_a?(Integer))
        "must be an integer"
      else
        "must be greater than #{dry_schema_token(0)}" if !(dry_schema_value > 0)
      end
      values[:age] = dry_schema_value
      errors[:age] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:age] = ["is missing"]
    end
    if input.key?("nick") || input.key?(:nick)
      dry_schema_value = if input.key?("nick")
        input["nick"]
      else
        input[:nick]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_nil(dry_schema_value)
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = if !(dry_schema_value.is_a?(String))
          "must be a string"
        else
          if !(dry_schema_value.size >= 2)
            "size cannot be less than #{dry_schema_token(2)}"
          else
            "size cannot be greater than #{dry_schema_token(5)}" if !(dry_schema_value.size <= 5)
          end
        end
      end
      values[:nick] = dry_schema_value
      errors[:nick] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("ok") || input.key?(:ok)
      dry_schema_value = if input.key?("ok")
        input["ok"]
      else
        input[:ok]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_bool(dry_schema_value)
      dry_schema_message_0 = ("must be boolean" if !(dry_schema_value == true || dry_schema_value == false))
      values[:ok] = dry_schema_value
      errors[:ok] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("ids") || input.key?(:ids)
      dry_schema_value = if input.key?("ids")
        input["ids"]
      else
        input[:ids]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:ids] = dry_schema_value
        errors[:ids] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = ::Dry::Schema::Lowered.params_integer(dry_schema_member_0)
          dry_schema_message_1 = ("must be an integer" if !(dry_schema_member_0.is_a?(Integer)))
          dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
          dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
        end
        values[:ids] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:ids] = dry_schema_member_errors_0
        end
      end
    end
    if input.key?("meta") || input.key?(:meta)
      dry_schema_value = if input.key?("meta")
        input["meta"]
      else
        input[:meta]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = ("must be #{Hash}" if !(dry_schema_value.is_a?(Hash)))
      values[:meta] = dry_schema_value
      errors[:meta] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("addr") || input.key?(:addr)
      dry_schema_value = if input.key?("addr")
        input["addr"]
      else
        input[:addr]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_hash(dry_schema_value)
      dry_schema_message_0 = ("must be a hash" if !(dry_schema_value.is_a?(Hash)))
      if dry_schema_message_0
        values[:addr] = dry_schema_value
        errors[:addr] = [dry_schema_message_0]
      else
        dry_schema_values_0 = {}
        dry_schema_errors_0 = {}
        dry_schema_1(dry_schema_value, dry_schema_values_0, dry_schema_errors_0)
        values[:addr] = dry_schema_values_0
        if dry_schema_errors_0.empty?
          nil
        else
          errors[:addr] = dry_schema_errors_0
        end
      end
    end
    if input.key?("tags") || input.key?(:tags)
      dry_schema_value = if input.key?("tags")
        input["tags"]
      else
        input[:tags]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:tags] = dry_schema_value
        errors[:tags] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = ::Dry::Schema::Lowered.params_hash(dry_schema_member_0)
          dry_schema_message_1 = ("must be a hash" if !(dry_schema_member_0.is_a?(Hash)))
          if dry_schema_message_1
            dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
            dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1]
          else
            dry_schema_values_1 = {}
            dry_schema_errors_1 = {}
            dry_schema_2(dry_schema_member_0, dry_schema_values_1, dry_schema_errors_1)
            dry_schema_members_0[dry_schema_index_0] = dry_schema_values_1
            if dry_schema_errors_1.empty?
              nil
            else
              dry_schema_member_errors_0[dry_schema_index_0] = dry_schema_errors_1
            end
          end
        end
        values[:tags] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:tags] = dry_schema_member_errors_0
        end
      end
    end
    if input.key?("score") || input.key?(:score)
      dry_schema_value = if input.key?("score")
        input["score"]
      else
        input[:score]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_float(::Dry::Schema::Lowered.params_nil(dry_schema_value))
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a float" if !(dry_schema_value.is_a?(Float)))
      end
      values[:score] = dry_schema_value
      errors[:score] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("price") || input.key?(:price)
      dry_schema_value = if input.key?("price")
        input["price"]
      else
        input[:price]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_decimal(dry_schema_value)
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a decimal" if !(dry_schema_value.is_a?(BigDecimal))
      end
      values[:price] = dry_schema_value
      errors[:price] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("born") || input.key?(:born)
      dry_schema_value = if input.key?("born")
        input["born"]
      else
        input[:born]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_date(::Dry::Schema::Lowered.params_nil(dry_schema_value))
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a date" if !(dry_schema_value.is_a?(Date)))
      end
      values[:born] = dry_schema_value
      errors[:born] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("kind") || input.key?(:kind)
      dry_schema_value = if input.key?("kind")
        input["kind"]
      else
        input[:kind]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(dry_schema_value.is_a?(String))
        "must be a string"
      else
        if !(KINDS.include?(dry_schema_value))
          if KINDS.is_a?(Range)
            "must be one of: #{KINDS.first} - #{KINDS.last}"
          else
            "must be one of: #{dry_schema_token(KINDS)}"
          end
        end
      end
      values[:kind] = dry_schema_value
      errors[:kind] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("email") || input.key?(:email)
      dry_schema_value = if input.key?("email")
        input["email"]
      else
        input[:email]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_nil(dry_schema_value)
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = if !(dry_schema_value.is_a?(String))
          "must be a string"
        else
          "is in invalid format" if !(!(dry_schema_value.nil?) && /@/.match?(dry_schema_value))
        end
      end
      values[:email] = dry_schema_value
      errors[:email] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("count") || input.key?(:count)
      dry_schema_value = if input.key?("count")
        input["count"]
      else
        input[:count]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a number" if !(::Dry::Schema::Lowered.number?(dry_schema_value)))
      end
      values[:count] = dry_schema_value
      errors[:count] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("pair") || input.key?(:pair)
      dry_schema_value = if input.key?("pair")
        input["pair"]
      else
        input[:pair]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = if !(dry_schema_value.is_a?(Array))
        "must be an array"
      else
        if !(::Dry::Schema::Lowered.size?(2, dry_schema_value))
          if dry_schema_value.is_a?(String)
            "length must be #{dry_schema_token(2)}"
          else
            if dry_schema_value.is_a?(Range)
              "size must be #{dry_schema_token(2)}"
            else
              "size must be #{dry_schema_token(2)}"
            end
          end
        end
      end
      values[:pair] = dry_schema_value
      errors[:pair] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("level") || input.key?(:level)
      dry_schema_value = if input.key?("level")
        input["level"]
      else
        input[:level]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        if !(dry_schema_value.is_a?(Integer))
          "must be an integer"
        else
          if !(!(dry_schema_value < 1))
            "must be greater than or equal to #{dry_schema_token(1)}"
          else
            "must be less than #{dry_schema_token(10)}" if !(dry_schema_value < 10)
          end
        end
      end
      values[:level] = dry_schema_value
      errors[:level] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("range") || input.key?(:range)
      dry_schema_value = if input.key?("range")
        input["range"]
      else
        input[:range]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
      dry_schema_message_0 = if !(dry_schema_value.is_a?(Integer))
        "must be an integer"
      else
        "must be one of: #{(1..3).first} - #{(1..3).last}" if !((1..3).include?(dry_schema_value))
      end
      values[:range] = dry_schema_value
      errors[:range] = [dry_schema_message_0] if dry_schema_message_0
    end
    values
  end
  private :dry_schema_0
end
