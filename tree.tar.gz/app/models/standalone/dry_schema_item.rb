module Standalone
  class DrySchemaItem
    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      ::Dry::Schema::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_0(input, values, errors)
      if input.key?("sku") || input.key?(:sku)
        dry_schema_value = if input.key?("sku")
          input["sku"]
        else
          input[:sku]
        end
        dry_schema_value = dry_schema_value
        dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
          "must be filled"
        else
          "must be a string" if !(dry_schema_value.is_a?(String))
        end
        values[:sku] = dry_schema_value
        errors[:sku] = [dry_schema_message_0] if dry_schema_message_0
      else
        errors[:sku] = ["is missing"]
      end
      if input.key?("qty") || input.key?(:qty)
        dry_schema_value = if input.key?("qty")
          input["qty"]
        else
          input[:qty]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
        dry_schema_message_0 = if !(dry_schema_value.is_a?(Integer))
          "must be an integer"
        else
          "must be greater than #{dry_schema_token(0)}" if !(dry_schema_value > 0)
        end
        values[:qty] = dry_schema_value
        errors[:qty] = [dry_schema_message_0] if dry_schema_message_0
      end
      values
    end
    private :dry_schema_0
  end
end
