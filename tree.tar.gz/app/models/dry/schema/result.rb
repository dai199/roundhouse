module Dry
  module Schema
    class Result
      def initialize(values, errors)
        @values = values
        @errors = errors
      end
      private :initialize

      def success?
        @errors.empty?
      end

      def failure?
        !(@errors.empty?)
      end

      def to_h
        @values
      end

      def [](key)
        @values[key]
      end

      def errors
        ::Dry::Validation::MessageSet.new(@errors)
      end
    end
  end
end
