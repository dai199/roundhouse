module Dry
  module Schema
    class MissingMessageError < StandardError
    end
  end
end
