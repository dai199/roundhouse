require "bigdecimal"
module Dry
  module Schema
    module Lowered
      def self.params_nil(value)
        if value == ""
          nil
        else
          value
        end
      end

      def self.add_error(errors, path, text)
        node = errors
        path[0...-1].each { |key| node = node[key] ||= {} }
        (node[path.last] ||= []) << text
        errors
      end

      def self.error_at?(errors, path)
        node = errors
        path.each do |key|
          return true if node.is_a?(Array)
          if node.is_a?(Hash) && node.key?(key)
            nil
          else
            return false
          end
          node = node[key]
        end
        true
      end

      def self.key_at?(values, path)
        node = values
        path.each do |key|
          if node.is_a?(Hash) && node.key?(key)
            nil
          else
            return false
          end
          node = node[key]
        end
        true
      end

      def self.deep_dup(errors)
        errors.transform_values { |value| if value.is_a?(Hash)
          deep_dup(value)
        else
          value.dup
        end }
      end

      def self.coerce_string(value)
        begin
          String(value)
        rescue ArgumentError, TypeError
          value
        end
      end

      def self.coerce_integer(value)
        begin
          Integer(value)
        rescue ArgumentError, TypeError, FloatDomainError
          value
        end
      end

      def self.coerce_float(value)
        begin
          Float(value)
        rescue ArgumentError, TypeError
          value
        end
      end

      def self.params_integer(value)
        begin
          if value.is_a?(String)
            Integer(value, 10)
          else
            Integer(value)
          end
        rescue ArgumentError, TypeError, FloatDomainError
          value
        end
      end

      def self.params_float(value)
        begin
          Float(value)
        rescue ArgumentError, TypeError
          value
        end
      end

      def self.params_decimal(value)
        json_decimal(value)
      end

      def self.params_bool(value)
        text = value.to_s
        return true if %w[1 on On ON t true True TRUE T y yes Yes YES Y].include?(text)
        return false if %w[0 off Off OFF f false False FALSE F n no No NO N].include?(text)
        value
      end

      def self.params_date(value)
        json_date(value)
      end

      def self.params_hash(value)
        if value == ""
          {}
        else
          value
        end
      end

      def self.params_array(value)
        if value == ""
          []
        else
          value
        end
      end

      def self.json_decimal(value)
        begin
          Float(value)
          case value
          when Float
            BigDecimal(value, 0)
          when String
            BigDecimal(value)
          when BigDecimal
            value
          else
            BigDecimal(value)
          end
        rescue ArgumentError, TypeError
          value
        end
      end

      def self.json_date(value)
        begin
          if value.is_a?(String)
            nil
          else
            return value
          end
          Date.parse(value)
        rescue ArgumentError, RangeError
          value
        end
      end

      def self.filled?(value)
        case value
        when String
          !(value.empty?)
        when Array
          !(value.empty?)
        when Hash
          !(value.empty?)
        when nil
          false
        else
          true
        end
      end

      def self.number?(value)
        begin
          Float(value)
          true
        rescue ArgumentError, TypeError
          false
        end
      end

      def self.size?(size, value)
        if size.is_a?(Integer)
          size.equal?(value.size)
        else
          size.include?(value.size)
        end
      end
    end
  end
end
