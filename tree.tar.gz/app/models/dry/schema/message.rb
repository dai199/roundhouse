module Dry
  module Schema
    class Message
      def initialize(text, path)
        @text = text
        @path = path
      end
      private :initialize

      def text
        @text
      end

      def path
        @path
      end

      def to_s
        @text
      end
    end
  end
end
