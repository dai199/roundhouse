module Dry
  module Validation
    class Contract
    end
  end
end
