module Dry
  module Validation
    class MissingMessageError < StandardError
    end
  end
end
