module Dry
  module Validation
    class MessageSet
      def initialize(errors)
        @errors = errors
      end
      private :initialize

      def to_h
        @errors
      end

      def to_hash
        @errors
      end

      def empty?
        @errors.empty?
      end

      def messages
        ::Dry::Validation::MessageSet.flatten(@errors, [])
      end

      def each(&block)
        messages.each(&block)
      end

      def map(&block)
        messages.map(&block)
      end

      def count
        messages.size
      end

      def self.flatten(errors, path)
        out = []
        errors.each do |key, value|
          if value.is_a?(Hash)
            out.concat(flatten(value, path + [key]))
          else
            value.each { |text| out << ::Dry::Schema::Message.new(text, path + [key]) }
          end
        end
        out
      end
    end
  end
end
