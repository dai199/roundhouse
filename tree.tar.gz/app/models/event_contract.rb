require "bigdecimal"
require_relative "dry/validation/contract"

class EventContract < Dry::Validation::Contract
  class DrySchemaIndexSchema
    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      ::Dry::Schema::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_0(input, values, errors)
      if input.key?("fields") || input.key?(:fields)
        dry_schema_value = if input.key?("fields")
          input["fields"]
        else
          input[:fields]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
        dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
        if dry_schema_message_0
          values[:fields] = dry_schema_value
          errors[:fields] = [dry_schema_message_0]
        else
          dry_schema_members_0 = []
          dry_schema_member_errors_0 = {}
          dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
            dry_schema_member_0 = dry_schema_member_0
            dry_schema_message_1 = ("must be a string" if !(dry_schema_member_0.is_a?(String)))
            dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
            dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
          end
          values[:fields] = dry_schema_members_0
          if dry_schema_member_errors_0.empty?
            nil
          else
            errors[:fields] = dry_schema_member_errors_0
          end
        end
      end
      if input.key?("object_ids") || input.key?(:object_ids)
        dry_schema_value = if input.key?("object_ids")
          input["object_ids"]
        else
          input[:object_ids]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
        dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
        if dry_schema_message_0
          values[:object_ids] = dry_schema_value
          errors[:object_ids] = [dry_schema_message_0]
        else
          dry_schema_members_0 = []
          dry_schema_member_errors_0 = {}
          dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
            dry_schema_member_0 = ::Dry::Schema::Lowered.params_integer(dry_schema_member_0)
            dry_schema_message_1 = ("must be an integer" if !(dry_schema_member_0.is_a?(Integer)))
            dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
            dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
          end
          values[:object_ids] = dry_schema_members_0
          if dry_schema_member_errors_0.empty?
            nil
          else
            errors[:object_ids] = dry_schema_member_errors_0
          end
        end
      end
      values
    end
    private :dry_schema_0
  end
  IndexSchema = ::EventContract::DrySchemaIndexSchema.new

  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_1(input, values, errors)
    if input.key?("fields") || input.key?(:fields)
      dry_schema_value = if input.key?("fields")
        input["fields"]
      else
        input[:fields]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:fields] = dry_schema_value
        errors[:fields] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = dry_schema_member_0
          dry_schema_message_1 = ("must be a string" if !(dry_schema_member_0.is_a?(String)))
          dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
          dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
        end
        values[:fields] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:fields] = dry_schema_member_errors_0
        end
      end
    end
    if input.key?("object_ids") || input.key?(:object_ids)
      dry_schema_value = if input.key?("object_ids")
        input["object_ids"]
      else
        input[:object_ids]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:object_ids] = dry_schema_value
        errors[:object_ids] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = ::Dry::Schema::Lowered.params_integer(dry_schema_member_0)
          dry_schema_message_1 = ("must be an integer" if !(dry_schema_member_0.is_a?(Integer)))
          dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
          dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
        end
        values[:object_ids] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:object_ids] = dry_schema_member_errors_0
        end
      end
    end
    values
  end
  private :dry_schema_1

  def dry_schema_0(input, values, errors)
    if input.key?("id") || input.key?(:id)
      dry_schema_value = if input.key?("id")
        input["id"]
      else
        input[:id]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be an integer" if !(dry_schema_value.is_a?(Integer))
      end
      values[:id] = dry_schema_value
      errors[:id] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:id] = ["is missing"]
    end
    if input.key?("on") || input.key?(:on)
      dry_schema_value = if input.key?("on")
        input["on"]
      else
        input[:on]
      end
      dry_schema_value = ::Dry::Schema::Lowered.json_date(dry_schema_value)
      dry_schema_message_0 = ("must be a date" if !(dry_schema_value.is_a?(Date)))
      values[:on] = dry_schema_value
      errors[:on] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("ratio") || input.key?(:ratio)
      dry_schema_value = if input.key?("ratio")
        input["ratio"]
      else
        input[:ratio]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a float" if !(dry_schema_value.is_a?(Float)))
      end
      values[:ratio] = dry_schema_value
      errors[:ratio] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("amount") || input.key?(:amount)
      dry_schema_value = if input.key?("amount")
        input["amount"]
      else
        input[:amount]
      end
      dry_schema_value = ::Dry::Schema::Lowered.json_decimal(dry_schema_value)
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a decimal" if !(dry_schema_value.is_a?(BigDecimal)))
      end
      values[:amount] = dry_schema_value
      errors[:amount] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("index") || input.key?(:index)
      dry_schema_value = if input.key?("index")
        input["index"]
      else
        input[:index]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = ("must be a hash" if !(dry_schema_value.is_a?(Hash)))
      if dry_schema_message_0
        values[:index] = dry_schema_value
        errors[:index] = [dry_schema_message_0]
      else
        dry_schema_values_0 = {}
        dry_schema_errors_0 = {}
        dry_schema_1(dry_schema_value, dry_schema_values_0, dry_schema_errors_0)
        values[:index] = dry_schema_values_0
        if dry_schema_errors_0.empty?
          nil
        else
          errors[:index] = dry_schema_errors_0
        end
      end
    else
      errors[:index] = ["is missing"]
    end
    values
  end
  private :dry_schema_0
end
