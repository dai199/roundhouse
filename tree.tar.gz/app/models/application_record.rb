require_relative "../../runtime/active_record"

class ApplicationRecord < ActiveRecord::Base
#<SPINEL_SOURCE>app/app/models/application_record.rb:2
  def self.abstract?
    true
  end

  def to_gid_param
    GlobalID.param("ApplicationRecord", self.id)
  end

  def to_gid_uri
    GlobalID.uri("ApplicationRecord", self.id)
  end

  def self._preload_dispatch(records, name, nested)
    nil
  end

  def self._eager_dispatch(records, name, filter)
    nil
  end

  def self.preload_associations(records, specs)
    return if records.length == 0
    specs.each do |spec|
      if spec.is_a?(Hash)
        spec.each do |name, nested|
          if nested.is_a?(ActiveRecord::EagerFilter)
            _eager_dispatch(records, name, nested)
          else
            _preload_dispatch(records, name, nested)
          end
        end
      else
        if spec.is_a?(Array)
          preload_associations(records, spec)
        else
          _preload_dispatch(records, spec, nil) if !(spec.nil?)
        end
      end
    end
    nil
  end
end
