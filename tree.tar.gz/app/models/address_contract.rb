require_relative "dry/validation/contract"

class AddressContract < Dry::Validation::Contract
  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_0(input, values, errors)
    if input.key?("city") || input.key?(:city)
      dry_schema_value = if input.key?("city")
        input["city"]
      else
        input[:city]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:city] = dry_schema_value
      errors[:city] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:city] = ["is missing"]
    end
    values
  end
  private :dry_schema_0
end
