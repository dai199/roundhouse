require_relative "dry/validation/contract"

class ChainContract < Dry::Validation::Contract
  class DrySchemaContext
    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      ::Dry::Schema::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_0(input, values, errors)
      if input.key?("n") || input.key?(:n)
        dry_schema_value = if input.key?("n")
          input["n"]
        else
          input[:n]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
        dry_schema_message_0 = ("must be an integer" if !(dry_schema_value.is_a?(Integer)))
        values[:n] = dry_schema_value
        errors[:n] = [dry_schema_message_0] if dry_schema_message_0
      end
      values
    end
    private :dry_schema_0
  end
  Context = ::ChainContract::DrySchemaContext.new

  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_1(input, values, errors)
    if input.key?("n") || input.key?(:n)
      dry_schema_value = if input.key?("n")
        input["n"]
      else
        input[:n]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
      dry_schema_message_0 = ("must be an integer" if !(dry_schema_value.is_a?(Integer)))
      values[:n] = dry_schema_value
      errors[:n] = [dry_schema_message_0] if dry_schema_message_0
    end
    values
  end
  private :dry_schema_1

  def dry_schema_2(input, values, errors)
    if input.key?(:k)
      dry_schema_value = input[:k]
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:k] = dry_schema_value
      errors[:k] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:k] = ["is missing"]
    end
    values
  end
  private :dry_schema_2

  def dry_schema_0(input, values, errors)
    if input.key?(:v)
      dry_schema_value = input[:v]
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = nil
      values[:v] = dry_schema_value
      errors[:v] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:v] = ["is missing"]
    end
    if input.key?(:c)
      dry_schema_value = input[:c]
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = ("must be a hash" if !(dry_schema_value.is_a?(Hash)))
      if dry_schema_message_0
        values[:c] = dry_schema_value
        errors[:c] = [dry_schema_message_0]
      else
        dry_schema_values_0 = {}
        dry_schema_errors_0 = {}
        dry_schema_1(dry_schema_value, dry_schema_values_0, dry_schema_errors_0)
        values[:c] = dry_schema_values_0
        if dry_schema_errors_0.empty?
          nil
        else
          errors[:c] = dry_schema_errors_0
        end
      end
    end
    if input.key?(:f)
      dry_schema_value = input[:f]
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(dry_schema_value.is_a?(Hash))
        "must be a hash"
      else
        "must be filled" if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
      end
      if dry_schema_message_0
        values[:f] = dry_schema_value
        errors[:f] = [dry_schema_message_0]
      else
        dry_schema_values_0 = {}
        dry_schema_errors_0 = {}
        dry_schema_2(dry_schema_value, dry_schema_values_0, dry_schema_errors_0)
        values[:f] = dry_schema_values_0
        if dry_schema_errors_0.empty?
          nil
        else
          errors[:f] = dry_schema_errors_0
        end
      end
    end
    values
  end
  private :dry_schema_0
end
