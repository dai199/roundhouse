require_relative "tags_base_contract"

class ShapesContract < TagsBaseContract
  MIN = 2

  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_1(input, values, errors)
    if input.key?("title") || input.key?(:title)
      dry_schema_value = if input.key?("title")
        input["title"]
      else
        input[:title]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:title] = dry_schema_value
      errors[:title] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:title] = ["is missing"]
    end
    values
  end
  private :dry_schema_1

  def dry_schema_2(input, values, errors)
    if input.key?("city") || input.key?(:city)
      dry_schema_value = if input.key?("city")
        input["city"]
      else
        input[:city]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:city] = dry_schema_value
      errors[:city] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:city] = ["is missing"]
    end
    values
  end
  private :dry_schema_2

  def dry_schema_0(input, values, errors)
    if input.key?("tags") || input.key?(:tags)
      dry_schema_value = if input.key?("tags")
        input["tags"]
      else
        input[:tags]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:tags] = dry_schema_value
        errors[:tags] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = dry_schema_member_0
          dry_schema_message_1 = nil
          if dry_schema_message_1
            dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
            dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1]
          else
            dry_schema_values_1 = {}
            dry_schema_errors_1 = {}
            dry_schema_1(dry_schema_member_0, dry_schema_values_1, dry_schema_errors_1)
            dry_schema_members_0[dry_schema_index_0] = dry_schema_values_1
            if dry_schema_errors_1.empty?
              nil
            else
              dry_schema_member_errors_0[dry_schema_index_0] = dry_schema_errors_1
            end
          end
        end
        values[:tags] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:tags] = dry_schema_member_errors_0
        end
      end
    end
    if input.key?("code") || input.key?(:code)
      dry_schema_value = if input.key?("code")
        input["code"]
      else
        input[:code]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = ("must be a string" if !(dry_schema_value.is_a?(String)))
      values[:code] = dry_schema_value
      errors[:code] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("nick") || input.key?(:nick)
      dry_schema_value = if input.key?("nick")
        input["nick"]
      else
        input[:nick]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(dry_schema_value.is_a?(String))
        "must be a string"
      else
        if !(dry_schema_value.size >= MIN)
          if MIN.is_a?(Range)
            "size cannot be less than #{num}"
          else
            "size cannot be less than #{dry_schema_token(MIN)}"
          end
        end
      end
      values[:nick] = dry_schema_value
      errors[:nick] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("owner") || input.key?(:owner)
      dry_schema_value = if input.key?("owner")
        input["owner"]
      else
        input[:owner]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = ("must be #{::Shop::User}" + " or " + "must be #{::Shop::Guest}" if !(dry_schema_value.is_a?(::Shop::User) || dry_schema_value.is_a?(::Shop::Guest)))
      values[:owner] = dry_schema_value
      errors[:owner] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("address") || input.key?(:address)
      dry_schema_value = if input.key?("address")
        input["address"]
      else
        input[:address]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_hash(dry_schema_value)
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a hash" if !(dry_schema_value.is_a?(Hash))
      end
      if dry_schema_message_0
        values[:address] = dry_schema_value
        errors[:address] = [dry_schema_message_0]
      else
        dry_schema_values_0 = {}
        dry_schema_errors_0 = {}
        dry_schema_2(dry_schema_value, dry_schema_values_0, dry_schema_errors_0)
        values[:address] = dry_schema_values_0
        if dry_schema_errors_0.empty?
          nil
        else
          errors[:address] = dry_schema_errors_0
        end
      end
    end
    values
  end
  private :dry_schema_0
end
