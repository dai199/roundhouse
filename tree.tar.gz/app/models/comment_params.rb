class CommentParams
#<SPINEL_SOURCE>app/app/controllers/comments_controller.rb:26
  def initialize
    @commenter_provided = false
    @body_provided = false
    @rh_multiparameter_unsupported = false
    @rh_multiparameter_fields = Params.no_fields
    @commenter = ""
    @body = ""
  end
  private :initialize

  def commenter
    @commenter
  end

  def commenter=(value)
    @commenter = value
  end

  def commenter_provided
    @commenter_provided
  end

  def commenter_provided=(value)
    @commenter_provided = value
  end

  def body
    @body
  end

  def body=(value)
    @body = value
  end

  def body_provided
    @body_provided
  end

  def body_provided=(value)
    @body_provided = value
  end

  def rh_multiparameter_fields
    @rh_multiparameter_fields
  end

  def rh_multiparameter_fields=(value)
    @rh_multiparameter_fields = value
  end

  def rh_multiparameter_unsupported
    @rh_multiparameter_unsupported
  end

  def rh_multiparameter_unsupported=(value)
    @rh_multiparameter_unsupported = value
  end

  def self.from_raw(params)
    sub = Params.sub(params, "comment")
    instance = CommentParams.new
    instance.commenter_provided = Params.scalar_provided(sub, "commenter")
    instance.commenter = Params.scalar(sub, "commenter")
    instance.body_provided = Params.scalar_provided(sub, "body")
    instance.body = Params.scalar(sub, "body")
    instance.rh_multiparameter_fields = Params.multiparameter_fields(sub, ["commenter", "body"])
    instance.rh_multiparameter_unsupported = Params.multiparameter_unsupported(sub, ["commenter", "body"])
    instance
  end

  def [](key)
    case key
    when :commenter
      @commenter
    when :body
      @body
    end
  end

  def to_h
    { "commenter" => @commenter, "body" => @body }
  end
end
