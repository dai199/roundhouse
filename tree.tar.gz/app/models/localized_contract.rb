require_relative "dry/validation/contract"

class LocalizedContract < Dry::Validation::Contract
end
