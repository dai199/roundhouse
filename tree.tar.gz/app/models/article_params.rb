class ArticleParams
#<SPINEL_SOURCE>app/app/controllers/articles_controller.rb:68
  def initialize
    @title_provided = false
    @body_provided = false
    @rh_multiparameter_unsupported = false
    @rh_multiparameter_fields = Params.no_fields
    @title = ""
    @body = ""
  end
  private :initialize

  def title
    @title
  end

  def title=(value)
    @title = value
  end

  def title_provided
    @title_provided
  end

  def title_provided=(value)
    @title_provided = value
  end

  def body
    @body
  end

  def body=(value)
    @body = value
  end

  def body_provided
    @body_provided
  end

  def body_provided=(value)
    @body_provided = value
  end

  def rh_multiparameter_fields
    @rh_multiparameter_fields
  end

  def rh_multiparameter_fields=(value)
    @rh_multiparameter_fields = value
  end

  def rh_multiparameter_unsupported
    @rh_multiparameter_unsupported
  end

  def rh_multiparameter_unsupported=(value)
    @rh_multiparameter_unsupported = value
  end

  def self.from_raw(params)
    sub = Params.sub(params, "article")
    instance = ArticleParams.new
    instance.title_provided = Params.scalar_provided(sub, "title")
    instance.title = Params.scalar(sub, "title")
    instance.body_provided = Params.scalar_provided(sub, "body")
    instance.body = Params.scalar(sub, "body")
    instance.rh_multiparameter_fields = Params.multiparameter_fields(sub, ["title", "body"])
    instance.rh_multiparameter_unsupported = Params.multiparameter_unsupported(sub, ["title", "body"])
    instance
  end

  def [](key)
    case key
    when :title
      @title
    when :body
      @body
    end
  end

  def to_h
    { "title" => @title, "body" => @body }
  end
end
