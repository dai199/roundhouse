require_relative "dry/validation/contract"

class StrictContract < Dry::Validation::Contract
  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_0(input, values, errors)
    if input.key?(:a)
      dry_schema_value = input[:a]
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be an integer" if !(dry_schema_value.is_a?(Integer))
      end
      values[:a] = dry_schema_value
      errors[:a] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:a] = ["is missing"]
    end
    if input.key?(:b)
      dry_schema_value = input[:b]
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a string" if !(dry_schema_value.is_a?(String)))
      end
      values[:b] = dry_schema_value
      errors[:b] = [dry_schema_message_0] if dry_schema_message_0
    end
    values
  end
  private :dry_schema_0
end
