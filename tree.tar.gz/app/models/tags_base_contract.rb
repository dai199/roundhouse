require_relative "dry/validation/contract"

class TagsBaseContract < Dry::Validation::Contract
  class DrySchemaTagSchema
    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      ::Dry::Schema::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_0(input, values, errors)
      if input.key?("title") || input.key?(:title)
        dry_schema_value = if input.key?("title")
          input["title"]
        else
          input[:title]
        end
        dry_schema_value = dry_schema_value
        dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
          "must be filled"
        else
          "must be a string" if !(dry_schema_value.is_a?(String))
        end
        values[:title] = dry_schema_value
        errors[:title] = [dry_schema_message_0] if dry_schema_message_0
      else
        errors[:title] = ["is missing"]
      end
      values
    end
    private :dry_schema_0
  end
  TagSchema = ::TagsBaseContract::DrySchemaTagSchema.new
end
