require_relative "standalone/dry_schema_item"

module Standalone
  Item = ::Standalone::DrySchemaItem.new
end
