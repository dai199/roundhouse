require_relative "dry/validation/contract"

class TypedContract < Dry::Validation::Contract
  class DrySchemaLine
    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      ::Dry::Schema::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_0(input, values, errors)
      if input.key?("sku") || input.key?(:sku)
        dry_schema_value = if input.key?("sku")
          input["sku"]
        else
          input[:sku]
        end
        dry_schema_value = dry_schema_value
        dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
          "must be filled"
        else
          "must be a string" if !(dry_schema_value.is_a?(String))
        end
        values[:sku] = dry_schema_value
        errors[:sku] = [dry_schema_message_0] if dry_schema_message_0
      else
        errors[:sku] = ["is missing"]
      end
      values
    end
    private :dry_schema_0
  end
  Line = ::TypedContract::DrySchemaLine.new
  class DrySchemaOrder
    def call(input)
      if input.is_a?(Hash)
        nil
      else
        raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
      end
      values = {}
      errors = {}
      dry_schema_0(input, values, errors)
      ::Dry::Schema::Result.new(values, errors)
    end

    def dry_schema_token(value)
      if value.is_a?(Array)
        value.join(", ")
      else
        value
      end
    end
    private :dry_schema_token

    def dry_schema_1(input, values, errors)
      if input.key?("sku") || input.key?(:sku)
        dry_schema_value = if input.key?("sku")
          input["sku"]
        else
          input[:sku]
        end
        dry_schema_value = dry_schema_value
        dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
          "must be filled"
        else
          "must be a string" if !(dry_schema_value.is_a?(String))
        end
        values[:sku] = dry_schema_value
        errors[:sku] = [dry_schema_message_0] if dry_schema_message_0
      else
        errors[:sku] = ["is missing"]
      end
      values
    end
    private :dry_schema_1

    def dry_schema_0(input, values, errors)
      if input.key?("lines") || input.key?(:lines)
        dry_schema_value = if input.key?("lines")
          input["lines"]
        else
          input[:lines]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
        dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
        if dry_schema_message_0
          values[:lines] = dry_schema_value
          errors[:lines] = [dry_schema_message_0]
        else
          dry_schema_members_0 = []
          dry_schema_member_errors_0 = {}
          dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
            dry_schema_member_0 = dry_schema_member_0
            dry_schema_message_1 = nil
            if dry_schema_message_1
              dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
              dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1]
            else
              dry_schema_values_1 = {}
              dry_schema_errors_1 = {}
              dry_schema_1(dry_schema_member_0, dry_schema_values_1, dry_schema_errors_1)
              dry_schema_members_0[dry_schema_index_0] = dry_schema_values_1
              if dry_schema_errors_1.empty?
                nil
              else
                dry_schema_member_errors_0[dry_schema_index_0] = dry_schema_errors_1
              end
            end
          end
          values[:lines] = dry_schema_members_0
          if dry_schema_member_errors_0.empty?
            nil
          else
            errors[:lines] = dry_schema_member_errors_0
          end
        end
      else
        errors[:lines] = ["is missing"]
      end
      if input.key?("note") || input.key?(:note)
        dry_schema_value = if input.key?("note")
          input["note"]
        else
          input[:note]
        end
        dry_schema_value = ::Dry::Schema::Lowered.params_nil(dry_schema_value)
        dry_schema_message_0 = nil
        if dry_schema_value.nil?
          nil
        else
          dry_schema_message_0 = ("must be a string" if !(dry_schema_value.is_a?(String)))
        end
        values[:note] = dry_schema_value
        errors[:note] = [dry_schema_message_0] if dry_schema_message_0
      end
      values
    end
    private :dry_schema_0
  end
  Order = ::TypedContract::DrySchemaOrder.new

  def call(input)
    if input.is_a?(Hash)
      nil
    else
      raise(ArgumentError, "Input must be a Hash. #{input.class} was given.")
    end
    values = {}
    errors = {}
    dry_schema_0(input, values, errors)
    ::Dry::Validation::Result.new(values, errors)
  end

  def dry_schema_token(value)
    if value.is_a?(Array)
      value.join(", ")
    else
      value
    end
  end
  private :dry_schema_token

  def dry_schema_1(input, values, errors)
    if input.key?("id") || input.key?(:id)
      dry_schema_value = if input.key?("id")
        input["id"]
      else
        input[:id]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_integer(dry_schema_value)
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be an integer" if !(dry_schema_value.is_a?(Integer))
      end
      values[:id] = dry_schema_value
      errors[:id] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:id] = ["is missing"]
    end
    values
  end
  private :dry_schema_1

  def dry_schema_3(input, values, errors)
    if input.key?("sku") || input.key?(:sku)
      dry_schema_value = if input.key?("sku")
        input["sku"]
      else
        input[:sku]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be a string" if !(dry_schema_value.is_a?(String))
      end
      values[:sku] = dry_schema_value
      errors[:sku] = [dry_schema_message_0] if dry_schema_message_0
    else
      errors[:sku] = ["is missing"]
    end
    values
  end
  private :dry_schema_3

  def dry_schema_2(input, values, errors)
    if input.key?("lines") || input.key?(:lines)
      dry_schema_value = if input.key?("lines")
        input["lines"]
      else
        input[:lines]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:lines] = dry_schema_value
        errors[:lines] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = dry_schema_member_0
          dry_schema_message_1 = nil
          if dry_schema_message_1
            dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
            dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1]
          else
            dry_schema_values_1 = {}
            dry_schema_errors_1 = {}
            dry_schema_3(dry_schema_member_0, dry_schema_values_1, dry_schema_errors_1)
            dry_schema_members_0[dry_schema_index_0] = dry_schema_values_1
            if dry_schema_errors_1.empty?
              nil
            else
              dry_schema_member_errors_0[dry_schema_index_0] = dry_schema_errors_1
            end
          end
        end
        values[:lines] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:lines] = dry_schema_member_errors_0
        end
      end
    else
      errors[:lines] = ["is missing"]
    end
    if input.key?("note") || input.key?(:note)
      dry_schema_value = if input.key?("note")
        input["note"]
      else
        input[:note]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_nil(dry_schema_value)
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a string" if !(dry_schema_value.is_a?(String)))
      end
      values[:note] = dry_schema_value
      errors[:note] = [dry_schema_message_0] if dry_schema_message_0
    end
    values
  end
  private :dry_schema_2

  def dry_schema_0(input, values, errors)
    if input.key?("n") || input.key?(:n)
      dry_schema_value = if input.key?("n")
        input["n"]
      else
        input[:n]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = ("must be a number" if !(::Dry::Schema::Lowered.number?(dry_schema_value)))
      values[:n] = dry_schema_value
      errors[:n] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("i") || input.key?(:i)
      dry_schema_value = if input.key?("i")
        input["i"]
      else
        input[:i]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(dry_schema_value.is_a?(Integer))
        "must be an integer"
      else
        "must be greater than #{dry_schema_token(0)}" if !(dry_schema_value > 0)
      end
      values[:i] = dry_schema_value
      errors[:i] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("on") || input.key?(:on)
      dry_schema_value = if input.key?("on")
        input["on"]
      else
        input[:on]
      end
      dry_schema_value = ::Dry::Schema::Lowered.json_date(dry_schema_value)
      dry_schema_message_0 = ("must be a date" if !(dry_schema_value.is_a?(Date)))
      values[:on] = dry_schema_value
      errors[:on] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("qty") || input.key?(:qty)
      dry_schema_value = if input.key?("qty")
        input["qty"]
      else
        input[:qty]
      end
      dry_schema_value = ::Dry::Schema::Lowered.coerce_integer(dry_schema_value)
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be an integer" if !(dry_schema_value.is_a?(Integer))
      end
      values[:qty] = dry_schema_value
      errors[:qty] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("ratio") || input.key?(:ratio)
      dry_schema_value = if input.key?("ratio")
        input["ratio"]
      else
        input[:ratio]
      end
      dry_schema_value = ::Dry::Schema::Lowered.coerce_float(::Dry::Schema::Lowered.params_nil(dry_schema_value))
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a float" if !(dry_schema_value.is_a?(Float)))
      end
      values[:ratio] = dry_schema_value
      errors[:ratio] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("label") || input.key?(:label)
      dry_schema_value = if input.key?("label")
        input["label"]
      else
        input[:label]
      end
      dry_schema_value = ::Dry::Schema::Lowered.coerce_string(dry_schema_value)
      dry_schema_message_0 = ("must be a string" if !(dry_schema_value.is_a?(String)))
      values[:label] = dry_schema_value
      errors[:label] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("device") || input.key?(:device)
      dry_schema_value = if input.key?("device")
        input["device"]
      else
        input[:device]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        if !(dry_schema_value.is_a?(String))
          "must be a string"
        else
          "must be one of: #{dry_schema_token(%w[desktop mobile])}" if !(%w[desktop mobile].include?(dry_schema_value))
        end
      end
      values[:device] = dry_schema_value
      errors[:device] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("state") || input.key?(:state)
      dry_schema_value = if input.key?("state")
        input["state"]
      else
        input[:state]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(dry_schema_value.is_a?(String))
        "must be a string"
      else
        "must be one of: #{dry_schema_token(["new", "done"])}" if !(["new", "done"].include?(dry_schema_value))
      end
      values[:state] = dry_schema_value
      errors[:state] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("flag") || input.key?(:flag)
      dry_schema_value = if input.key?("flag")
        input["flag"]
      else
        input[:flag]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = if !(::Dry::Schema::Lowered.filled?(dry_schema_value))
        "must be filled"
      else
        "must be boolean" if !(dry_schema_value == true || dry_schema_value == false)
      end
      values[:flag] = dry_schema_value
      errors[:flag] = [dry_schema_message_0] if dry_schema_message_0
    else
      values[:flag] = false
    end
    if input.key?("at") || input.key?(:at)
      dry_schema_value = if input.key?("at")
        input["at"]
      else
        input[:at]
      end
      dry_schema_value = dry_schema_value
      dry_schema_message_0 = nil
      if dry_schema_value.nil?
        nil
      else
        dry_schema_message_0 = ("must be a string" if !(dry_schema_value.is_a?(String)))
      end
      values[:at] = dry_schema_value
      errors[:at] = [dry_schema_message_0] if dry_schema_message_0
    end
    if input.key?("items") || input.key?(:items)
      dry_schema_value = if input.key?("items")
        input["items"]
      else
        input[:items]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = if !(dry_schema_value.is_a?(Array))
        "must be an array"
      else
        "size cannot be less than #{dry_schema_token(1)}" if !(dry_schema_value.size >= 1)
      end
      if dry_schema_message_0
        values[:items] = dry_schema_value
        errors[:items] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = ::Dry::Schema::Lowered.params_hash(dry_schema_member_0)
          dry_schema_message_1 = ("must be a hash" if !(dry_schema_member_0.is_a?(Hash)))
          if dry_schema_message_1
            dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
            dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1]
          else
            dry_schema_values_1 = {}
            dry_schema_errors_1 = {}
            dry_schema_1(dry_schema_member_0, dry_schema_values_1, dry_schema_errors_1)
            dry_schema_members_0[dry_schema_index_0] = dry_schema_values_1
            if dry_schema_errors_1.empty?
              nil
            else
              dry_schema_member_errors_0[dry_schema_index_0] = dry_schema_errors_1
            end
          end
        end
        values[:items] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:items] = dry_schema_member_errors_0
        end
      end
    end
    if input.key?("pairs") || input.key?(:pairs)
      dry_schema_value = if input.key?("pairs")
        input["pairs"]
      else
        input[:pairs]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:pairs] = dry_schema_value
        errors[:pairs] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = ::Dry::Schema::Lowered.params_array(dry_schema_member_0)
          dry_schema_message_1 = if !(dry_schema_member_0.is_a?(Array))
            "must be an array"
          else
            if !(::Dry::Schema::Lowered.size?(2, dry_schema_member_0))
              if dry_schema_member_0.is_a?(String)
                "length must be #{dry_schema_token(2)}"
              else
                if dry_schema_member_0.is_a?(Range)
                  "size must be #{dry_schema_token(2)}"
                else
                  "size must be #{dry_schema_token(2)}"
                end
              end
            end
          end
          dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
          dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
        end
        values[:pairs] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:pairs] = dry_schema_member_errors_0
        end
      end
    end
    if input.key?("codes") || input.key?(:codes)
      dry_schema_value = if input.key?("codes")
        input["codes"]
      else
        input[:codes]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_array(dry_schema_value)
      dry_schema_message_0 = ("must be an array" if !(dry_schema_value.is_a?(Array)))
      if dry_schema_message_0
        values[:codes] = dry_schema_value
        errors[:codes] = [dry_schema_message_0]
      else
        dry_schema_members_0 = []
        dry_schema_member_errors_0 = {}
        dry_schema_value.each_with_index do |dry_schema_member_0, dry_schema_index_0|
          dry_schema_member_0 = dry_schema_member_0
          dry_schema_message_1 = ("must be a string" if !(dry_schema_member_0.is_a?(String)))
          dry_schema_members_0[dry_schema_index_0] = dry_schema_member_0
          dry_schema_member_errors_0[dry_schema_index_0] = [dry_schema_message_1] if dry_schema_message_1
        end
        values[:codes] = dry_schema_members_0
        if dry_schema_member_errors_0.empty?
          nil
        else
          errors[:codes] = dry_schema_member_errors_0
        end
      end
    end
    if input.key?("order") || input.key?(:order)
      dry_schema_value = if input.key?("order")
        input["order"]
      else
        input[:order]
      end
      dry_schema_value = ::Dry::Schema::Lowered.params_hash(dry_schema_value)
      dry_schema_message_0 = ("must be a hash" if !(dry_schema_value.is_a?(Hash)))
      if dry_schema_message_0
        values[:order] = dry_schema_value
        errors[:order] = [dry_schema_message_0]
      else
        dry_schema_values_0 = {}
        dry_schema_errors_0 = {}
        dry_schema_2(dry_schema_value, dry_schema_values_0, dry_schema_errors_0)
        values[:order] = dry_schema_values_0
        if dry_schema_errors_0.empty?
          nil
        else
          errors[:order] = dry_schema_errors_0
        end
      end
    end
    values
  end
  private :dry_schema_0
end
