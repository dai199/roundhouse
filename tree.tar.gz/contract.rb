require_relative "boot"
def f(value)
  value.class
end
