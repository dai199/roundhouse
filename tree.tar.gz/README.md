# Roundhouse → spinel

Transpiled from a Rails source app by [Roundhouse](https://roundhouse-rb.dev/).

Running it serves the blog on http://localhost:3000 (set `PORT` to override), with live Turbo Stream updates over the `/cable` WebSocket.

This tree is the Rails-shape-without-metaprogramming specimen, packaged as a [spin](https://github.com/matz/spinel/blob/master/docs/spin.md) project and compiled ahead-of-time to a native binary by the [Spinel](https://github.com/matz/spinel) Ruby VM — see `SPECIMEN.md` for the full architecture document (layout, runtime, ruleset, limitations). Static assets ship prebuilt in `static/assets/` (the Makefile's `make assets` step needs the MRI toolchain; the binary sendfiles them at `/assets/*`).

## Prerequisites
- [spinel](https://github.com/matz/spinel) — `spinel` and `spin` on PATH (the repo's `bin/` after `make`)
- A C toolchain + SQLite headers (`libsqlite3-dev`) — the binary links `-lsqlite3`
- jemalloc headers (`libjemalloc-dev`) — `spin.toml` asks for it as this program's allocator, and a server is the shape where that is worth having. Note the DEV package: the `libjemalloc2` runtime alone is what `LD_PRELOAD` uses and is not enough to link against
- libvips (`libvips-dev` to build, `libvips42` to run; `brew install vips`) — only when `spin.toml` lists `ruby-vips`, which it does when the app declares image variants (thumbnails, avatars)
- Node.js 24+ — for the End-to-end suite

## Build
```sh
spin build
```

## Setup
Seed the database — the Rails-traditional `storage/development.sqlite3`, from the bundled `db/seed.sql` (needs the `sqlite3` CLI):
```sh
sqlite3 storage/development.sqlite3 < db/seed.sql
```

## Run
```sh
./build/bin/blog
```
The server is a green thread per connection, run on the runtime's OS workers (one per core, autodetected); `SPINEL_WORKERS=N` in the environment sets the count.

## Test
Each `test/*.rb` compiles to its own binary and diffs against its `.expected` snapshot. `spin test` feeds the `.rbs` sidecars to the compiler itself, so no seeding is needed:
```sh
spin test
```

## End-to-end
Browser smoke tests (Playwright). Needs Node.js 24+ and the `sqlite3` CLI; run after the Build steps above — the test config boots the server and seeds `db/seed.sql` itself:
```sh
cd e2e
npm install
npx playwright install chromium
npx playwright test
```

## Regenerate
```sh
roundhouse --target spinel -o <output-dir> <input-app>
```
