module Seeds
  def self.run
    if Article.count > 0
      nil
    else
      article1 = Article.create!(title: "Getting Started with Rails", body: "Rails is a web application framework running on the Ruby programming language. It makes building web apps faster and easier with conventions over configuration.")
#<SPINEL_SOURCE>app/db/seeds.rb:10
      Comment.create!(commenter: "Alice", body: "Great introduction! Rails really does make development faster.", article_id: article1.id)
#<SPINEL_SOURCE>app/db/seeds.rb:15
      Comment.create!(commenter: "Bob", body: "I love how Rails handles database migrations automatically.", article_id: article1.id)
      
#<SPINEL_SOURCE>app/db/seeds.rb:20
      article2 = Article.create!(title: "Understanding MVC Architecture", body: "MVC stands for Model-View-Controller. Models handle data and business logic, Views display information to users, and Controllers coordinate between them.")
#<SPINEL_SOURCE>app/db/seeds.rb:25
      Comment.create!(commenter: "Carol", body: "This pattern really helps keep code organized!", article_id: article2.id)
      
#<SPINEL_SOURCE>app/db/seeds.rb:30
      article3 = Article.create!(title: "Ruby2JS: Rails Everywhere", body: "Ruby2JS transpiles Ruby to JavaScript, enabling Rails applications to run in browsers, on Node.js, and at the edge. Same code, different runtimes.")
      
#<SPINEL_SOURCE>app/db/seeds.rb:35
      puts "Created #{Article.count} articles and #{Comment.count} comments"
    end
  end
end
