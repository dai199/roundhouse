# frozen_string_literal: true
# Tep::Server::Scheduled -- Falcon-shape fiber-per-connection HTTP
# server, built on Tep::Scheduler + sp_net non-blocking accept/recv.
#
# THE MEASUREMENT LANE. Tep::Server::Threaded (a green thread per
# connection) replaced this server on 2026-09-01; this file came back on
# 2026-09-03 so the two designs can be measured on ONE binary, differing
# only in the environment: `TEP_SERVER=fiber` selects it (scaffold/main.rb),
# `SPINEL_WORKERS` is irrelevant to it (every fiber runs on the main
# thread). It serves the HTTP keep-alive path only: a WebSocket upgrade
# is refused with a 501 (its recv loop belongs on a parked green thread,
# and here it would hold every other connection), and the per-request
# state the threaded server keeps in Thread.current is shared by all
# fibers on the main thread -- correct while a request runs from start to
# finish without yielding, which a GET does; so the bench pages run it and
# the campfire gates do not. matz/spinel#4306 is the question it answers.
#
# Why this exists
# ---------------
# The default Tep::Server (in server.rb) is prefork + blocking per
# worker -- N workers <=> N concurrent connections. WebSockets and
# slow keep-alive clients tie up a worker for the full connection
# duration, so the prefork pool's effective concurrency degrades
# to N regardless of actual CPU work. The scheduled variant accepts
# in a fiber, spawns one fiber per accepted connection, and parks
# all I/O on Tep::Scheduler.io_wait -- N workers serve M >> N
# concurrent connections, bounded only by per-fiber memory.
#
# Fiber bodies use ordinary closure capture for sfd / client now
# (matz/spinel#564 + #1007 both closed; the heap-cell-reset fix
# in spinel commit 48594d6 lets multi-method capture chains lower
# correctly). cmeths still preferred for accept_loop /
# handle_connection so the bodies read cleanly without per-instance
# state, but the per-connection fd flows through closure capture,
# not the earlier `Tep::APP.pending_*` stash + pause(0) handoff.
module Tep
  class Server
    class Scheduled
      # Max bytes accepted from a single request's start-line +
      # headers. Bigger requests get 413; matches the blocking
      # server's SPHTTP_BUFSIZE cap (64 KiB).
      MAX_REQUEST_BYTES = 65535

      # Idle keep-alive timeout between requests on the same
      # connection. 30s matches nginx; bump from app code as needed.
      KEEPALIVE_TIMEOUT = 30

      # Slow-headers DoS guard.
      HEADER_READ_TIMEOUT = 10

      attr_accessor :app

      def initialize(app)
        @app = app
      end

      def run(port, workers, quiet, unix = UnixListener.new(""))
        sfd = Sock.sphttp_listen_on(Tep::APP.bind_host, port, workers > 1 ? 1 : 0)
        if sfd < 0
          # Loud + nonzero exit: the one plausible cause on a sane host
          # is another process already bound to the port, and silently
          # returning here (the caller discards the code) made the
          # binary look like it started and immediately vanished.
          $stderr.puts Tep.display_name + ": cannot bind to port " +
                       port.to_s + " (already in use?)"
          unix.close
          exit(1)
        end
        Sock.sphttp_set_nonblock(sfd)
        if !quiet
          # Same banner shape as the prefork Tep::Server, printed only
          # after a successful bind so startup and bind-failure are
          # distinguishable at a glance. Explicit flush: when stdout is
          # redirected (not a TTY) C stdio block-buffers, and a banner
          # that only shows up at exit is no banner at all.
          puts Tep.display_name + " (" + RUBY_ENGINE +
               ") listening on http://" + (Tep::APP.bind_host.empty? ? "0.0.0.0" : Tep::APP.bind_host) + ":" + port.to_s +
               ", pid " + Sock.sphttp_getpid.to_s
          puts "  one fiber per connection (TEP_SERVER=fiber); OS workers: " +
               "1, the main thread; processes: " + Tep.processes_desc(workers)
          $stdout.flush
        end

        # Install SIGTERM/SIGINT handlers BEFORE fork so children
        # inherit them; accept_loop checks the term flag once per
        # second and runs Tep.on_shutdown (run_end + future hooks).
        Sock.sphttp_install_term_handlers

        if workers > 1
          pids = [0]
          pids.pop
          i = 0
          while i < workers
            pid = Sock.sphttp_fork
            if pid == 0
              Tep::Server::Scheduled.run_worker(sfd, unix.unix_fd)
              unix.close
              Sock.sphttp_exit(0)
            end
            pids.push(pid) if pid > 0
            i += 1
          end
          # Reap children until none remain. After all workers exit,
          # emit the single aggregated run_end (see #128 / Tep::Events
          # #run_end_aggregated).
          Tep.reap_workers(pids)
          if Sock.sphttp_shutdown_requested != 0
            Tep.on_shutdown
          end
        else
          Tep::Server::Scheduled.run_worker(sfd, unix.unix_fd)
          # Single-process: this IS the parent; emit run_end here.
          if Sock.sphttp_shutdown_requested != 0
            Tep.on_shutdown
          end
          # Exit outright, as the threaded server does: the scaffold's
          # job-loop green thread is parked on its queue, and spinel runs
          # every remaining green thread to completion when main returns.
          unix.close
          Sock.sphttp_close(sfd)
          Sock.sphttp_exit(0)
        end
        unix.close
        Sock.sphttp_close(sfd)
        Sock.sphttp_exit(0)
      ensure
        unix.close
        Sock.sphttp_close(sfd) if sfd >= 0
      end

      # Spawn the accept fiber + pump the scheduler. Called inside
      # each prefork child. Loops directly on `tick` rather than
      # `run_until_empty` because the accept fiber parks on io_wait
      # indefinitely -- run_until_empty bails when no fiber is ready
      # to resume THIS pass; we need to keep polling so parked
      # accept-on-sfd fibers get woken when a connection arrives.
      def self.run_worker(sfd, ufd = -1)
        f = Fiber.new { Tep::Server::Scheduled.accept_loop(sfd, "tcp") }
        Tep::Scheduler.spawn_fiber(f)
        if ufd >= 0
          Sock.sphttp_set_nonblock(ufd)
          unix_accept = Fiber.new { Tep::Server::Scheduled.accept_loop(ufd, "unix") }
          Tep::Scheduler.spawn_fiber(unix_accept)
        end
        while Tep::Scheduler.alive_count > 0
          # Shutdown is the WORKER's exit condition, not the fibers'.
          # The accept fiber honours the term flag and dies, but any
          # perpetual fiber an app registered (the scaffold's job-queue
          # drain runs `loop { pause; drain }`) keeps alive_count > 0
          # forever — so a SIGTERM/SIGINT used to leave the process
          # squatting on the port, accepting connections into the
          # backlog and serving none of them. Ctrl-C must mean exit.
          if Sock.sphttp_shutdown_requested != 0
            break
          end
          Tep::Scheduler.tick(1000)
        end
        0
      end

      # Accept loop. Each accepted connection becomes its own fiber
      # that closes over the just-accepted `client` fd.
      def self.accept_loop(sfd, transport = "tcp")
        while true
          # SIGTERM/SIGINT: sphttp's term flag is set by the signal
          # handler; check before parking on io_wait so we don't sleep
          # past a shutdown request. The 1s io_wait timeout below
          # bounds the sleep-side latency. The parent (or this same
          # process for workers=1) emits the aggregated run_end after
          # all workers exit (#128).
          if Sock.sphttp_shutdown_requested != 0
            break
          end
          # Bounded wait so the flag check above runs once per second
          # even when traffic is idle (was -1 = wait forever).
          ready = Tep::Scheduler.io_wait(sfd, Tep::Scheduler::READ, 1)
          if ready == 0
            next
          end
          client = Sock.sphttp_accept_nb(sfd)
          if client < 0
            next
          end
          Sock.sphttp_set_nonblock(client)
          conn = Fiber.new { Tep::Server::Scheduled.handle_connection(client, transport) }
          Tep::Scheduler.spawn_fiber(conn)
        end
      end

      # Per-connection lifecycle. Per-request work lives in handle_one so
      # each keep-alive iteration gets its own SP_GC_SAVE/SP_GC_RESTORE
      # scope. Inline in this while loop, the per-request roots (blob, req,
      # res, and everything dispatch/render allocates) would hoist to this
      # function's long-lived scope and pile up across the connection's
      # requests -- defeating the young-gen GC and racing the heap threshold
      # upward (idle 2 MB -> multi-GB under sustained keep-alive load).
      # Mirrors the Tep::Server#handle_one fix (210a5f6) for the prefork
      # server; this Scheduled server is the one the blog actually runs.
      def self.handle_connection(client, transport = "tcp")
        input = InputBuffer.new
        keep_going = true
        while keep_going
          keep_going = Tep::Server::Scheduled.handle_one(client, input, transport)
        end
        Sock.sphttp_close(client)
        0
      end

      # Process exactly one request on `client`. Returns true to keep the
      # connection open for the next keep-alive request, false to close.
      def self.handle_one(client, input = InputBuffer.new, transport = "tcp")
        blob = Tep::Server::Scheduled.read_request_blob(client, KEEPALIVE_TIMEOUT, input)
        if blob.length == 0
          return false
        end
        req = Parser.parse(blob, input)
        if req == nil
          Tep::Server::Scheduled.send_simple(client, 400, "bad request")
          return false
        end
        req.listener_transport = transport
        # Rack's REMOTE_ADDR: the peer a connection came from ("" over a UNIX socket).
        req.remote_host = Sock.sp_net_peer_ip(client)

        # Before the drain, which is what held the bytes (Request#body_refusal).
        refusal = req.body_refusal(Tep.max_body_bytes)
        if refusal != 0
          Tep::Server::Scheduled.send_simple(client, refusal,
            refusal == 413 ? "request body too large" : "bad request")
          return false
        end

        unless req.consume_body_via_scheduler(client, input)
          failure = req.body_failure_status
          Tep::Server::Scheduled.send_simple(client, failure, failure == 413 ? "request body too large" : "bad request") if failure != 0
          return false
        end

        res = Response.new
        begin
          Tep::APP.dispatch(req, res)
        # Both names, as in the blocking server: a stubbed gem facade
        # raises NotImplementedError, a ScriptError, which a bare
        # `rescue` does not catch.
        rescue StandardError, ScriptError => e
          # Same contract as the blocking server: one request's failure
          # is not the worker's. A fiber that unwinds here would take
          # the whole scheduler loop with it, so every OTHER open
          # connection dies too — strictly worse than the prefork case.
          Tep.log_dispatch_error(req.verb, req.path, e)
          Tep::Server::Scheduled.send_simple(client, 500, "internal server error")
          return false
        end

        # The writer returns the keep-alive decision it actually sends.
        keep_alive = req.keep_alive? && !res.halted_close?
        Tep::Server::Scheduled.write_response(client, req, res, keep_alive)
      end

      # Non-blocking request reader. Returns the accumulated blob
      # once "\r\n\r\n" is seen, or "" on timeout / EOF / oversize.
      def self.read_request_blob(fd, timeout_seconds, input = InputBuffer.new)
        buf = input.take_pending_input
        return buf if buf.include?("\r\n\r\n")
        deadline = Time.now.to_i + timeout_seconds
        while buf.bytesize < MAX_REQUEST_BYTES
          remaining = deadline - Time.now.to_i
          if remaining <= 0
            return ""
          end
          ready = Tep::Scheduler.io_wait(fd, Tep::Scheduler::READ, remaining)
          if ready == 0
            return ""
          end
          chunk = Sock.sphttp_recv_some(fd, [4096, MAX_REQUEST_BYTES - buf.bytesize].min).b
          if chunk.length == 0
            return ""
          end
          buf << chunk
          if buf.bytesize >= 4 && buf.include?("\r\n\r\n")
            return buf
          end
        end
        ""
      end

      # Body-shape mirror of Tep::Server#write_response. Lifted into
      # a cmeth so the connection fiber can call it without a captured
      # `self`.
      def self.write_response(client, req, res, keep_alive)
        # WebSocket upgrade branch. Set by res.start_websocket in the
        # user's handler after a successful Handshake.check. Writes
        # the 101 Switching Protocols head, then assigns the client
        # fd onto the driver and runs the recv loop. The recv loop
        # returns when the connection closes (peer EOF, idle timeout,
        # or a CLOSE frame round-trip). After return, the caller's
        # handle_connection closes the fd as usual.
        if res.upgrading_ws
          # The fiber lane serves the HTTP path only: the driver's recv
          # loop wants a parked green thread (Tep::Server::Threaded), and
          # on this server it would run on the main thread and hold every
          # other connection. Refuse the upgrade rather than serve it wrong.
          Tep::Server::Scheduled.send_simple(client, 501,
            "websocket upgrade needs TEP_SERVER=thread")
          return false
        end

        # Streaming branch -- cooperative mirror of Tep::Server's
        # streaming path (server.rb). Set by res.start_stream(streamer)
        # in the handler. Writes a chunked-encoding head immediately,
        # hands a Tep::Stream writer to the user's Streamer#pump, then
        # emits the end-of-stream terminator. pump runs cooperatively:
        # it parks on Tep::Scheduler.io_wait between writes (e.g. the
        # proxy streamer waits on the upstream fd), so other fibers keep
        # running while this stream is in flight. Connection: close --
        # chunked keep-alive is legal but we keep it simple, matching
        # the prefork server.
        if res.streaming
          res.headers["Transfer-Encoding"] = "chunked"
          if !res.headers.key?("Content-Type")
            res.headers["Content-Type"] = "text/event-stream"
          end
          reason = Tep.reason(res.status)
          head = req.http_version + " " + res.status.to_s + " " + reason + "\r\n"
          head << Tep.header_lines(res)
          head << "Connection: close\r\n\r\n"
          Sock.sphttp_write_str(client, head)
          out = Tep::Stream.new(client)
          begin
            res.streamer.pump(out)
          rescue StandardError, ScriptError => e
            Tep.log_dispatch_error(req.verb, req.path, e)
            return false
          end
          Sock.sphttp_write_chunk_end(client)
          return false
        end

        # Default Content-Type for inline-body responses. Matches
        # Tep::Server#send; without it, the Security::Headers nosniff
        # default leaves the browser refusing to interpret an erb
        # response as HTML.
        if res.file_path.length == 0 && res.body.length > 0 && !res.headers.key?("Content-Type")
          res.headers["Content-Type"] = "text/html; charset=utf-8"
        end
        Tep.maybe_gzip!(req, res)
        reason = Tep.reason(res.status)
        head = req.http_version + " " + res.status.to_s + " " + reason + "\r\n"
        head << Tep.header_lines(res)
        if keep_alive
          head << "Connection: keep-alive\r\n"
        else
          head << "Connection: close\r\n"
        end
        if res.file_path.length > 0
          fs = Sock.sphttp_filesize(res.file_path)
          if fs < 0
            Tep::Server::Scheduled.send_simple(client, 404, "file not found")
            return false
          end
          head << "Content-Length: " + fs.to_s + "\r\n\r\n"
          Sock.sphttp_write_str(client, head)
          Sock.sphttp_sendfile(client, res.file_path) unless req.verb == "HEAD"
        else
          # BYTES, both times. `length` counts characters, and
          # `write_str` crosses the FFI as a NUL-terminated C string —
          # so a PNG served through res.body used to announce the
          # file's size and deliver 8 bytes (everything before the
          # first 0x00), and a page with one emoji understated its
          # Content-Length and corrupted keep-alive framing. The
          # browser waits out the difference: campfire's sign-in page
          # hung ~30s on /account/logo until the keep-alive timeout
          # closed the connection under it (ERR_CONTENT_LENGTH_MISMATCH).
          # Not for a 204 or a 304: RFC 9110 gives neither a Content-Length of its own body, and Puma writes none.
          if res.status == 204 || res.status == 304
            head << "\r\n"
          else
            head << "Content-Length: " + res.body.bytesize.to_s + "\r\n\r\n"
          end
          Sock.sphttp_write_str(client, head)
          # HEAD: the headers GET would send, Content-Length included, and
          # no body (RFC 9110 9.3.2). A body here would be read by the
          # client as the start of the NEXT response on a keep-alive socket.
          if res.body.bytesize > 0 && req.verb != "HEAD"
            Sock.sphttp_write_bytes(client, res.body, res.body.bytesize)
          end
        end
        keep_alive
      end

      # bytesize, as write_response: a multibyte `msg` would otherwise
      # announce fewer bytes than are written.
      def self.send_simple(client, status, msg)
        reason = Tep.reason(status)
        head = "HTTP/1.0 " + status.to_s + " " + reason + "\r\n" +
               "Content-Length: " + msg.bytesize.to_s + "\r\n" +
               "Connection: close\r\n\r\n" + msg
        Sock.sphttp_write_str(client, head)
        0
      end
    end
  end
end
