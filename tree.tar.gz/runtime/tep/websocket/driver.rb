# frozen_string_literal: true
# Tep::WebSocket::Driver -- Faye-shape state machine + event dispatch.
#
# Constructed AFTER the handshake completes, before the recv loop
# starts. Holds per-connection state + outbound write methods +
# the event-callback registry that the handler (or the Phase 3 DSL)
# populates.
#
# Faye-shape API (matches faye/websocket-driver-ruby's surface for
# the parts tep ships -- single-frame text/binary, ping/pong, close):
#
#     drv = Tep::WebSocket::Driver.new(fd)
#     drv.on_message    do |evt| ... end    # block-based on:open/on:message etc
#     drv.on_close      do |evt| ... end    #   are syntactic sugar; tep ships
#     drv.text("hi")                        #   the explicit setters instead
#     drv.binary(bytes)
#     drv.ping("")
#     drv.close(1000, "bye")
#
# In Phase 2, callbacks are set via explicit setters (`set_on_message`)
# rather than `on(:message) { block }` since spinel's block-with-
# closure-on-locals support is still uneven outside Fiber.new bodies.
# Phase 3's DSL hides this behind `ws.on(:message) { ... }` once we
# decide on the lowering shape.
module Tep
  module WebSocket
    class Driver
      # Rails/websocket-driver has no closing-handshake deadline. Tep chooses
      # five seconds so a silent peer cannot retain a parked receiver forever.
      CLOSE_TIMEOUT_SECONDS = 5
      attr_accessor :max_frame_size, :subprotocol, :faye_text_only
      # Callback slots. Each holds a subclass of Tep::WebSocket::Handler
      # (or the base) that gets `handle_event(event)` called when the
      # corresponding wire event arrives. Defaults to a no-op base
      # so the slot is type-safe pre-set.
      attr_accessor :h_open, :h_message, :h_close, :h_ping, :h_pong, :h_error

      def initialize(fd)
        @faye_text_only = false
        @fd             = fd
        @closed         = false
        @closing        = false
        @close_complete = false
        @close_timed_out = false
        @close_pending  = false
        @close_payload  = +""
        @close_code     = Tep::WebSocket::CLOSE_GOING_AWAY
        @close_reason   = +""
        @wlock          = Mutex.new
        @state_lock     = Mutex.new
        @max_frame_size = Tep::WebSocket::DEFAULT_MAX_FRAME
        @subprotocol    = +""
        @h_open    = Tep::WebSocket::Handler.new
        @h_message = Tep::WebSocket::Handler.new
        @h_close   = Tep::WebSocket::Handler.new
        @h_ping    = Tep::WebSocket::Handler.new
        @h_pong    = Tep::WebSocket::Handler.new
        @h_error   = Tep::WebSocket::Handler.new
      end

      def set_max_frame_size(n)
        @max_frame_size = n
      end

      # Reassign the underlying fd. Used by the server-side upgrade
      # path: the user handler builds the Driver with a placeholder
      # fd (since the client fd isn't visible at handler-dispatch
      # time), and the write_response branch sets the real fd here
      # right before constructing the Connection.
      def fd
        @state_lock.synchronize { @fd }
      end

      def fd=(new_fd)
        set_fd(new_fd)
      end

      def set_fd(new_fd)
        @wlock.synchronize do
          @state_lock.synchronize do
            unless @closed
              @fd = new_fd
              if @close_timed_out
                TepSocketControl.shutdown(@fd, 2) if @fd >= 0
              end
            end
          end
          write_pending_close
        end
        0
      end

      def set_subprotocol(name)
        @subprotocol = name
      end

      def set_on_open(h);    @h_open = h;    end
      def set_on_message(h); @h_message = h; end
      def set_on_close(h);   @h_close = h;   end
      def set_on_ping(h);    @h_ping = h;    end
      def set_on_pong(h);    @h_pong = h;    end
      def set_on_error(h);   @h_error = h;   end

      # Send a text frame.
      def text(s)
        write_frame(Tep::WebSocket::OPCODE_TEXT, s)
      end

      # (Upstream tep also defines a Streamer-shape `write(s)` alias for
      # `text`, used by Tep::Llm.chat_stream. Roundhouse doesn't vendor
      # Llm and never calls it; dropped here because an uncalled
      # String-param method's param defaults to int under spinel and
      # then fails the C-compile when its body passes it as a string.)

      # Send a binary frame.
      def binary(bytes)
        write_frame(Tep::WebSocket::OPCODE_BINARY, bytes)
      end

      # Send a ping with optional payload (<=125 bytes).
      def ping(payload)
        write_frame(Tep::WebSocket::OPCODE_PING, payload)
      end

      # Send a pong with the matching ping's payload (per §5.5.3).
      def pong(payload)
        write_frame(Tep::WebSocket::OPCODE_PONG, payload)
      end

      # Send a close frame with code + reason. Reason capped at
      # 123 bytes so the 2-byte code + reason fits in a control
      # frame's 125-byte payload limit. The first close wins; it refuses
      # later application frames. Keep reading for the peer's close or EOF;
      # only the bounded fallback shuts down the socket to wake its owner.
      def close(code, reason)
        body = Driver.encode_close_payload(code, reason)
        started = false
        # State is never held while waiting for, or performing, a write.
        @state_lock.synchronize do
          unless @closing || @closed
            @closing = true
            @close_pending = true
            @close_payload = body
            unless @close_complete
              @close_code = code
              @close_reason = code == 0 ? "" : reason.byteslice(0, 123)
            end
            started = true
          end
        end
        if started
          # Start before acquiring the writer: an earlier application send,
          # or the close frame itself, can be parked on a full socket buffer.
          Thread.new(self) do |driver|
            sleep Driver::CLOSE_TIMEOUT_SECONDS
            driver.expire_close
          end
          @wlock.synchronize do
            write_pending_close
          end
        end
        0
      end

      # Caller holds @wlock. The receiver can retire before the initiating
      # closer acquires it; either caller must complete the one queued frame.
      def write_pending_close
        send_fd = -1
        body = +""
        @state_lock.synchronize do
          if @close_pending && !@closed && !@close_timed_out && @fd >= 0
            @close_pending = false
            send_fd = @fd
            body = @close_payload
          end
        end
        Driver.send_frame(send_fd, Tep::WebSocket::OPCODE_CLOSE, body) if send_fd >= 0
        0
      end

      def closing?
        @state_lock.synchronize { @closing || @closed || @close_complete || @close_timed_out }
      end

      # Called by the receiver for the peer's close, or a protocol failure.
      # The close event describes that result, not our outbound request.
      def finish_close(code, reason)
        @state_lock.synchronize do
          unless @closed || @close_timed_out
            @close_code = code
            @close_reason = reason
            @close_complete = true
          end
        end
        0
      end

      def close_complete?
        @state_lock.synchronize { @close_complete }
      end

      def close_finished?
        @state_lock.synchronize { @closed || @close_complete || @close_timed_out }
      end

      def expire_close
        # Even a received close can be waiting for a parked writer before
        # retirement. Only retirement makes it safe to ignore this deadline.
        @state_lock.synchronize do
          unless @closed
            @close_timed_out = true
            TepSocketControl.shutdown(@fd, 2) if @fd >= 0
          end
        end
        0
      end

      def close_code
        @state_lock.synchronize { @close_code }
      end

      def close_reason
        @state_lock.synchronize { @close_reason }
      end

      # When both locks are needed, acquire @wlock then @state_lock. Never
      # hold @state_lock across send_frame; expiry needs it to wake the send.
      # ONE WRITER AT A TIME, AND NONE AFTER RETIREMENT. Every frame this
      # driver sends passes through here: the connection's own thread
      # (welcome, confirm_subscription, close), its ping thread, and any
      # thread publishing a broadcast. The lock serialises them, so two
      # frames never interleave their bytes on the wire; and `retire`
      # flips `@closed` under the same lock, so no write can START once
      # the fd's owner has decided to close it. That ordering is what
      # makes an fd NUMBER safe to hold across threads: the kernel hands
      # a closed fd's number to the next accept, and a writer that only
      # asked "did my last write fail?" wrote into a stranger's socket.
      # The ping thread did exactly that -- a ping frame ahead of a new
      # connection's 101 is ERR_INVALID_HTTP_RESPONSE in the browser, and
      # a subscribe that never confirms. Returns the write's result, or
      # -1 once closing or retired.
      def write_frame(opcode, payload)
        allowed = false
        @state_lock.synchronize do
          allowed = !@closed && !@close_complete && !@close_timed_out && @fd >= 0 &&
            (!@closing || opcode == Tep::WebSocket::OPCODE_PONG)
        end
        return -1 unless allowed
        r = -1
        @wlock.synchronize do
          send_fd = -1
          @state_lock.synchronize do
            if !@closed && !@close_complete && !@close_timed_out && @fd >= 0 &&
                (!@closing || opcode == Tep::WebSocket::OPCODE_PONG)
              send_fd = @fd
            end
          end
          r = Driver.send_frame(send_fd, opcode, payload) if send_fd >= 0
        end
        r
      end

      # The fd's owner calls this BEFORE closing the fd (Tep::Server::
      # Threaded, after the recv loop returns). A write in flight
      # finishes first -- a parked write completes or fails -- and every
      # later one is refused, which is also how the ping thread learns
      # to exit.
      def retire
        @wlock.synchronize do
          begin
            write_pending_close
          ensure
            @state_lock.synchronize { @closed = true }
          end
        end
        0
      end

      # Build the frame bytes (unmasked, server-side) and write via
      # sphttp_write_bytes (binary-safe, explicit length). The raw write
      # behind `write_frame`; nothing else should reach an fd directly.
      def self.send_frame(fd, opcode, payload)
        frame = Tep::WebSocket::Frame.new(true, opcode, payload)
        bytes = frame.encode_unmasked
        Sock.sphttp_write_bytes(fd, bytes, bytes.bytesize)
      end

      # Close payload: 2-byte big-endian code + UTF-8 reason. Per
      # §5.5.1 the payload may be omitted (close with no body); if
      # `code == 0` we emit an empty payload.
      def self.encode_close_payload(code, reason)
        if code == 0
          return ""
        end
        out = Tep::WebSocket::Frame.byte_to_chr((code >> 8) & 0xff) +
              Tep::WebSocket::Frame.byte_to_chr(code & 0xff)
        if reason.bytesize > 123
          out + reason.byteslice(0, 123)
        else
          out + reason
        end
      end
    end

    # Event passed to handler callbacks. Holds `data` (the payload
    # as String for text/binary, raw bytes for ping/pong, or the
    # close code+reason for close) and a numeric `code` for close.
    class Event
      attr_accessor :data, :code, :reason

      def initialize
        @data   = +""
        @code   = 0
        @reason = +""
      end
    end

    # Base class for event handlers. Subclass + override
    # `handle_event(event)`. The Driver stores one Handler instance
    # per event type and dispatches via `@h_message.handle_event(evt)`.
    # The explicit-Handler shape (vs faye's block-based `driver.on(:msg)
    # { ... }`) is chosen because it stays compatible with future
    # Fiber.storage per-connection state plumbing without re-typing
    # the callback boundary.
    #
    # `req` is set at WS upgrade time by the route handler the
    # translator emits, giving on_X handler bodies access to the
    # request that initiated the connection (req.identity,
    # req.session, headers, ...). It stays the same across every
    # event on the connection -- there's no per-frame "request".
    class Handler
      attr_accessor :req

      def initialize
        @req = Tep::Request.new
      end

      def handle_event(event)
        0
      end
    end
  end
end
