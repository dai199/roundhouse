# frozen_string_literal: true
# Tep::WebSocket::Connection -- per-connection recv loop.
#
# Runs on the connection's green thread (Tep::Server::Threaded) after
# the upgrade route has written the 101 response. The loop:
#   1. Parks on the IO wrapper's timed `wait_readable` for bytes.
#   2. Reads via Sock.sp_net_recv_some(:binstr) into a binary String,
#      appended to a per-connection accumulator (binary-safe `+`).
#   3. Walks the accumulator with Frame.parse_from_buf, dispatching
#      events to the Driver's handlers and carrying any partial trailing
#      frame forward via byteslice.
#   4. After a close result, EOF or deadline, retires for the fd's owner.
#
# The accumulator is a per-connection Ruby String (binary-safe via
# :binstr + pack), owned by this thread, so it needs no shared static
# buffer.
module Tep
  module WebSocket
    class Connection
      attr_accessor :driver, :fd, :idle_timeout_seconds

      # `io` is the connection's `IO.for_fd` wrapper over the same fd
      # (Tep::Server::Threaded owns and closes it): a raw fd has no
      # `wait_readable`, and the wrapper is what parks this green
      # thread until a frame arrives or the idle timeout passes.
      def initialize(driver, io)
        @driver = driver
        @fd     = driver.fd
        @io     = io
        @idle_timeout_seconds = 300
      end

      def set_idle_timeout(seconds)
        @idle_timeout_seconds = seconds
      end

      # Drive the recv loop. Returns 0 on clean close, -1 on error.
      # Idempotent across multiple frames per recv: a single
      # sphttp_recv_into_frame fill may contain several complete
      # frames; Connection consumes them all before parking again.
      #
      # `pending` is the suffix Parser already took off the socket with
      # the upgrade request (the first frame often shares that recv).
      # Those bytes are the WebSocket stream, so they are parsed before
      # the loop waits for anything further.
      #
      # The caller (Tep::Server::Threaded.write_response) owns the
      # fd lifecycle -- run() never calls sphttp_close. On clean
      # close OR error the server's handle_connection closes the fd
      # via its usual exit path, after retiring the driver. Every exit
      # from this loop passes through `dispatch_close`, so the broadcast
      # registry drops this fd's subscriptions while the number is still
      # this connection's; a timed-out socket used to skip that and leave
      # entries behind for the number's next owner.
      def run(pending = +"".b)
        # Synthetic open event before the first recv -- handlers
        # often want to send a welcome message.
        Connection.dispatch_open(@driver)

        # Inbound byte accumulator. sp_net_recv_some(:binstr) returns a
        # binary-safe String; append it (binary-safe `+`) and parse as many
        # whole frames as the buffer holds, carrying any partial trailing
        # frame forward via byteslice. Replaces the old static recv buffer
        # + per-byte C accessor (sphttp.c is retired — matz/spinel#1466).
        inbuf = pending.b
        while !@driver.close_finished?
          # Parse + dispatch every complete frame the buffer now holds,
          # including a frame that arrived in the same recv as the upgrade.
          while true
            # bytesize, not length: inbuf is masked binary, and char-count
            # arithmetic under-reports avail (complete frames report "need")
            # and truncates the carried tail after a parse (stream
            # misalignment) whenever XOR'd bytes form multi-byte UTF-8
            # sequences — mask-dependent, so it flakes per connection.
            # `@driver.max_frame_size` is what bounds `inbuf`: the parse
            # refuses an over-cap frame from its length field, so the
            # loop below can only ever carry a partial frame of at most
            # the cap plus a header. Passing the cap is not optional —
            # without it the parse says "need" for any size and the
            # accumulator grows until the worker OOMs.
            r = Tep::WebSocket::Frame.parse_from_buf(inbuf, 0, inbuf.bytesize, @driver.max_frame_size)
            if r.outcome == "need"
              break
            end
            if r.outcome == "close"
              reason = "protocol error"
              if r.close_code == Tep::WebSocket::CLOSE_MESSAGE_TOO_BIG
                reason = "message too big"
              end
              @driver.finish_close(r.close_code, reason)
              @driver.close(r.close_code, reason)
              return 0
            end
            Connection.dispatch_frame(@driver, r.frame)
            break if @driver.close_finished?
            if r.consumed >= inbuf.bytesize
              inbuf = +""
              break
            end
            inbuf = inbuf.byteslice(r.consumed, inbuf.bytesize - r.consumed)
          end

          break if @driver.close_finished?
          ready = @io.wait_readable(@idle_timeout_seconds)
          if ready.nil?
            # Timeout: close 1001 going-away.
            @driver.close(Tep::WebSocket::CLOSE_GOING_AWAY, "idle timeout")
            next
          end

          break if @driver.close_finished?
          chunk = Sock.sp_net_recv_some(@fd, 65536)
          if chunk.bytesize == 0
            # EOF / peer gone: dispatch close without sending one back.
            return 0
          end
          inbuf = inbuf + chunk
        end
        0
      ensure
        @driver.retire
        code = 1006
        reason = +""
        if @driver.close_complete?
          code = @driver.close_code
          reason = @driver.close_reason
        end
        Connection.dispatch_close(@driver, code, reason)
      end

      # Route a parsed frame to the right handler.
      def self.dispatch_frame(driver, frame)
        op = frame.opcode
        return 0 if driver.close_finished?
        return 0 if driver.closing? && op != Tep::WebSocket::OPCODE_CLOSE && op != Tep::WebSocket::OPCODE_PING
        if driver.faye_text_only && (op == Tep::WebSocket::OPCODE_CONTINUATION ||
            (!frame.fin && (op == Tep::WebSocket::OPCODE_TEXT || op == Tep::WebSocket::OPCODE_BINARY)))
          driver.finish_close(Tep::WebSocket::CLOSE_UNSUPPORTED, "Faye fragmentation is not supported")
          driver.close(Tep::WebSocket::CLOSE_UNSUPPORTED, "Faye fragmentation is not supported")
          return 0
        end
        if op == Tep::WebSocket::OPCODE_TEXT
          Connection.dispatch_message(driver, frame.payload, true)
        elsif op == Tep::WebSocket::OPCODE_BINARY
          Connection.dispatch_message(driver, frame.payload, false)
        elsif op == Tep::WebSocket::OPCODE_PING
          # Auto-pong with the ping's payload (§5.5.3).
          driver.pong(frame.payload)
          Connection.dispatch_ping(driver, frame.payload)
        elsif op == Tep::WebSocket::OPCODE_PONG
          Connection.dispatch_pong(driver, frame.payload)
        elsif op == Tep::WebSocket::OPCODE_CLOSE
          code = 0
          reason = +""
          # bytesize/getbyte/byteslice: the close payload is binary (2-byte
          # code + UTF-8 reason); char indexing misreads the code when the
          # reason opens with a multi-byte character.
          if frame.payload.bytesize >= 2
            code = (frame.payload.getbyte(0) << 8) | frame.payload.getbyte(1)
            if frame.payload.bytesize > 2
              reason = frame.payload.byteslice(2, frame.payload.bytesize - 2)
            end
          end
          # Record the received result before the one permitted echo. An
          # already-closing driver keeps its outbound frame and this result.
          driver.finish_close(code == 0 ? Tep::WebSocket::CLOSE_NORMAL : code, reason)
          driver.close(code == 0 ? Tep::WebSocket::CLOSE_NORMAL : code, reason)
        end
        0
      end

      def self.dispatch_open(driver)
        evt = Tep::WebSocket::Event.new
        driver.h_open.handle_event(evt)
        0
      end

      def self.dispatch_message(driver, data, text)
        if driver.faye_text_only
          unless text
            driver.finish_close(Tep::WebSocket::CLOSE_UNSUPPORTED, "Faye binary messages are not supported")
            driver.close(Tep::WebSocket::CLOSE_UNSUPPORTED, "Faye binary messages are not supported")
            return 0
          end
          data = data.dup.force_encoding(Encoding::UTF_8)
          unless data.valid_encoding?
            driver.finish_close(Tep::WebSocket::CLOSE_INVALID_UTF8, "Could not decode a text frame as UTF-8")
            driver.close(Tep::WebSocket::CLOSE_INVALID_UTF8, "Could not decode a text frame as UTF-8")
            return 0
          end
        end
        evt = Tep::WebSocket::Event.new
        evt.data = data
        driver.h_message.handle_event(evt)
        0
      end

      def self.dispatch_ping(driver, data)
        evt = Tep::WebSocket::Event.new
        evt.data = data
        driver.h_ping.handle_event(evt)
        0
      end

      def self.dispatch_pong(driver, data)
        evt = Tep::WebSocket::Event.new
        evt.data = data
        driver.h_pong.handle_event(evt)
        0
      end

      def self.dispatch_close(driver, code, reason)
        evt = Tep::WebSocket::Event.new
        evt.code = code
        evt.reason = reason
        begin
          driver.h_close.handle_event(evt)
          # Auto-cleanup: any Broadcast subscription or Presence row
          # keyed on this connection's fd gets dropped. Both calls
          # are no-op-safe when nothing was tracked (zero matches).
          # Apps that still call unsubscribe_fd / untrack_by_fd
          # explicitly stay correct -- the second call finds 0 matches.
        ensure
          Tep::Broadcast.unsubscribe_fd(driver.fd)
          Tep::Presence.untrack_by_fd(driver.fd)
        end
        0
      end
    end
  end
end
