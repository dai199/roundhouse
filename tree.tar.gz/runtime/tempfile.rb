# The bundled tempfile library — see `project::spinel_files`.
# The port at runtime/ruby/tempfile.rb exists for the strict
# targets that have no stdlib to bind to, and opens by name
# where this one opens O_EXCL.
require "tempfile"
