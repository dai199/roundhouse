# The bundled zlib library — see `project::spinel_files`.
# The port at runtime/ruby/zlib.rb is CRC-32 only; this one is
# packages/zlib (gzip/deflate) so tep can honour Accept-Encoding.
require "zlib"
