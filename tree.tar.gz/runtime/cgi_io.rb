# frozen_string_literal: true
require "cgi/escape"
# CGI protocol I/O. Reads requests from ENV + stdin; writes responses
# to stdout. The shape spinel can ingest (no sockets) and the shape
# any CGI-aware web server (Apache mod_cgi, nginx fcgiwrap, lighttpd)
# can drive.
#
# Inputs (per the CGI/1.1 spec):
#   ENV["REQUEST_METHOD"]   — "GET" / "POST" / "PATCH" / "DELETE"
#   ENV["PATH_INFO"]        — path portion, e.g. "/articles/42"
#   ENV["QUERY_STRING"]     — raw query string, e.g. "foo=bar"
#   ENV["CONTENT_LENGTH"]   — body length (decimal string)
#   ENV["CONTENT_TYPE"]     — urlencoded, multipart and JSON bodies supported
#   stdin                   — the request body (for POST/PATCH/PUT)
#
# Outputs (the response is plain text on stdout):
#   Status: <code> <reason>\r\n
#   Content-Type: text/html; charset=utf-8\r\n
#   [Location: <url>\r\n  if redirect]
#   \r\n
#   <body bytes>
#
# Keeps the spinel-subset envelope clean: basic regex, string ops,
# Hash mutation. No metaprogramming.

require "json"
require_relative "http_headers"

module CgiIo
  REASON_PHRASES = {
    200 => "OK",
    201 => "Created",
    204 => "No Content",
    301 => "Moved Permanently",
    302 => "Found",
    303 => "See Other",
    304 => "Not Modified",
    400 => "Bad Request",
    401 => "Unauthorized",
    403 => "Forbidden",
    404 => "Not Found",
    422 => "Unprocessable Entity",
    500 => "Internal Server Error",
  }.freeze

  # Parse a CGI request from the given env hash + body-readable IO.
  # Returns: { method:, path:, params:, body_params:, cookies:, accept:,
  # bad_request: }. `body_params` holds the body's params alone (Rails'
  # `request_parameters`), which ParamsWrapper copies from. `bad_request`
  # is true for a JSON body that does not parse, which Rails answers 400.
  def self.parse_request(env, stdin)
    method = (env["REQUEST_METHOD"] || "GET").upcase
    path   = env["PATH_INFO"] || "/"
    query  = env["QUERY_STRING"] || ""

    params = {}
    body_params = {}
    bad_request = false
    parse_form_into(query, params) unless query.empty?

    if method == "POST" || method == "PATCH" || method == "PUT"
      length = (env["CONTENT_LENGTH"] || "0").to_i
      ctype  = env["CONTENT_TYPE"] || ""
      if length > 0 && ctype.start_with?("application/x-www-form-urlencoded")
        body = stdin.read(length).to_s
        parse_form_into(body, body_params)
      elsif length > 0 && ctype.start_with?("multipart/form-data")
        # File parts land in the params tree as UploadedFile objects
        # under their bracket-nested name, the way Rack nests them; see
        # runtime/multipart.rb.
        body = stdin.read(length).to_s
        form = ActionDispatch::Http::Multipart.parse(body, ctype)
        form.fields.each { |k, v| assign_form_pair(body_params, k, v) }
        form.file_parts.each { |part| assign_form_pair(body_params, part.name, part.file) }
      elsif length > 0 && ctype.start_with?("application/json")
        # `@rails/request.js` with `contentType: "application/json"`
        # (campfire's link unfurl): Rails parses the object into params,
        # keeping its nesting and its types; a body that is not an object
        # lands under "_json", and deep_munge drops the nils inside
        # arrays. A malformed body is Rails' 400 (`bad_request`). The
        # spinel lane's twin is Tep::Request#parse_body_params with
        # `ParamBuilder.from_json`.
        body = stdin.read(length).to_s
        begin
          parsed = JSON.parse(body)
          root = parsed.is_a?(Hash) ? parsed : { "_json" => parsed }
          root.each { |k, v| body_params[k.to_s] = json_munge(v) }
        rescue JSON::ParserError
          bad_request = true
        end
      end
      # Merged `params` is body ∪ query (query already landed above).
      body_params.each { |k, v| params[k] = v }
    end

    # Rails-style method override: a POST with hidden `_method=delete` (or
    # patch / put) is treated as that verb for routing purposes. Browsers
    # can't emit DELETE/PATCH directly from a form, so Rails renders these
    # forms as method="post" with a hidden input; the dispatch layer
    # rewrites the verb here. Only honored from POST → {PATCH,PUT,DELETE};
    # GETs ignore the override.
    if method == "POST"
      override = params.delete("_method")
      if !override.nil?
        upcased = override.to_s.upcase
        method = upcased if upcased == "PATCH" || upcased == "PUT" || upcased == "DELETE"
      end
    end

    cookies = parse_cookies(env["HTTP_COOKIE"])

    # Accept rides along so dispatch can negotiate the response format.
    # Turbo sends `text/vnd.turbo-stream.html` on a form submission it
    # drives, which is the only way to tell that request apart from the
    # same URL typed into the address bar.
    accept = env.fetch("HTTP_ACCEPT", "").to_s

    { method: method, path: path, params: params, body_params: body_params, cookies: cookies, accept: accept, bad_request: bad_request }
  end

  # Rails' deep_munge on one parsed JSON value: nils inside Arrays are
  # dropped at any depth; Hashes and scalars keep their contents (a nil
  # under a key stays nil).
  def self.json_munge(v)
    if v.is_a?(Array)
      v.compact.map { |e| json_munge(e) }
    elsif v.is_a?(Hash)
      v.each_with_object({}) { |(k, e), h| h[k.to_s] = json_munge(e) }
    else
      v
    end
  end

  # Write a CGI response to the given writable IO. `set_cookies` is
  # `{ name => value | nil }`; nil clears the cookie via Max-Age=0.
  def self.write_response(io, status, body, location: nil, content_type: "text/html; charset=utf-8", set_cookies: {}, extra_headers: {})
    code   = status.is_a?(Integer) ? status : status.to_i
    reason = REASON_PHRASES.fetch(code, "OK")
    io.write("Status: #{code} #{reason}\r\n")
    write_header(io, "Content-Type", content_type.to_s) unless content_type.nil? || content_type.to_s.empty?
    write_header(io, "Location", location.to_s) unless location.nil?
    extra_headers.each { |k, v| write_header(io, k.to_s, v.to_s) unless v.nil? }
    set_cookies.each do |name, val|
      if val.nil?
        write_header(io, "Set-Cookie", "#{name}=; Path=/; Max-Age=0")
      else
        write_header(io, "Set-Cookie", "#{name}=#{url_encode(val.to_s)}; Path=/; HttpOnly")
      end
    end
    io.write("\r\n")
    io.write(body.to_s)
    nil
  end

  # One header line, or nothing when it cannot be one line. A value can
  # carry request data (a redirect Location, a Content-Disposition, a
  # blob's Content-Type), and a CR or LF in it would end the header and
  # write the rest as a header the app never set. Puma's rule, the same
  # one the spinel servers apply (`Tep.header_lines` — this lane does
  # not load Tep, so the two predicates are twins): DROP a key holding a
  # control character, space, `"` or `:`, or a value holding a control
  # character other than tab.
  def self.write_header(io, key, value)
    return nil unless HttpHeaders.key_ok?(key) && HttpHeaders.value_ok?(value)
    io.write(key + ": " + value + "\r\n")
    nil
  end

  # ── cookie parsing ──────────────────────────────────────────────

  # Parse a `Cookie:` header value into a Hash[Symbol => String].
  # The `; ` separator between cookies is RFC 6265 standard; tolerate
  # extra whitespace around the `=` and around separators.
  def self.parse_cookies(header)
    out = {}
    return out if header.nil? || header.empty?
    header.split(";").each do |pair|
      pair = pair.strip
      eq = pair.index("=")
      next if eq.nil?
      name = url_decode(pair[0, eq].strip)
      val  = url_decode(pair[(eq + 1)..].to_s.strip)
      out[name.to_sym] = val unless name.empty?
    end
    out
  end

  # ── form-urlencoded parsing ─────────────────────────────────────

  # Parse a `key1=val1&key2=val2&article[title]=hello` body into a
  # nested-hash structure. Mutates the passed-in hash so multiple
  # sources (query string + body) can be merged.
  def self.parse_form_into(input, into)
    return if input.empty?
    input.split("&").each do |pair|
      next if pair.empty?
      eq = pair.index("=")
      raw_key = eq.nil? ? pair : pair[0, eq]
      raw_val = eq.nil? ? ""   : pair[(eq + 1)..]
      key = url_decode(raw_key)
      val = url_decode(raw_val)
      assign_form_pair(into, key, val)
    end
    nil
  end

  # `article[title]` → into["article"]["title"] = val
  # `id` → into["id"] = val
  # `user_ids[]` → into["user_ids"] = [..., val]
  # `a[b][c]` → into["a"]["b"]["c"] = val
  #
  # The bracket grammar Rack's `parse_nested_query` reads, which is what
  # `Hash#to_query` writes on the other side (`ViewHelpers.to_query`): a
  # head, then any number of `[segment]` steps, where an EMPTY segment
  # means "append to the array here" and is only meaningful last. A
  # malformed key (an unclosed bracket) is dropped, as before.
  #
  # String keys throughout: the router's path_params are already
  # string-keyed (`params["id"]`), and merging the two via main.rb
  # only works cleanly if both halves agree. Controllers (and the
  # `*Params.from_raw` helpers) consequently fetch by string key.
  def self.assign_form_pair(into, raw_key, val)
    open_bracket = raw_key.index("[")
    if open_bracket.nil?
      into[raw_key] = val
      return
    end
    segments = []
    rest = raw_key[open_bracket..]
    while rest.start_with?("[")
      close_bracket = rest.index("]")
      return if close_bracket.nil?
      segments.push(rest[1...close_bracket])
      rest = rest[(close_bracket + 1)..]
    end
    return if !rest.empty?
    current = into
    key = raw_key[0, open_bracket]
    segments.each do |segment|
      if segment.empty?
        current[key] = [] unless current[key].is_a?(Array)
        current[key].push(val)
        return
      end
      current[key] = {} unless current[key].is_a?(Hash)
      current = current[key]
      key = segment
    end
    current[key] = val
  end

  def self.url_encode(s)
    CGI.escapeURIComponent(s.to_s)
  end

  def self.url_decode(s)
    # Not the input as-is: a request body is read as binary, and Rails hands every decoded param over as UTF-8 (commonmarker refuses ASCII-8BIT).
    unless s.include?("%") || s.include?("+")
      return s if s.encoding == Encoding::UTF_8
      utf8 = s.dup.force_encoding(Encoding::UTF_8)
      # Not retagged when the bytes are not UTF-8: a cookie name so tagged would raise at `to_sym`.
      return utf8.valid_encoding? ? utf8 : s
    end
    # Retagged, not taken as CGI.unescape tags it: CRuby's follows CGI.accept_charset, which an app may set to binary.
    CGI.unescape(s).force_encoding(Encoding::UTF_8)
  end
end
