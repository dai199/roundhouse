# frozen_string_literal: true
require "time"
require_relative "active_support_interval"
# Spinel-subset temporal intrinsics: ActiveSupport.parse_db_time /
# db_now. Sibling of the CRuby/JRuby overlay's
# ruby_overlay/runtime/active_support_time_parsing.rb, which shadows
# this file on those trees (dedupe last-wins) with the stdlib-backed
# implementation.
#
# The synthesized temporal-column readers call `parse_db_time`
# (apply_datetime_lowering runs on the spinel-shape emit too) and
# `Base#save`'s fill_timestamps calls `db_now`. Until spinel's
# unresolved-call gate turned strict (spinel 1356cb14), both calls
# silently no-op'd here — readers returned nil, stamps were skipped —
# because the spinel tree simply lacked the module (spinel#1661).
#
# Storage form is Rails' fixed-width "YYYY-MM-DD HH:MM:SS[.ffffff]"
# TEXT (implicitly UTC, `T` tolerated as the separator), so a
# positional parse is exact. Sub-second storage survives writes
# (db_now stamps it via Time#to_f) but truncates on read —
# `Time.utc` takes whole seconds; comparisons and strftime in the
# corpus are second-granularity, and JSON serializes from the raw
# string (`<col>_raw`), not the parsed Time.
module ActiveSupport
  # Date-only parse/format live in `active_support_date_parsing.rb`,
  # loaded only when `app_uses_date` (matz/spinel#7334).

  # ---- THE TEST CLOCK ------------------------------------------------
  #
  # `ActiveSupport.now` is the ONE time read in this runtime. Every
  # other one calls it — `db_now` below, `Duration#ago`/`#from_now`
  # beside it — so `travel_to` in the test harness can move the clock
  # for the whole app with a single write, and a model does not have to
  # know it is under test.
  #
  # ActiveSupport's own `TimeHelpers` do this by stubbing `Time.now`,
  # which needs a reopened built-in; the shared runtime cannot reopen
  # one, and spinel AOT cannot stub at all. A module function every
  # caller already routes through is the same seam without either.
  #
  # An ARRAY, not a module ivar: `TRANSPORTS` in broadcasts.rb holds
  # mutable module state the same way, and the literal `[0]` is what
  # pins the element type for spinel.
  #
  # PRODUCTION IS ZERO. Nothing outside the harness ever calls
  # `travel`, so `now` is `Time.now` plus a constant-folded 0.
  TRAVEL_OFFSET = [0]

  def self.travel_offset
    TRAVEL_OFFSET[0]
  end

  # `freeze_time`'s instant, whole seconds since the epoch; 0 = the
  # clock runs. Rails' `freeze_time` stubs `Time.now` to one value, so
  # two reads inside the block are EQUAL — an offset alone keeps
  # ticking between them.
  FROZEN_AT = [0]

  # Whole seconds relative to the real clock. `travel(0)` is Rails'
  # `travel_back`, which the harness runs after every test; it thaws a
  # frozen clock too.
  def self.travel(seconds)
    TRAVEL_OFFSET.clear
    TRAVEL_OFFSET << seconds
    FROZEN_AT.clear
    FROZEN_AT << 0
  end

  # Stop the clock at `seconds` (the harness's `freeze_time`).
  def self.freeze(seconds)
    FROZEN_AT.clear
    FROZEN_AT << seconds
  end

  def self.clock
    frozen = FROZEN_AT[0]
    return Time.at(frozen) if frozen != 0
    Time.now + TRAVEL_OFFSET[0]
  end

  def self.now
    ActiveSupport.present(clock)
  end

  # Hydrate the stored UTC instant, then land it in the app's zone —
  # Rails presents every AR temporal value in `config.time_zone`
  # REGARDLESS of the host's zone; `ActiveSupport.present` lands it in
  # that zone, which the boot sets as the runtime's default
  # (`ActiveSupport.set_default_zone`).
  # Doing the shift HERE rather than at each render site is what makes
  # strftime, iso8601 and pubDate agree without every call site knowing
  # about zones — the same seam the CRuby overlay's twin uses.
  #
  # The offset is DST-correct because libc resolves the instant against
  # the host's tzdata: America/Chicago is -0500 in July and -0600 in
  # January. Nothing is baked at compile time except the zone NAME.
  def self.parse_db_time(str)
    return nil if str.nil?
    return nil if str.length < 19
    # The stored TEXT carries fractional seconds — Rails' datetime(6)
    # writes ".418418" and so does our own db_now — and the CRuby
    # overlay's twin reads them (usec, via its regex). Reading whole
    # seconds only truncated every hydrated timestamp: campfire's
    # `updated_at.to_fs(:epoch)` answered `…596000` where Rails said
    # `…596418`, found by the room-page compare gate on the binary.
    # Fixed-position slicing with a digit walk, same no-regex rationale
    # as the fields above; digits beyond micros are ignored, a
    # non-digit ends the read (so a legacy "…16Z" contributes nothing).
    micros = 0
    if str.length > 20 && str[19, 1] == "."
      digits = 0
      while digits < 6
        c = str[20 + digits, 1]
        break if c.nil? || c.empty? || c < "0" || c > "9"
        digits += 1
      end
      if digits > 0
        micros = "#{str[20, digits]}000000"[0, 6].to_i
      end
    end
    # The micros go in as `Time.utc`'s seventh argument, NOT as a float
    # added afterwards. `t + 170926 / 1_000_000.0` lands at
    # .170925999, and `format_db_time` below then truncates it back to
    # .170925 — so a `created_at > ?` bound from a hydrated record
    # matched the record itself, and campfire's "page after" test
    # passed or failed on which microsecond the fixtures loaded in.
    t = Time.utc(
      str[0, 4].to_i, str[5, 2].to_i, str[8, 2].to_i,
      str[11, 2].to_i, str[14, 2].to_i, str[17, 2].to_i, micros
    )
    ActiveSupport.present(t)
  end

  def self.db_now
    t = ActiveSupport.now.utc
    format(
      "%04d-%02d-%02d %02d:%02d:%02d.%06d",
      t.year, t.mon, t.mday, t.hour, t.min, t.sec, t.usec
    )
  end

  # A temporal column as JSON: Rails serializes one through
  # `TimeWithZone#as_json` → `xmlschema(3)`, i.e. ISO8601 with exactly
  # three fractional digits and the app zone's offset
  # (`2023-05-08T05:28:49.595-05:00`), NOT the stored TEXT.
  #
  # `parse_db_time` above now lands the instant in the app's zone, so
  # the offset is the receiver's own — NOT a hardcoded "+00:00", which
  # would label local clock fields as UTC and be wrong by the offset.
  # The milliseconds are `usec / 1000`, formatted apart: strftime here
  # has no millisecond directive, and xmlschema(3) TRUNCATES (.027418 →
  # .027), which integer division does too. A monomorphized `as_json`
  # writer (lower::as_json_writer, `PairEncoding::ZonedTime`) is what
  # reaches this — lobsters' /hottest, one call per story.
  def self.json_time(str)
    t = parse_db_time(str)
    return nil if t.nil?
    t.strftime("%Y-%m-%dT%H:%M:%S") + format(".%03d", t.usec / 1000) + t.strftime("%:z")
  end

  # Normalize a temporal-writer value into the canonical storage form.
  # Time → stamped (same shape as db_now); nil → nil (nullable column
  # cleared: `self.banned_at = nil`); String passes through untouched.
  # The synthesized model writers (`banned_at=`) route every store
  # through this so column TEXT stays homogeneous and lexicographically
  # ordered.
  def self.format_db_time(value)
    return nil if value.nil?
    if value.is_a?(Time)
      t = value.utc
      # `usec`, not float arithmetic on `to_f`: a double near 2e9
      # seconds resolves to ~0.4 µs, so `((f - f.to_i) * 1e6).to_i`
      # lands a microsecond short of what `parse_db_time` read.
      return format(
        "%04d-%02d-%02d %02d:%02d:%02d.%06d",
        t.year, t.mon, t.mday, t.hour, t.min, t.sec, t.usec
      )
    end
    value
  end

  def self.parse_time(str)
    t = parse_fields(str, false)
    raise ArgumentError, "no time information in #{str.inspect}" if t.nil?
    t
  end

  def self.zone_parse(str)
    parse_fields(str, true)
  end

  # Not `Date._parse`'s every shape: a string outside these forms raises rather than parse to a different instant.
  def self.parse_fields(str, in_zone)
    raise TypeError, "no implicit conversion of nil into String" if str.nil?
    s = str.strip
    m = /\A(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:(?:T|\s+)(\d{1,2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?)?\s*(Z|UTC|GMT|[-+]\d{2}:?\d{2})?\z/i.match(s)
    return build_time(in_zone, m[1].to_i, m[2].to_i, m[3].to_i, m[4], m[5], m[6], m[7], m[8]) if m
    m = /\A(\d{4})(\d{2})(\d{2})\z/.match(s)
    return build_time(in_zone, m[1].to_i, m[2].to_i, m[3].to_i, nil, nil, nil, nil, nil) if m
    m = /\A(\d{1,2})\/(\d{1,2})\z/.match(s)
    return build_time(in_zone, -1, m[1].to_i, m[2].to_i, nil, nil, nil, nil, nil) if m
    m = /\A(\d{1,2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?\s*(Z|UTC|GMT|[-+]\d{2}:?\d{2})?\z/i.match(s)
    return build_time(in_zone, -1, -1, -1, m[1], m[2], m[3], m[4], m[5]) if m
    m = /\A(?:(?:sun|mon|tue|wed|thu|fri|sat)[a-z]*,?\s+)?(?:(\d{1,2})\s+)?(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?(?:\s+(\d{1,2})(?!\d),?)?(?:\s+(\d{4}))?(?:\s+(\d{1,2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?)?\s*(Z|UTC|GMT|[-+]\d{2}:?\d{2})?\z/i.match(s)
    if m
      mon = %w[jan feb mar apr may jun jul aug sep oct nov dec].index(m[2].downcase).to_i + 1
      day = m[1] ? m[1].to_i : (m[3] ? m[3].to_i : -1)
      year = m[4] ? m[4].to_i : -1
      return build_time(in_zone, year, mon, day, m[5], m[6], m[7], m[8], m[9])
    end
    return nil unless s =~ /\d|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|sun|mon|tue|wed|thu|fri|sat/i
    raise ArgumentError, "unsupported time format: #{str.inspect}"
  end

  # -1 marks a missing date part, filled from `now` the way ActiveSupport's `parts_to_time` does.
  def self.build_time(in_zone, year, mon, mday, hour_s, min_s, sec_s, frac, zone)
    now = ActiveSupport.now
    y = year < 0 ? now.year : year
    mo = mon < 0 ? now.mon : mon
    d = mday
    d = (year >= 0 || mon >= 0) ? 1 : now.mday if d < 0
    hour = hour_s ? hour_s.to_i : 0
    min = min_s ? min_s.to_i : 0
    sec = sec_s ? sec_s.to_i : 0
    usec = frac ? "#{frac}000000"[0, 6].to_i : 0
    raise ArgumentError, "argument out of range" if mo < 1 || mo > 12 || d < 1 || d > 31
    raise ArgumentError, "argument out of range" if hour > 24 || min > 59 || sec > 60
    # Not the zone's clock for `Time.parse`: Rails reads a zoneless string in the system zone there.
    return (in_zone ? ActiveSupport.local_time(y, mo, d, hour, min, sec, usec * 1000) : Time.local(y, mo, d, hour, min, sec, usec)) if zone.nil?
    z = zone.upcase
    t = Time.utc(y, mo, d, hour, min, sec, usec)
    return (in_zone ? ActiveSupport.present(t) : t) if z == "Z" || z == "UTC" || z == "GMT"
    digits = z.delete(":")
    offset = digits[1, 2].to_i * 3600 + digits[3, 2].to_i * 60
    offset = -offset if digits[0] == "-"
    shifted = t - offset
    in_zone ? ActiveSupport.present(shifted) : shifted.getlocal(offset)
  end

  # ActiveModel::Type::DateTime#cast, for an `attribute :x, :datetime` writer.
  # A subset of the strings Rails reads (ISO 8601 date, optional time, a zone only after seconds); any other string raises rather than read as a different instant.
  def self.cast_datetime(value)
    return nil if value.nil?
    return value if value.is_a?(Time)
    raise TypeError, "can't cast #{value.class} to a datetime" unless value.is_a?(String)
    return nil if value.empty?
    m = /\A(\d{4})-(\d\d)-(\d\d)(?:[T ](\d\d):(\d\d)(?::(\d\d)(?:\.(\d{1,6}))?(Z|[-+]\d\d:?\d\d)?)?)?\z/.match(value)
    raise ArgumentError, "unsupported datetime format: #{value.inspect}" if m.nil?
    year = m[1].to_i
    mon = m[2].to_i
    mday = m[3].to_i
    hour = m[4] ? m[4].to_i : 0
    min = m[5] ? m[5].to_i : 0
    sec = m[6] ? m[6].to_i : 0
    usec = m[7] ? "#{m[7]}000000"[0, 6].to_i : 0
    raise ArgumentError, "unsupported datetime format: #{value.inspect}" if mon < 1 || mon > 12
    days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mon - 1]
    days = 29 if mon == 2 && year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)
    raise ArgumentError, "unsupported datetime format: #{value.inspect}" if mday < 1 || mday > days || hour > 23 || min > 59 || sec > 59
    zone = m[8]
    # Rails' `is_utc?` is `Time.zone_default.name == "UTC"`. `GMT`, `Etc/UTC`, `Etc/GMT`, and `Etc/UCT` are not that name, so they take `Time.local` (the host zone). Boot does not pin `ENV["TZ"]`.
    if zone.nil?
      return Time.utc(year, mon, mday, hour, min, sec, usec) if Rails.application.config_time_zone == "UTC"
      return Time.local(year, mon, mday, hour, min, sec, usec)
    end
    t = Time.utc(year, mon, mday, hour, min, sec, usec)
    return t if zone == "Z"
    digits = zone.delete(":")
    offset = digits[1, 2].to_i * 3600 + digits[3, 2].to_i * 60
    offset = -offset if digits[0] == "-"
    (t - offset).getlocal(offset)
  end
end
