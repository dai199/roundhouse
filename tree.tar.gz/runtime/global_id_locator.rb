# frozen_string_literal: true
# `GlobalID::Locator.locate` — the READ side of the `gid://<app>/<Model>/<id>`
# identifier `GlobalID.param` mints in runtime/ruby/rails.rb.
#
# WHY IT IS HERE AND THE MINT IS THERE. The mint prices every target: a
# page renders `<turbo-cable-stream-source signed-stream-name="…">`
# whatever the runtime underneath it, so `GlobalID.param` transpiles
# eight ways. Locating prices only the lanes that have a subscribe path
# to run it on — a channel turning a stream name back into a record —
# and that is the spinel/ruby pair. Splitting them costs a drift risk
# (an encoder and a decoder in different files), which is why
# `tests/overlay_cable_dispatch.rb` round-trips `GlobalID.param`
# THROUGH this file rather than asserting either half against a literal.
#
# `only:` IS REQUIRED, AND IT IS THE FINDER. globalid 1.3.0 treats it as
# a filter and reflects the model name into a constant:
#
#   def locate(gid, options = {})
#     gid = GlobalID.parse(gid)
#     ... find_allowed?(gid.model_class, options[:only]) ... gid.find
#   end
#
# `gid.model_class` is `model_name.constantize`, and a constant computed
# from a wire string is the shape this pipeline will not emit — it is
# also the shape that lets a crafted name name any class in the process.
# So the caller's `only:` is what the record is found ON, and the model
# name in the URI is checked AGAINST it rather than resolved. campfire's
# one call site already passes it (`GlobalID::Locator.locate gid_param,
# only: Room`), so this is a narrowing of an API nobody used the wide
# half of, not a reinterpretation of the call.
#
# NIL for anything that is not one of OUR names — a truncated param, a
# different app's gid, a gid naming another model. `RecordNotFound` for
# a well-formed name whose record is gone, because that is `find`'s
# contract and campfire's `room_from` rescues exactly it.
require_relative "base64"

module GlobalID
  module Locator
    # `gid_param` is the urlsafe-base64 form (what a stream name carries);
    # `only` is the model class the caller will accept.
    #
    # THE GENERIC FORM, AND THE ONE A STRICT TARGET CANNOT RUN. `only`
    # arrives as a class OBJECT, so `only.name` and `only.find` need a
    # singleton to dispatch through; spinel has none and emits a call to
    # a class method `ActiveRecord::Base` never defines
    # (matz/spinel#4217). `lower::global_id_locate` rewrites every call
    # site whose `only:` is a literal class — which is all of them in
    # the corpus — to one of the generated `locate_<model>` entry points
    # below, so on a strict target nothing reaches this body and it is
    # not emitted. It stays for the Ruby lanes, where a class object
    # dispatches, and as the honest answer for a COMPUTED `only:`: that
    # call is left alone and refused at compile time rather than
    # rewritten to find on a class the caller did not name.
    def self.locate(gid_param, only:)
      parts = parts_from(gid_param)
      return nil if parts.nil?
      return nil unless parts[1] == only.name

      only.find(cast_id(parts[2]))
    end

    # `GlobalID::Locator.locate_signed(sgid, only:, for:)` — Rails'
    # signed GlobalID read. The sgid is MessageVerifier's
    # `message--hmac` envelope under salt `signed_global_ids` (same
    # envelope ActionText attachables use); `for:` is the purpose the
    # mint signed under. Verifies, then finds on the caller's `only:`
    # for the same reason unsigned `locate` does — the model name on
    # the wire is checked, never constantized.
    #
    # `lower::global_id_locate` rewrites a literal `only:` to a
    # generated `locate_signed_<model>(sgid, purpose)` entry point so
    # a strict target never dispatches through a class object.
    # `for` is a Ruby reserved word, so the keyword cannot be bound to
    # a plain local via `for: purpose` (that form is a DEFAULT of
    # `purpose`, not an alias). Pull it from `**opts` instead.
    def self.locate_signed(sgid, only:, **opts)
      purpose = opts[:for]
      parts = parts_from_signed(sgid, purpose)
      return nil if parts.nil?
      return nil unless parts[1] == only.name

      only.find(cast_id(parts[2]))
    end

    # One entry point per model class an `only:` names, with the finder
    # spelled as a literal constant. GENERATED —
    # `project::apply_global_id_locate` rewrites the span between the
    # markers from `App::global_id_locate_models`, the same
    # eager-arm shape `apply_cable_connection` uses for the connection
    # class. Empty for an app with no `locate` / `locate_signed` call
    # site. Unsigned and signed specializations share the marker span.
    # >>> generated: global-id-locate
    # <<< generated: global-id-locate

    # The `[app, model, id]` triple a well-formed gid carries, or nil
    # for anything that is not a name this app minted — a truncated
    # param, a different app's gid, a shape with the wrong arity.
    #
    # SHARED BY THE GENERIC FORM AND EVERY GENERATED ONE, so the two
    # cannot drift: a specialization differs from `locate` only in how
    # the finder is named, and that is the only line the generator
    # writes differently.
    def self.parts_from(gid_param)
      uri = decode(gid_param)
      return nil if uri.nil?
      parts_from_uri(uri)
    end

    # Signed half of `parts_from`: verify the sgid under `purpose`,
    # then split the URI it carries. Purpose is coerced with `to_s`
    # so a Symbol mint (`for: :markdown_uploads`) and a String mint
    # read the same way Rails does.
    def self.parts_from_signed(sgid, purpose)
      uri = verified_signed_uri(sgid, purpose)
      return nil if uri.nil? || uri == ""
      parts_from_uri(uri)
    end

    def self.verified_signed_uri(sgid, purpose)
      return "" if sgid.nil?
      json = ActionController::MessageVerifier.verified_data_json(
        Rails.application.secret_key_base,
        "signed_global_ids",
        sgid.to_s,
        purpose.to_s,
        true
      )
      return "" if json == ""
      ActionController::MessageVerifier.json_value(json)
    end

    # `gid://<app>/<Model>/<id>[?…]` — query stripped; anything with a
    # different shape is not a name this app minted.
    def self.parts_from_uri(uri)
      rest = uri.start_with?("gid://") ? uri[6..] : nil
      return nil if rest.nil?
      q = rest.index("?")
      rest = rest[0, q] unless q.nil?
      parts = rest.split("/")
      return nil unless parts.length == 3
      return nil unless parts[0] == Rails.application.global_id_app

      parts
    end

    # A malformed param is a nil, not a raise: the caller is deciding
    # whether to authorize a subscription, and "this is not a name I
    # minted" is an ordinary answer to that question.
    def self.decode(gid_param)
      return nil if gid_param.nil?
      value = Base64.urlsafe_decode64(gid_param.to_s)
      value.empty? ? nil : value
    rescue ArgumentError
      nil
    end

    # The id travels as text and the column is typically an integer.
    # Rails hands `find` the string and lets the attribute type cast it;
    # there is no such cast here, so an all-digit id becomes an Integer
    # and anything else (a uuid pk) is passed through unchanged.
    def self.cast_id(text)
      return text if text.empty?
      i = 0
      while i < text.length
        c = text[i]
        return text if c < "0" || c > "9"
        i = i + 1
      end
      text.to_i
    end
  end
end

# `ActionText::Attachable.locate` — the record an attachment's sgid
# names, for `ActionText::Attachment#attachable`. A REDEFINITION: the
# shared runtime (runtime/action_text.rb, whose `Attachable` module says
# why) carries a default that answers nil, and this reopen, required
# after it by both boots, replaces it with the app's own. The sgid has already verified and been split into a model
# name and an id by the time this is asked; what is left is the one step
# a shared runtime cannot take, turning the NAME into a finder. The
# models that mix `ActionText::Attachable` in are known at ingest, so
# `project::apply_attachable_locate` writes one `when` per model
# between the markers, spelled as a literal constant — the same reason
# and the same shape as the `locate_<model>` entry points above.
# `find_by`, not `find`: a row that is gone reads as nil, which
# `#attachable` turns into `MissingAttachable`, as Rails' rescue of
# `RecordNotFound` does.
module ActionText
  module Attachable
    # >>> generated: attachable-locate
    def self.locate(model_name, id)
      nil
    end
    # <<< generated: attachable-locate
  end

  # `ActionText::Attachment.permitted_without_signature` — the models
  # whose sgid resolves even when its signature FAILS. campfire's
  # `lib/rails_ext/action_text_attachables.rb` reopens `from_node` so
  # that rotating SECRET_KEY_BASE does not orphan every @mention, for
  # `%w[ User ]` alone; `ingest::on_load_reopen` reads that list off
  # the reopen and `project::apply_attachable_locate` writes it here
  # as a literal. The decode the reopen did by hand is
  # `SignedGlobalId.unverified_uri` in the shared runtime, and
  # `Attachment#attachable` consults this list only after the signed
  # read has failed. Empty for an app without the reopen, where a
  # tampered sgid is missing as it is in stock Rails.
  class Attachment
    # >>> generated: attachable-unsigned
    def self.permitted_without_signature
      []
    end
    # <<< generated: attachable-unsigned
  end
end
