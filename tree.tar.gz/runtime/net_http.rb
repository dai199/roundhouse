# frozen_string_literal: true
require "openssl"
# Net::HTTP, reopened over spinel's bundled `packages/net` so the stub
# table (`runtime/http_stub.rb`) is consulted BEFORE any socket opens.
#
# THE RUBY FAMILY NEVER LOADS THIS FILE. `project::ruby_runtime_files`
# swaps it for a bare `require "net/http"`: over there the real WebMock
# gem intercepts CRuby's own client, and a second `Net::HTTP` beside it
# would be a reopen of the wrong class. Same arrangement as `resolv.rb`.
#
# WHY A REOPEN AND NOT A SEPARATE DOUBLE. `Opengraph::Fetch` and
# `Webhook` are written against `Net::HTTP` by name — `Net::HTTP.start`,
# `Net::HTTP::Get.new`, `is_a?(Net::HTTPRedirection)`, `rescue
# Net::OpenTimeout` — so the double has to BE that constant. Reopening
# the package's class keeps every one of those names real (the response
# hierarchy in particular: `is_a?` on a bare struct answers nothing),
# and keeps the real transport reachable for a request no stub answers.
# Webhook delivery works on the spinel binary today through this
# class; a double that replaced it would have taken that away.
#
# WHAT IS REDEFINED, AND WHAT DELIBERATELY IS NOT.
#
# `#request` carries the stub lookup. It does NOT (yet) gain the block
# form the package lacks (matz/spinel#4420; measured 2026-09-10:
# `http.request(req) { |res| }` compiled and the block never ran — no
# error, no warning — so campfire's unfurl spun through MAX_REDIRECTS
# and raised TooManyRedirectsError): see the note on the method for
# what a yielding `request` cost the block-less callers.
#
# `#start` (the INSTANCE method) becomes lazy: it marks the client
# started and opens nothing. The package's `self.start` connects
# eagerly — it hands its block to `http.start`, which connects BEFORE
# yielding — which would put a real TLS connect to www.example.com
# ahead of any stub. Deferring the connect to the first request that no
# stub answers is what puts the double above the transport. The lazy
# `start` keeps CRuby's block form (yield, then finish in an ensure):
# since matz/spinel#8048 that is the only way the package's
# `self.start`, `get_response` and `post_form` reach their block.
#
# `self.start` is NOT redefined, and `ipaddr:` — the keyword campfire's
# DNS-rebinding pin is written on — is the PACKAGE's to honour: since
# matz/spinel#4420 closed (2026-09-10) `Net::HTTP.start` declares it and
# its connect connects to it while `Host:` and the TLS name stay
# `address`. Probed 2026-09-17: `Net::HTTP.start("example.com", 80,
# ipaddr: "127.0.0.1")` from a spinel binary fails with ECONNREFUSED on
# 127.0.0.1, exactly as CRuby does, so the pin holds on this lane. The
# TEST's proof of it — `TCPSocket.expects(:open).with { … }.throws` —
# is served by `connect_with_timeout` below asking `TcpSocketStub` about
# the address it is about to connect to, which is where CRuby's mocha
# would have intercepted `TCPSocket.open`. (#4416 and #4419, the
# reopened-yielding-class-method and dropped-keyword bugs this comment
# used to describe, closed the same day.)
#
# Last definition wins under spinel, and a redefined method sees the
# class's other methods and ivars — `transport_request` below is the
# package's `#request` body re-stated over `connect`/`begin_transport`
# (also defined below) and `write_request`/`read_response`, which this
# file leaves alone.
require "net/http"
require_relative "http_stub"
require_relative "tcp_socket_stub"

module Net
  class HTTPResponse
    # The slice a streaming reader takes at a time. `Opengraph::Fetch`
    # bails when the accumulated body crosses MAX_BODY_SIZE, and three
    # of its tests exist only to exercise that path — a `read_body` that
    # handed the whole String over in one yield would pass the happy
    # path and silently break all three.
    READ_BODY_CHUNK = 16384

    # Keep the package's reader, read-once checks and destination argument.
    # A stub already has a String body; bound its callback chunks as before.
    alias read_body_from_package read_body

    def read_body(dest = nil, &blk)
      if blk.nil?
        read_body_from_package(dest)
      else
        read_body_from_package(dest) do |chunk|
          offset = 0
          while offset < chunk.bytesize
            blk.call(chunk.byteslice(offset, READ_BODY_CHUNK).to_s)
            offset += READ_BODY_CHUNK
          end
        end
      end
    end
    private :read_body_from_package

    # Integer or nil, as CRuby answers it — `Opengraph::Fetch` applies
    # `.to_i` and compares, so nil has to survive the read.
    def content_length
      v = @headers["content-length"]
      v.nil? ? nil : v.to_i
    end
  end

  class HTTP
    # CRuby's positional form, `Net::HTTP.start(address, port, p_addr,
    # opt)`: the proxy fields come before a trailing options Hash.
    # `Opengraph::Fetch` writes `start(host, port, nil, ipaddr:, use_ssl:,
    # **timeouts)`, and with a `**` the keywords arrive as that one Hash,
    # which CRuby's `start(address, *arg)` reads off the end. The package's
    # keyword form stays as it was for a call that names them directly.
    #
    # `p_addr` nil is "no proxy", the only kind served; a proxy raises
    # rather than connecting direct. Of the options, `write_timeout` is
    # accepted and not enforced (the package bounds connects and reads,
    # not writes), and `max_retries` is moot: the package never retries.
    def self.start(address, port = nil, p_addr = nil, opt = nil,
                   use_ssl: false, ipaddr: nil, open_timeout: 60, read_timeout: 60)
      raise NotImplementedError, "Net::HTTP.start through a proxy is not supported here" unless p_addr.nil?
      unless opt.nil?
        use_ssl = opt[:use_ssl] == true
        ipaddr = opt[:ipaddr] unless opt[:ipaddr].nil?
        open_timeout = HTTP.timeout_seconds(opt[:open_timeout], open_timeout)
        read_timeout = HTTP.timeout_seconds(opt[:read_timeout], read_timeout)
      end
      http = HTTP.new(address, port.nil? ? (use_ssl ? 443 : 80) : port)
      http.use_ssl = use_ssl
      http.ipaddr = ipaddr.to_s
      http.open_timeout = open_timeout
      http.read_timeout = read_timeout
      http.start { |h| yield h }
    end

    # A timeout option as the package's whole seconds: an Integer, a
    # Float rounded UP (a limit is never shortened), or an
    # ActiveSupport::Duration (what campfire passes, whole seconds on this
    # runtime); absent, the default.
    def self.timeout_seconds(value, default)
      return default if value.nil?
      return value.to_i if value.is_a?(ActiveSupport::Duration)
      return value if value.is_a?(Integer)
      return value.ceil if value.is_a?(Float)
      default
    end

    # Lazy: started, but with no socket until a request needs one. The
    # package's `finish` closes whatever is open and clears the flags,
    # so a `start`/`finish` pair around nothing but stubbed requests
    # touches no descriptor at all.
    #
    # With a block: CRuby's block form, still lazy. Yield the session,
    # answer the block's value, finish in an ensure. A `start` that
    # dropped the block made `Net::HTTP.start(...) { |http|
    # http.request(req) }` answer the session and send nothing (see the
    # header). `finish if started?` rather than the package's
    # `do_finish`: `finish` raises IOError on a session the block already
    # finished, and `do_finish` is absent from packages before #8048.
    # `yield`, not the `&blk` `#request` needs: the package's own `start`
    # yields too, and every caller of it holds a typed `HTTP.new`.
    # Like CRuby's, it raises on a session that is already open, before
    # touching it, so a nested `start` can't finish the outer session.
    #
    # `if block_given? … else` rather than an early `return self unless
    # block_given?`: with the early return, spinel loses a `return` from
    # the caller's block through this ensure (matz/spinel#9511), and
    # `Opengraph::Fetch#fetch_document` ran its redirect loop out.
    def start
      raise IOError, "HTTP session already opened" if @started
      @started = true
      if block_given?
        begin
          yield self
        ensure
          finish if started?
        end
      else
        self
      end
    end

    # The URL this connection would put on the wire for `path`, in the
    # spelling `HttpStub.normalize` files stubs under.
    def stub_url(path)
      scheme = @use_ssl ? "https" : "http"
      default = @use_ssl ? 443 : 80
      host = @address.to_s.downcase
      authority = @port == default ? host : "#{host}:#{@port}"
      "#{scheme}://#{authority}#{path}"
    end

    # `http.request(req)`. A stub answers without a connection; otherwise
    # the package's own path runs. The response class comes from the
    # package's `build_response`, so a stubbed 302 IS a
    # `Net::HTTPRedirection` and a stubbed 200 a `Net::HTTPOK`.
    #
    # The block form is a declared `&blk` CALLED, not a `yield` — the
    # spelling the package itself settled on for matz/spinel#4420. A
    # method that yields is inlined at its call sites and has no entry
    # in spinel's dynamic dispatch, and `Webhook#http` comes back BOXED
    # (its return is emitted `sp_box_nullable_obj`), so a yielding
    # `request` left `http.request(post)` there with no arm at all:
    # `undefined method 'request' for an instance of Net::HTTP` in all
    # four delivery tests. A `&blk` parameter keeps the standalone
    # entry, so the block-less webhook call and `Opengraph::Fetch`'s
    # `request(req) { |res| … }` dispatch to the same method. The
    # response keeps its live reader through the callback and is drained
    # before the implicit session finishes.
    def request(req, &blk)
      started = @started
      start unless started
      i = HttpStub.find_for(req.method, stub_url(req.path), req.body)
      res =
        if i < 0
          transport_request(req)
        else
          build_response("1.1", HttpStub::STUB_STATUSES[i].to_s, "", HttpStub.headers_at(i), HttpStub::STUB_BODIES[i])
        end
      blk.call(res) unless blk.nil?
      # Keep #1753's body-before-finish guarantee after the live callback.
      res.body
      res
    ensure
      @tls.sysclose unless @tls.nil?
      @tls = nil
      @socket.close unless @socket.nil?
      @socket = nil
      finish if !started && started?
    end

    # The package's `connect_with_timeout`, re-stated over one question
    # to the socket seam: `TcpSocketStub.check` on the address this
    # connection is about to open — `ipaddr:` when the caller pinned one,
    # the hostname otherwise — and the port. With nothing filed it
    # answers nil and the connect proceeds exactly as the package wrote
    # it; a test's `TCPSocket.expects(:open)` throws or fails here, the
    # way mocha's replacement of `TCPSocket.open` does under CRuby.
    def connect_with_timeout
      limit = @open_timeout.nil? ? 0 : @open_timeout
      target = @ipaddr.empty? ? @address : @ipaddr
      # Spinel tip (9bac0daa+): `@port` is Integer? (sp_oint) while
      # `TcpSocketStub.check` / `TCPSocket.new` take Integer. Default to
      # the scheme port the same way `stub_url` does, so a definite
      # Integer reaches those calls.
      port = @port
      if port.nil?
        port = @use_ssl ? 443 : 80
      end
      TcpSocketStub.check(target, port)
      return TCPSocket.new(target, port) if limit <= 0
      s = Socket.new(Socket::AF_INET, Socket::SOCK_STREAM, 0)
      begin
        s.connect_nonblock(target, port)
      rescue IO::WaitWritable
        if IO.select(nil, [s], nil, limit).nil?
          s.close
          raise OpenTimeout
        end
        begin
          s.connect_nonblock(target, port)
        rescue Errno::EISCONN
          # already connected: the wait above is what completed it
        end
      end
      s
    end

    # The package's `#request`, re-stated: a request on an unstarted
    # client opens and closes around itself; a started one opens its
    # socket on first use (the lazy `start` above) and reconnects after
    # the `Connection: close` every response carries.
    #
    # Through CRuby's two private transport hooks, `connect` and
    # `begin_transport(req)`, so a subclass that overrides them sees them
    # run in CRuby's order: campfire's `WebPush::Connections::Stages`
    # records a connection's stage there and its pool reads it back to
    # tell a dead idle connection from a push the service may have
    # (`lower::known_super_forwarding` gives its `(...)` overrides these
    # signatures). Both are defined here rather than relied on from the
    # package, which names them only from matz/spinel#8361 on.
    def transport_request(req)
      connect if @socket.nil?
      begin_transport(req)
      write_request(req)
      read_response(req.method, req.decode_content)
    end

    # The package connects direct or not at all (`Net::HTTP.new` raises
    # given a proxy), so no connection here has one.
    def proxy?
      false
    end

    # CRuby's reuse window for an idle connection. Every response here
    # carries `Connection: close`, so nothing is reused and it governs
    # nothing; held so a pool that sets it reads back what it wrote.
    # (The package holds it too from matz/spinel#8361 on.) Unset reads as
    # CRuby's default, 2.
    def keep_alive_timeout
      @keep_alive_timeout.nil? ? 2 : @keep_alive_timeout
    end

    def keep_alive_timeout=(seconds)
      @keep_alive_timeout = seconds
    end

    def connect
      @socket = connect_with_timeout
      if @use_ssl
        begin
          tls = OpenSSL::SSL::SSLSocket.new(@socket)
        rescue NameError
          raise "net/http: an https request needs the openssl package (require \"openssl\")"
        end
        tls.hostname = @address
        tls.connect
        @tls = tls
      end
      @fresh = true
      nil
    end

    # Connects again unless the socket was opened for this request: every
    # response carries `Connection: close`.
    def begin_transport(req)
      unless @fresh
        @tls.sysclose unless @tls.nil?
        @socket.close unless @socket.nil?
        @tls = nil
        @socket = nil
        connect
      end
      @fresh = false
      nil
    end
    private :connect, :begin_transport
  end
end

module Net
  class HTTP
    # net-http-persistent's client, as far as campfire reaches it:
    # `WebPush::Pool` builds one per process (`name:`, `pool_size:`),
    # hands it to every delivery as `connection:`, and shuts it down at
    # exit; the gem's own `WebPush::Request` then calls `request(uri,
    # req)` on it. The ruby family has the real gem (`RUNTIME_GEMS`).
    #
    # NOTHING IS KEPT ALIVE HERE, and that is spinel's client rather
    # than a choice of this file's: the package speaks `Connection:
    # close` on every response (see `transport_request` above), so a
    # "persistent" connection on this lane is a client opened per
    # request. The pool-size and name are accepted and unused. What is
    # honoured is the interface — a caller holding one of these can
    # send a request through it and get the package's response back,
    # stub table included.
    class Persistent
      def initialize(name: nil, pool_size: nil)
        @name = name.to_s
      end

      def name
        @name
      end

      def request(uri, req)
        http = Net::HTTP.new(uri.host, uri.port)
        http.use_ssl = (uri.scheme == "https")
        http.request(req)
      end

      def shutdown
        nil
      end
    end
  end
end
