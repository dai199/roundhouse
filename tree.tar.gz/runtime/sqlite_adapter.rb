# frozen_string_literal: true
# Generic ActiveRecord adapter facade routed through the `Db.*` primitive
# surface. Implements the 10-method contract that AR Base's `_adapter_*`
# defaults call into when a model hasn't received the lowerer's Level-3
# emit (real-blog models all do; this code path is a documented fallback).
#
# Same source compiles under both Db variants:
#   - `runtime/db.rb` = `db_cruby.rb` (gem-backed) under CRuby
#   - `runtime/db.rb` = `db.rb`       (FFI-backed) under spinel-AOT
# No SQLite3 / FFI references appear here directly; everything goes
# through Db.exec / Db.prepare / Db.column_*.
#
# SQL composition uses Db.escape_string / Db.escape_int rather than
# placeholder bind params — the FFI shim can't construct SQLITE_TRANSIENT
# for bind_text, so the shared contract is "inline escaped values".
module SqliteAdapter
  # Quote one schema-validated SQL identifier (not a value); SQLite
  # doubles embedded quotes and accepts this SQL-standard spelling.
  def self.quote_column_name(name)
    "\"#{name.to_s.gsub("\"", "\"\"")}\""
  end

  def self.configure(database_path)
    Db.configure(database_path)
  end

  # Writes run with their values written in: a Relation's bind marks
  # (`Relation#bind_literal`) are dropped here, not lifted.
  def self.execute_ddl(sql)
    Db.exec(ActiveRecord::Relation.inline_sql(sql))
  end

  # Rows affected by the last INSERT/UPDATE/DELETE — Rails'
  # `delete_all`/`update_all` return this count.
  def self.changes
    Db.changes
  end

  def self.all(table)
    select_rows("SELECT * FROM #{table}")
  end

  def self.find(table, id)
    rows = select_rows("SELECT * FROM #{table} WHERE id = #{Db.escape_int(id)} LIMIT 1")
    rows.empty? ? nil : rows[0]
  end

  def self.where(table, conditions)
    sql = "SELECT * FROM #{table}"
    sql += " WHERE #{build_where(conditions)}" unless conditions.empty?
    select_rows(sql)
  end

  def self.count(table)
    stmt = Db.prepare("SELECT COUNT(*) FROM #{table}")
    n = Db.step?(stmt) ? Db.column_int(stmt, 0) : 0
    Db.finalize(stmt)
    n
  end

  def self.exists?(table, id)
    stmt = Db.prepare("SELECT 1 FROM #{table} WHERE id = #{Db.escape_int(id)} LIMIT 1")
    found = Db.step?(stmt)
    Db.finalize(stmt)
    found
  end

  def self.insert(table, attrs)
    cols = attrs.keys
    values = cols.map { |k| escape_value(attrs[k]) }
    sql = "INSERT INTO #{table} (#{cols.join(", ")}) VALUES (#{values.join(", ")})"
    Db.exec(sql)
    Db.last_insert_rowid
  end

  def self.update(table, id, attrs)
    assigns = attrs.keys.map { |k| "#{k} = #{escape_value(attrs[k])}" }
    sql = "UPDATE #{table} SET #{assigns.join(", ")} WHERE id = #{Db.escape_int(id)}"
    Db.exec(sql)
  end

  def self.delete(table, id)
    Db.exec("DELETE FROM #{table} WHERE id = #{Db.escape_int(id)}")
  end

  # `Model.delete_all` — bulk row delete with ActiveRecord semantics:
  # rows go, the autoincrement counter stays (unlike `truncate`).
  def self.delete_all(table)
    Db.exec("DELETE FROM #{table}")
  end

  # Adapter-agnostic table reset (test setup). Issues both the row
  # delete and the autoincrement-counter reset so subsequent inserts
  # start from id=1.
  def self.truncate(table)
    Db.exec("DELETE FROM #{table}")
    Db.exec("DELETE FROM sqlite_sequence WHERE name = #{Db.escape_string(table)}")
  end

  # Internal helpers — walk a prepared statement and build a row hash
  # keyed by column name. Values read through `Db.column_value` — the
  # driver's NATIVE types (Integer/Float/String, nil for NULL), which
  # is what ActiveRecord hands the app: `group_by(&:fk)[nil]` finds
  # root rows, integer columns compare as integers, and `pluck(:fk)`
  # returns keys that match the ones model attributes carry. All three
  # shims answer this now, the FFI one by storage-class dispatch. Each
  # row is its own Hash so the caller gets a stable copy after
  # `finalize`.
  #
  # `each_row` yields each row Hash as it is read; `select_rows` collects
  # them. Hydration (`instantiate`) goes through `each_row`: Spinel can
  # only type an Array of Hashes as a polymorphic array, so an element
  # taken from `select_rows` reaches `<Model>Row.from_raw` boxed and
  # widens its parameter, while a yielded row stays a Hash.
  #
  # The statement is finalized in an `ensure`, as the generated readers
  # do: a block that raises (an `instantiate(row)` that fails) must not
  # leave it checked out on the connection until the lease ends — or,
  # outside `Db.with_connection`, until `Db.close`.
  def self.each_row(sql)
    stmt = Db.prepare(sql)
    begin
      ncols = Db.column_count(stmt)
      # Column names can't change between rows — resolve them once, not
      # rows×cols times (each column_name is a shim call, and hydrating
      # a 1000-row result was paying 24,000 of them).
      names = []
      i = 0
      while i < ncols
        names.push(Db.column_name(stmt, i))
        i += 1
      end
      while Db.step?(stmt)
        row = {}
        i = 0
        while i < ncols
          row[names[i]] = Db.column_value(stmt, i)
          i += 1
        end
        yield row
      end
    ensure
      Db.finalize(stmt)
    end
    nil
  end

  def self.select_rows(sql)
    rows = []
    each_row(sql) { |row| rows << row }
    rows
  end

  def self.build_where(conditions)
    conditions.map { |k, v| "#{k} = #{escape_value(v)}" }.join(" AND ")
  end

  # A bind value rendered as SQL text.
  #
  # A Time goes through `ActiveSupport.format_db_time`, the SAME writer
  # every temporal COLUMN is stored with, and that is the whole point:
  # comparison here is string-vs-string, so a bind written in any other
  # format silently answers the wrong rows rather than erroring.
  # `Time#to_s` is that other format — it renders local time with a
  # zone offset (`2026-08-22 15:30:00 -0400`) where the column holds
  # UTC with microseconds (`2026-08-22 19:30:00.123456`). Both start
  # with the same date, so the comparison reaches the HOUR and answers
  # on the zone difference: campfire's `where("created_at < ?",
  # message.created_at)` matched NOTHING and its `>` twin matched
  # EVERYTHING, which is a message list paginating backwards into an
  # empty page and forwards into the whole room.
  def self.escape_value(v)
    if v.is_a?(Integer)
      Db.escape_int(v)
    elsif v == true
      # The database's own literal: SQLite's 1, PostgreSQL's TRUE (which
      # compares with no integer).
      Db.escape_bool_opt(true)
    elsif v == false
      Db.escape_bool_opt(false)
    elsif v.nil?
      "NULL"
    elsif v.is_a?(Time)
      Db.escape_string(ActiveSupport.format_db_time(v).to_s)
    elsif defined?(Date) && v.is_a?(Date)
      # `time` can load Date even when the app has no date columns and
      # the optional ActiveSupport date helpers were omitted. Quote the
      # civil day directly, including for a DateTime receiver.
      date = defined?(DateTime) && v.is_a?(DateTime) ? Date.new(v.year, v.month, v.day) : v
      Db.escape_string(date.strftime("%Y-%m-%d"))
    else
      Db.escape_string(v.to_s)
    end
  end
end
