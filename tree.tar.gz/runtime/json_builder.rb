# frozen_string_literal: true
# JSON encoding primitives used by Views::*.<x>_json render methods —
# the lowered output of `*.json.jbuilder` templates. Hand-rolled to drop
# the stdlib `json` dependency (which spinel doesn't ship), and to keep
# the surface small enough that the same Ruby transpiles cleanly to
# every Group 1 target.
#
# Scope: three primitives the Jbuilder lowerer needs for real-blog
# templates — encode_string (RFC 8259 escaping for the common cases),
# encode_value (type-dispatched scalar encoder), and encode_datetime
# (Rails-compatible ISO 8601 reformat for `datetime` columns). The
# lowerer inlines `{`/`,`/`}` and `[`/`,`/`]` directly into method
# bodies, so the runtime has no array_join / object_pairs primitive
# today; those land when stretch DSL forms (json.merge!, dynamic-shape
# objects) need them.
#
# Decimal handling is still the lowerer's job: call sites pass strings
# or pre-formatted values. encode_datetime is bundled here because the
# input is uniformly a sqlite-shape TEXT timestamp and the output
# format is Rails-canonical; doing the reformat in the runtime keeps
# the lowerer's column-aware routing simple (just "is this column a
# datetime, yes or no").
module JsonBuilder
  ESCAPES = {
    "\\" => "\\\\",
    "\"" => "\\\"",
    "\n" => "\\n",
    "\r" => "\\r",
    "\t" => "\\t",
    "\b" => "\\b",
    "\f" => "\\f",
    # ActiveSupport's `escape_html_entities_in_json` (on by default), so
    # a value can sit inside a `<script>` or an HTML attribute: Lexxy's
    # attachment `content` does. The JS line separators U+2028/U+2029
    # are left alone, as `load_defaults` 8.1+ leaves them.
    "<" => "\\u003c",
    ">" => "\\u003e",
    "&" => "\\u0026",
  }.freeze

  # `\x08` rather than `\b` for the backspace because Rust's `regex`
  # crate rejects `\b` inside a character class (where it would
  # otherwise be word-boundary, which makes no sense inside `[]`).
  # Ruby/JS/Crystal/RE2 all accept the hex escape, so this is the
  # cross-target spelling.
  ESCAPE_PATTERN = /[\\"\n\r\t\x08\f<>&]/.freeze
  # Some targets flatten runtime constants; keep this distinct from ViewHelpers.
  JSON_HTML_ESCAPE_PATTERN = /[<>&]/.freeze

  # Escape a string for embedding inside JSON double-quotes. Does
  # NOT add the surrounding quotes — `encode_value` wraps a String
  # value in quotes; callers building object keys interpolate the
  # raw escape result inside their own `"…"`.
  #
  # Non-nil contract: callers (encode_value, encode_datetime, lowered
  # template bodies) narrow nil before reaching here. Strict-typed
  # targets (Rust, Crystal) compile against `String` directly without
  # Option-wrapping at every call site.
  def self.encode_string(s)
    s.gsub(ESCAPE_PATTERN, ESCAPES)
  end

  # Apply Rails' default HTML-entity escaping to an already encoded JSON
  # document. These characters occur only inside JSON strings, so escaping
  # the document preserves its structure and existing JSON escapes.
  def self.escape_html_entities(json)
    json.gsub(JSON_HTML_ESCAPE_PATTERN, ESCAPES)
  end

  # The generic targets retain the prior response policy. Ruby, JRuby
  # and Spinel replace this method in the JSON renderer overlay, where
  # the application's Rails configuration is available.
  def self.escape_json_response(json, jsonp = false)
    escape_html_entities(json)
  end

  def self.jsonp(json, callback)
    "/**/#{callback}(#{json})"
  end

  # A Float as Rails' encoder sees it: NaN and the infinities are written
  # `null` (`Float#as_json`), where `JSON.generate` raises on them. The
  # lowerer wraps each Float leaf of a payload it hands `JSON.generate`.
  def self.finite_float(v)
    return nil if v.nil?
    # Not `finite?`, which not every target's Float answers.
    return nil if v - v != 0.0
    v
  end

  # Render a scalar Ruby value as its JSON fragment, complete with
  # surrounding quotes for strings. Returns a String the lowered
  # body can concatenate directly into the io accumulator.
  def self.encode_value(v)
    return "null" if v.nil?
    return "true" if v.is_a?(TrueClass)
    return "false" if v.is_a?(FalseClass)
    return v.to_s if v.is_a?(Integer)
    # Not `finite?`, which not every target's Float answers: NaN and the infinities are the values `v - v` is not 0.0 for, and Rails writes them `null`.
    return (v - v == 0.0 ? v.to_s : "null") if v.is_a?(Float)
    return "\"#{encode_string(v)}\"" if v.is_a?(String)
    # An Array value (`json.tags([a, nil])`) is a JSON array of its
    # elements, each encoded as a value is; not its `to_s`.
    return "[" + v.map { |e| encode_value(e) }.join(",") + "]" if v.is_a?(Array)
    # A Hash (an element of such an Array: `json.tags([{name: "b"}])`) is
    # a JSON object: String keys, each value encoded as a value is. Over
    # `keys` with a one-parameter block, the shape every target that
    # transpiles this file iterates.
    if v.is_a?(Hash)
      return "{" + v.keys.map { |k| "\"#{encode_string(k.to_s)}\":" + encode_value(v[k]) }.join(",") + "}"
    end
    # Fallback: stringify and quote. Call sites convert Time /
    # BigDecimal / etc. before reaching here.
    "\"#{encode_string(v.to_s)}\""
  end

  # An Array of Strings as a JSON array — the one non-scalar value a
  # monomorphized `as_json` writer hands over (lobsters Story's
  # `tags: tags.map(&:tag).sort`). Typed `Array[String]` rather than a
  # walk over `untyped` elements: the writer routes a value here only
  # when analysis typed it so, and a mixed array is declined upstream
  # instead of encoded by guess.
  def self.encode_string_array(values)
    "[" + values.map { |v| "\"#{encode_string(v)}\"" }.join(",") + "]"
  end

  # An integer-backed enum column as Rails serializes it: the LABEL,
  # not the stored integer (`json.(user, :role)` renders `"bot"`, the
  # reader `user.role` in Rails answers the label too). `labels` is
  # the declaration's order, so the stored value indexes it; a value
  # outside it is `null`, which is what Rails' reader answers for a
  # stored integer no label maps to.
  #
  # A plain Integer, never nil: the jbuilder lowerer routes only a
  # NOT NULL enum column here (a nullable one keeps `encode_value`), so
  # no strict target has to narrow an `Integer?` — neither Rust's nor
  # Swift's emit does past a `nil?` guard.
  def self.encode_enum(labels, value)
    return "null" if value < 0 || value >= labels.length
    "\"#{encode_string(labels[value])}\""
  end

  # Reformat a sqlite-shape TEXT timestamp ("YYYY-MM-DD HH:MM:SS[.f]")
  # to Rails-canonical ISO 8601 with millisecond precision and a `Z`
  # suffix ("YYYY-MM-DDTHH:MM:SS.fffZ"). Returns a JSON-quoted string.
  # Inputs that don't match the expected shape pass through as plain
  # quoted strings, so the call site degrades gracefully if a column
  # the lowerer routed here turns out to hold non-timestamp text.
  #
  # Assumes UTC — adapters that store local-time timestamps without
  # an offset can't be reliably normalized without per-app config; the
  # Rails default is UTC for ActiveRecord-managed datetime columns,
  # which is what real-blog produces.
  def self.encode_datetime(s)
    return "null" if s.nil?
    # A `Time` value never reaches this primitive: the Jbuilder lowerer
    # routes a temporal column through its `<col>_raw` storage reader
    # (the stored ISO-8601 TEXT), never the parsing `<col>` reader. The
    # string→string reformat is exact — no float sub-second hazards —
    # and skips a native parse→format round-trip per row. Keeping `Time`
    # out of this file is also what lets it transpile cleanly to targets
    # with no `Time` type.
    str = s.to_s
    return "\"#{encode_string(str)}\"" if str.length < 19
    date = str[0, 10]
    time = str[11, 8]
    ms = "000"
    if str.length > 20 && str[19, 1] == "."
      # `str[20..]` (open-ended) rather than `str[20..-1]`. Both
      # forms now lower correctly on every target — the TS emit's
      # `Range { end: -1, inclusive }` path was fixed to produce
      # `str.slice(20)` instead of the old `str.slice(20, -1 + 1)`
      # = `str.slice(20, 0)` = empty (zeroed-out fractional
      # seconds). Keep the open-ended idiom: it's the Ruby 2.6+
      # convention and the lowering is unambiguous.
      frac = str[20..]
      padded = "#{frac}000"
      ms = padded[0, 3]
    end
    "\"#{date}T#{time}.#{ms}Z\""
  end
end
