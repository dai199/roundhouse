# frozen_string_literal: true
# Active Storage — what a `has_one_attached` reader hands back, the
# blob it points at, and the identity "variant" of that blob.
#
# Sits beside `ActionText::Content` and for the same reason: the
# proxy has no table, so it is framework Ruby rather than a
# synthesized model. The ROWS (`active_storage_attachments`,
# `active_storage_blobs`) are read and written here with raw SQL
# through the adapter, the way `Relation` itself composes.
#
# # Three halves, and where each lives
#
# Active Storage is three things: attachment ROWS (which record, which
# blob, under which name), BLOBS (bytes in a service), and VARIANTS
# (derivatives produced by an image processor).
#
# * ROWS are fully modeled here, in the shared runtime: `attached?`,
#   `filename`, `content_type`, `attach`, `purge`, and the preload the
#   batch loader drives.
# * BLOB BYTES go through `ActiveStorage::Service`, whose methods here
#   RAISE: the shared runtime does no file I/O anywhere (grep it), so
#   a storage service is a per-target seam. The ruby family reopens the
#   class with a disk service (`runtime/spinel/active_storage_disk.rb`)
#   under Rails' own `storage/files/<xx>/<yy>/<key>` layout. `Blob
#   .create_and_upload!` and `Attached#attach` write the ROW here and
#   hand the bytes to the service, so a target that has one gets the
#   whole feature and a target that has none fails at the one named
#   seam.
# * VARIANTS are Rails' `VariantWithRecord`: the ROWS
#   (`active_storage_variant_records` + the record's `image`
#   attachment) are modeled here, the PIXELS are a per-target seam.
#   `has_one_attached :logo do |attachable| attachable.variant :large,
#   resize_to_limit: [512, 512], format: :png end` is lowered into the
#   proxy's constructor as `Variation` values; `variant(:large)`
#   answers a `VariantWithRecord` over the blob and that variation, and
#   `.processed` finds the variant record or makes one — downloading
#   the original, handing it to `Processor.transform`, uploading the
#   result as a blob of its own. `Processor` RAISES in the shared
#   runtime (it decodes and encodes images); the ruby family reopens it
#   over ruby-vips (`runtime/spinel/active_storage_processor.rb`), and
#   a tree without that reopen fails at the one named seam rather than
#   serving the original as its own thumbnail. `variable?` is Rails'
#   content-type question (can a variant be MADE from this), answered
#   from `variable_content_types`, so an image goes down the image
#   path and a PDF down the link path exactly as in Rails.
#   `preview` (a poster frame for a video, a page for a PDF) has no
#   previewer — there is no still to serve — so it raises, and
#   `previewable?` is false so no view reaches it.
#
# # The reader never returns nil
#
# Rails' `record.logo` is an `Attached::One` proxy whether or not
# anything is attached, which is why app code writes `logo.attached?`
# and `logo.variable?` without a nil guard. The reader keeps that
# contract by always constructing one of these.
module ActiveStorage
  # Rails' default `config.active_storage.variable_content_types`: the
  # image types a processor could make a variant from. A content-type
  # question, not a bytes question, which is why it can be answered
  # here. An app that trims the list in an initializer (campfire drops
  # bmp/ico/psd, whose loaders it does not trust) has the trim lifted
  # onto its `Rails::Application` reopen at ingest, and `variable?`
  # honours it: a bmp avatar falls back to initials here as it does
  # there.
  def self.default_variable_content_types
    ["image/png", "image/gif", "image/jpeg", "image/tiff", "image/bmp",
     "image/vnd.adobe.photoshop", "image/vnd.microsoft.icon", "image/webp",
     "image/avif", "image/heic", "image/heif"]
  end

  def self.variable_content_types
    excluded = Rails.application.active_storage_excluded_content_types
    out = []
    default_variable_content_types.each do |t|
      out << t unless excluded.include?(t)
    end
    out
  end

  def self.variable_content_type?(content_type)
    variable_content_types.include?(content_type)
  end

  # Rails' `ActiveStorage.paths` — executable locations for previewers /
  # analyzers (`:ffmpeg`, `:ffprobe`, `:mutool`). Default `{}` means
  # PATH lookup. Tests and config assign `paths[:ffmpeg] = "/bin/…"`.
  def self.paths
    @paths = {} if @paths.nil?
    @paths
  end

  def self.paths=(value)
    @paths = value
    value
  end

  # Rails' `config.active_storage.video_preview_arguments` — the ffmpeg
  # argv fragment after `-i <path>`. Default matches the filter the
  # ruby-family poster reopen draws with; an initializer override
  # (campfire adds `gte(t,5)`) is lifted onto the Application reopen
  # at ingest. Suite pins and `Previewer.poster` both read this.
  def self.video_preview_arguments
    Rails.application.active_storage_video_preview_arguments
  end

  # The `-vf` filter expression peeled from `video_preview_arguments`.
  # One Rails knob, one Application override; the poster reopen takes
  # this alone (it already passes `-frames:v` / `-f image2`).
  # Falls back to the framework default filter when the argv has no
  # quoted `-vf` value — never feeds the whole argv into `-vf`.
  def self.video_preview_vf_filter
    args = video_preview_arguments
    default = "select=eq(n\\,0)+eq(key\\,1)+gt(scene\\,0.015),loop=loop=-1:size=2,trim=start_frame=1"
    # Match `-vf` as a whole option (not a prefix of `-vframes`).
    i = 0
    found = nil
    while i < args.length
      j = args.index("-vf", i)
      if j.nil?
        break
      end
      before_ok = j == 0 || args[j - 1] == " "
      after = args[j + 3]
      after_ok = after.nil? || after == " " || after == "'" || after == "\""
      if before_ok && after_ok
        found = j
        break
      end
      i = j + 1
    end
    if found.nil?
      return default
    end
    rest = args[(found + 3)..-1].to_s
    while rest.start_with?(" ")
      rest = rest[1..-1].to_s
    end
    quote = rest[0]
    if quote != "'" && quote != "\""
      return default
    end
    body = rest[1..-1].to_s
    j = body.index(quote)
    if j.nil?
      return default
    end
    body[0...j]
  end

  # Rails' `config.active_storage.previewers` — class list used for
  # identity checks (`assert_includes ActiveStorage.previewers, …`).
  # Default is the video previewer only (RH does not ship PDF
  # previewers). A VideoPreviewer → replacement map on the Application
  # reopen (campfire: TimeLimitedVideoPreviewer) is lifted at ingest.
  def self.previewers
    Rails.application.active_storage_previewers
  end

  # Marcel's answers for the formats a variation can name, so the
  # variant blob's `content_type` column is what Rails would write.
  def self.content_type_for_format(format)
    f = format.downcase
    if f == "png"
      "image/png"
    elsif f == "jpg" || f == "jpeg"
      "image/jpeg"
    elsif f == "gif"
      "image/gif"
    elsif f == "webp"
      "image/webp"
    elsif f == "avif"
      "image/avif"
    else
      "application/octet-stream"
    end
  end

  # The format a variant keeps when its variation names none: a web
  # image's own (Rails' `web_image_content_types` — png, jpeg, gif,
  # webp), and PNG for anything else (tiff, bmp, heic, …) — Rails'
  # `default_variant_format`.
  def self.format_for_content_type(content_type)
    if content_type == "image/png"
      "png"
    elsif content_type == "image/jpeg"
      "jpg"
    elsif content_type == "image/gif"
      "gif"
    elsif content_type == "image/webp"
      "webp"
    else
      "png"
    end
  end

  # The filename without its extension — Rails' `Filename#base`, which
  # names a variant "<base>.<format>".
  def self.filename_base(filename)
    dot = filename.rindex(".")
    dot.nil? || dot == 0 ? filename : filename[0, dot].to_s
  end

  # Marcel's filename half when `attach(io:, filename:)` omits
  # `content_type:` — the MIME registry by extension, else octet-stream.
  # Byte sniffing stays with `ImageAnalyzer` after the bytes exist.
  def self.content_type_for_filename(filename)
    ext = Filename.new(filename).extension_without_delimiter
    looked = Mime::Type.lookup_by_extension(ext)
    looked.nil? ? "application/octet-stream" : looked.to_s
  end

  # Where the blob's file lives, keyed by the blob's `key` column.
  #
  # Every method RAISES: no storage service is modeled in the shared
  # runtime, and a plausible answer (an empty string for `download`, a
  # path nothing wrote to) would be a page that renders a broken image
  # — the failure that looks like success. The ruby family reopens this
  # class with a disk implementation; the methods stay the contract.
  #
  # A class rather than a module because `Blob.service` is a SINGLETON
  # in Rails and app code chains off it (`ActiveStorage::Blob.service
  # .path_for(key)`); keeping the shape means the call site needs no
  # rewrite when a real service is present.
  class Service
    def path_for(key)
      raise NotImplementedError,
            "ActiveStorage::Service#path_for: no storage service on this " \
            "target — the shared runtime does no file I/O"
    end

    def upload(key, data)
      raise NotImplementedError,
            "ActiveStorage::Service#upload: no storage service on this " \
            "target — the shared runtime does no file I/O"
    end

    def download(key)
      raise NotImplementedError,
            "ActiveStorage::Service#download: no storage service on this " \
            "target — the shared runtime does no file I/O"
    end

    def delete(key)
      raise NotImplementedError,
            "ActiveStorage::Service#delete: no storage service on this " \
            "target — the shared runtime does no file I/O"
    end

    def exist?(key)
      raise NotImplementedError,
            "ActiveStorage::Service#exist?: no storage service on this " \
            "target — the shared runtime does no file I/O"
    end
  end

  # The image processor behind `VariantWithRecord#processed`: the
  # original's bytes and content type in, the variant's bytes out, under
  # the variation's resize and format. RAISES here for the reason
  # `Service` does — decoding an image is not something the shared
  # runtime can do, and answering the original's bytes would serve an
  # upload at full size under a thumbnail's name, the failure that
  # looks like success. The ruby family reopens it over ruby-vips
  # (`runtime/spinel/active_storage_processor.rb`), a spin package on
  # the spinel tree and the gem on the CRuby one, with the same subset
  # surface on both.
  class Processor
    def self.transform(data, content_type, variation)
      raise NotImplementedError,
            "ActiveStorage::Processor.transform: no image processor on this " \
            "target — variants need ruby-vips (see spin.toml / Gemfile)"
    end
  end

  # Rails' generic Active Storage exception base (`activestorage/errors.rb`).
  # Concrete errors hang off this so `rescue ActiveStorage::Error` matches.
  class Error < StandardError
  end

  # The remaining exceptions in Rails 8.1's active_storage/errors.rb.
  class InvariableError < Error
  end

  class UnpreviewableError < Error
  end

  class UnrepresentableError < Error
  end

  class IntegrityError < Error
  end

  class FileNotFoundError < Error
  end

  class InvalidKeyError < Error
  end

  # Rails' `ActiveStorage::PreviewError` — raised when a previewer cannot
  # draw a poster (ffmpeg failed, timed out, …). Apps and railties rescue
  # or raise it; campfire's `TimeLimitedVideoPreviewer` raises it when
  # the wall-clock limit trips. Parent is `Error`, not bare StandardError,
  # matching Rails.
  class PreviewError < Error
  end

  # Nested exceptions keep their Rails owners as well as their parents.
  class Service
    class GCSService < Service
      class MetadataServerError < ActiveStorage::Error
      end

      class MetadataServerNotFoundError < ActiveStorage::Error
      end
    end
  end

  module Transformers
    class Transformer
    end

    class ImageProcessingTransformer < Transformer
      class UnsupportedImageProcessingMethod < StandardError
      end

      class UnsupportedImageProcessingArgument < StandardError
      end
    end
  end

  # The video previewer's swap point. Drawing is the class-side
  # `Previewer.poster` (ffmpeg on the ruby family); Rails' instance API
  # lives under the nested `VideoPreviewer` so an app can subclass it
  # (`TimeLimitedVideoPreviewer < ActiveStorage::Previewer::VideoPreviewer`)
  # without a NameError at boot. The shared `poster` raises, as
  # `Processor` does: nothing here can run a program, and answering
  # the video's own bytes as its poster would put them in an `<img>`.
  # The ruby family reopens `poster` over ffmpeg
  # (`runtime/spinel/active_storage_previewer.rb`), the same command
  # Rails runs; a tree without ffmpeg raises there the way Rails does.
  class Previewer
    # The PNG poster frame of the video stored at `path`.
    def self.poster(path)
      raise NotImplementedError,
            "ActiveStorage::Previewer.poster: no previewer on this target — " \
            "a video poster needs ffmpeg"
    end

    # Rails' `ActiveStorage::Previewer::VideoPreviewer`. This base class
    # exists so `class TimeLimitedVideoPreviewer < …::VideoPreviewer`
    # (and `config.active_storage.previewers` identity checks against
    # that constant) resolve. Poster drawing on this runtime goes
    # through `Previewer.poster`, not the Rails instance `capture` path.
    #
    # Override `preview_timeout` to cap the class-side poster (seconds),
    # or define `TIME_LIMIT` on the subclass — the spinel poster reads
    # either (campfire's TimeLimitedVideoPreviewer + suite stub_const).
    class VideoPreviewer < Previewer
      def self.preview_timeout
        nil
      end
    end
  end

  # Rails' `ActiveStorage::Preview`: a still of a previewable blob (a
  # video here), stored as the blob's OWN `preview_image` attachment —
  # `has_one_attached :preview_image` on the Blob in Rails, the same
  # attachments row shape here (`record_type` "ActiveStorage::Blob",
  # `name` "preview_image") — and served as a VARIANT of that image
  # under the transformations the caller asked for (`preview(format:
  # :webp, resize_to_limit: [w, h])`).
  #
  # `processed` is Rails' find-or-create: the poster is drawn once,
  # `Previewer.poster` → `Blob.create_and_upload!` → the attachment row,
  # and every later `preview` of the blob finds it attached. `url` is
  # the representation route on the ORIGINAL blob with the variation,
  # exactly where `url_for(preview)` points in Rails; serving it draws
  # and transforms on demand, so building the URL does not.
  class Preview
    class UnprocessedError < StandardError
    end

    def initialize(blob, variation)
      @blob = blob
      @variation = variation
    end

    def blob
      @blob
    end

    def variation
      @variation
    end

    # The poster, as the blob's `preview_image` attachment.
    def image
      b = @blob
      Attached.new("ActiveStorage::Blob", b.nil? ? 0 : b.id, "preview_image", [])
    end

    def processed?
      image.attached?
    end

    # Rails: the frame, then the variant of it this preview names
    # (`variant.processed if variant?`) — the poster campfire serves is
    # that variant, and its presentation shows one only once it exists.
    def processed
      process
      variant.processed unless @variation.nil?
      self
    end

    def process
      return nil if processed?
      b = @blob
      return nil if b.nil?
      png = Previewer.poster(Blob.service.path_for(b.key))
      poster = Blob.create_and_upload!(png, ActiveStorage.filename_base(b.filename.to_s) + ".png", "image/png")
      ActiveRecord.adapter.insert("active_storage_attachments", {
        "name" => "preview_image",
        "record_type" => "ActiveStorage::Blob",
        "record_id" => b.id,
        "blob_id" => poster.id,
        "created_at" => ActiveSupport.db_now,
      })
      nil
    end

    # The poster's variant under this preview's transformations — what
    # the representation route serves.
    def variant
      process
      VariantWithRecord.new(image.blob, @variation)
    end

    def key
      variant.key
    end

    # Rails: "<original base>.<format>" — the transformed poster's name.
    def filename
      b = @blob
      return "" if b.nil?
      v = @variation
      ActiveStorage.filename_base(b.filename.to_s) + "." + (v.nil? ? "png" : v.output_format("image/png"))
    end

    def url
      b = @blob
      return "" if b.nil?
      v = @variation
      "/rails/active_storage/representations/redirect/" + b.signed_id +
        "/" + (v.nil? ? "original" : v.encode) + "/" + ActiveStorage.url_filename(filename)
    end
  end

  # One `attachable.variant :name, resize_to_limit: [w, h], format: :f`
  # declaration, as the model's `has_one_attached` block names it —
  # Rails' `ActiveStorage::Variation`, narrowed to the transformations
  # that lower (`resize_to_limit` / `resize_to_fit`, and `format`).
  # `width`/`height` 0 means no resize; `format` "" means keep the
  # original's (a web image stays what it is, anything else becomes
  # PNG — `output_format`).
  #
  # `encode` is one spelling for two jobs: the `variation_digest` column
  # a variant record is found by, and the URL segment Rails fills with
  # a signed transformation key (`/representations/redirect/<blob>/
  # <variation>/<filename>`). Rails digests a Marshal dump the runtime
  # cannot reproduce, so a database shared with a Rails process keeps
  # two records per variation — one per digest scheme — and each side
  # serves its own. `decode` reads the URL segment back, which is how
  # the representation route knows what to process without a record
  # type to look the name up on.
  class Variation
    def initialize(name, width, height, format)
      @name = name
      @width = width
      @height = height
      @format = format
    end

    def name
      @name
    end

    def width
      @width
    end

    def height
      @height
    end

    def format
      @format
    end

    def resize?
      @width > 0 || @height > 0
    end

    def output_format(source_content_type)
      @format == "" ? ActiveStorage.format_for_content_type(source_content_type) : @format
    end

    def output_content_type(source_content_type)
      ActiveStorage.content_type_for_format(output_format(source_content_type))
    end

    def encode
      "limit-" + @width.to_s + "x" + @height.to_s + "-" + (@format == "" ? "keep" : @format)
    end

    def digest
      encode
    end

    # The variation a URL segment names, or nil for anything that is
    # not one — the identity variant, which the route serves as the
    # original.
    def self.decode(key)
      parts = key.split("-")
      return nil if parts.length != 3 || parts[0] != "limit"
      dims = parts[1].to_s.split("x")
      return nil if dims.length != 2
      Variation.new(key, dims[0].to_s.to_i, dims[1].to_s.to_i, parts[2] == "keep" ? "" : parts[2].to_s)
    end
  end

  # The `metadata` column, as the two numbers the corpus reads from it
  # (`attachment.metadata[:width]`). Rails' analyzer fills the column
  # with a JSON object (`{"identified":true,"width":…,"height":…,
  # "analyzed":true}`); a blob nothing identified answers nil for both,
  # which is what an app's `width.nil? || height.nil?` guard expects.
  #
  # A class with a Symbol-keyed `[]` rather than a `Hash[Symbol,
  # Integer?]`, so the read is typed on every target rather than a
  # nullable lookup in a bag.
  class BlobMetadata
    def initialize(width, height)
      @width = width
      @height = height
    end

    def [](key)
      if key == :width
        @width == 0 ? nil : @width
      elsif key == :height
        @height == 0 ? nil : @height
      else
        nil
      end
    end

    def width
      @width
    end

    def height
      @height
    end

    # `Hash#values_at`, the other read the corpus spells
    # (`width, height = attachment.metadata.values_at(:width, :height)`).
    def values_at(*keys)
      out = []
      keys.each { |key| out << self[key] }
      out
    end

    # The JSON Rails writes, so a database this tree and a Rails process
    # share reads the same numbers either way.
    def to_json
      if @width == 0 || @height == 0
        "{\"identified\":true,\"analyzed\":true}"
      else
        "{\"identified\":true,\"width\":" + @width.to_s +
          ",\"height\":" + @height.to_s + ",\"analyzed\":true}"
      end
    end

    # The number after `"<name>":` in the column's JSON, or 0. A
    # hand-rolled scan rather than a JSON parse: the column is written
    # by `to_json` above (or by Rails, in the same shape), the two keys
    # are integers, and the shared runtime has no typed JSON reader
    # to hand a Hash back from.
    def self.int_field(json, name)
      needle = "\"" + name + "\":"
      at = json.index(needle)
      return 0 if at.nil?
      i = at + needle.length
      n = 0
      while i < json.length
        c = json[i].to_s
        break if c < "0" || c > "9"
        n = n * 10 + c.to_i
        i += 1
      end
      n
    end

    def self.parse(json)
      BlobMetadata.new(int_field(json, "width"), int_field(json, "height"))
    end
  end

  # Rails' `Blob#filename` is not a String: it is an
  # `ActiveStorage::Filename` that knows its extension and base, which
  # is what Action Text's copied `_blob` partial reads
  # (`blob.filename.extension`) and why app code that wants the text
  # writes `filename.to_s`. Same shape here, so a call the analyzer
  # accepts on Rails runs on this runtime.
  class Filename
    def initialize(filename)
      @filename = filename
    end

    def to_s
      # Fresh characters: the stored name may still be a handle another
      # name appends to; readers only answer text.
      @filename + ""
    end

    # `.jpg` — the delimiter and the extension, "" when there is none.
    def extension_with_delimiter
      i = @filename.rindex(".")
      i.nil? || i == 0 ? +"" : @filename[i..] + ""
    end

    # `jpg` — the extension without its delimiter, "" when there is none.
    def extension_without_delimiter
      e = extension_with_delimiter
      e.empty? ? +"" : e[1..] + ""
    end

    def extension
      extension_without_delimiter
    end

    # `racecar` for `racecar.jpg`; the whole name when there is no extension.
    def base
      e = extension_with_delimiter
      e.empty? ? @filename + "" : @filename[0, @filename.length - e.length].to_s + ""
    end

    # Rails strips the characters no filesystem or URL wants.
    def sanitized
      @filename.tr("\u{202E}%$|:;/\t\r\n\\", "-")
    end

    def as_json
      @filename + ""
    end
  end

  # One `active_storage_blobs` row: what the file IS, apart from what it
  # is attached to. Constructed from a row (`from_row`), never queried
  # per field.
  class Blob
    def initialize(id, key, filename, content_type, byte_size, metadata)
      @id = id
      @key = key
      @filename = filename
      @content_type = content_type
      @byte_size = byte_size
      @metadata = metadata
    end

    def id
      @id
    end

    def key
      @key
    end

    def filename
      Filename.new(@filename)
    end

    def content_type
      @content_type
    end

    def byte_size
      @byte_size
    end

    def metadata
      @metadata
    end

    # The columns every blob read selects, so the proxy's own join, the
    # batch preloader and `find` cannot disagree about the row shape.
    def self.columns(alias_prefix)
      alias_prefix + ".id AS blob_id, " + alias_prefix + ".key AS blob_key, " +
        alias_prefix + ".filename AS filename, " + alias_prefix +
        ".content_type AS content_type, " + alias_prefix +
        ".byte_size AS byte_size, " + alias_prefix + ".metadata AS metadata"
    end

    def self.from_row(row)
      Blob.new(
        row["blob_id"].to_i,
        row["blob_key"].to_s,
        row["filename"].to_s,
        row["content_type"].to_s,
        row["byte_size"].to_i,
        BlobMetadata.parse(row["metadata"].to_s)
      )
    end

    def self.find(id)
      rows = ActiveRecord.adapter.select_rows(
        "SELECT " + columns("b") + " FROM active_storage_blobs b WHERE b.id = " +
        ActiveRecord.adapter.escape_value(id) + " LIMIT 1"
      )
      rows.length == 0 ? nil : from_row(rows[0])
    end

    def self.find_by_key(key)
      rows = ActiveRecord.adapter.select_rows(
        "SELECT " + columns("b") + " FROM active_storage_blobs b WHERE b.key = " +
        ActiveRecord.adapter.escape_value(key) + " LIMIT 1"
      )
      rows.length == 0 ? nil : from_row(rows[0])
    end

    # Rails' `ActiveStorage.verifier` signs the blob id with purpose
    # `blob_id`, under Active Storage's own salt so a blob token and a
    # record token can never stand in for each other.
    #
    # THE ENVELOPE IS NOT `record.signed_id`'s, though it was here: the
    # app's `message_verifier("ActiveStorage")` signs HMAC-SHA1 over
    # URL-safe, PADDED base64 — `gid_envelope`'s shape — where a signed
    # id is SHA256 and unpadded. Held to Rails' bytes by
    # tests/rails_compat_vectors.rb (`app_verifiers`); before, every blob
    # URL minted here failed on Rails and every one Rails minted (a
    # cached page, an email) failed here.
    def self.find_signed(signed_id)
      json = ActionController::MessageVerifier.verified_data_json(
        Rails.application.secret_key_base, "ActiveStorage", signed_id, "blob_id", true
      )
      return nil if json == ""
      find(json.to_i)
    end

    def signed_id
      ActionController::MessageVerifier.gid_envelope(
        Rails.application.secret_key_base, "ActiveStorage", @id.to_s, "blob_id", ""
      )
    end

    def self.service
      Service.new
    end

    # A value for the `key` column, which is NOT NULL and uniquely
    # indexed, and which names the file on disk.
    #
    # Derived rather than random: randomness is a per-target seam here
    # (the spinel tree reaches /dev/urandom through FFI, the CRuby tree
    # through SecureRandom), and the shared runtime cannot name either.
    # The filename plus the clock plus the byte count is unique in every
    # way that matters, and a collision would need the same name and
    # size in the same millisecond.
    def self.generate_key(filename, byte_size)
      MessageDigest.hmac_sha256_hex(
        "active_storage/blob/" + byte_size.to_s,
        filename + "/" + ActiveSupport.db_now
      )
    end

    # Rails: the blob row AND the bytes. The row goes through the
    # adapter here; the bytes go to the service, which is the one seam
    # a target without storage fails at. `byte_size` is REAL — `data`
    # is the file's contents — so the column means what it says.
    #
    # `data` is bytes, NOT an io: `lower::attached` grounds Rails'
    # `io:` at the call site (`f.read`), because the shared runtime's
    # RBS has no `File` or `IO` type to name.
    #
    # Analyzed on the way in rather than by a later job, so the
    # `metadata` column carries the image's dimensions from the moment
    # the row exists — campfire's `attachment&.analyze` in its create
    # path then has nothing left to do. The analyzer itself is a
    # per-target seam (it reads bytes; see `ImageAnalyzer`).
    def self.create_and_upload!(data, filename, content_type)
      key = generate_key(filename, data.length)
      dims = ImageAnalyzer.dimensions(data, content_type)
      metadata = BlobMetadata.new(dims[0], dims[1])
      service.upload(key, data)
      id = ActiveRecord.adapter.insert("active_storage_blobs", {
        "key" => key,
        "filename" => filename,
        "content_type" => content_type,
        "metadata" => metadata.to_json,
        "service_name" => "local",
        "byte_size" => data.length,
        "checksum" => "",
        "created_at" => ActiveSupport.db_now,
      })
      Blob.new(id, key, filename, content_type, data.length, metadata)
    end

    # Rails' `create_before_direct_upload!`: the ROW ONLY. A direct
    # upload allocates the blob first — key, size, checksum and type
    # as the browser declared them — and the bytes arrive afterwards
    # on the disk service's own PUT, which checks them against the
    # checksum signed into its token. No analysis: there are no bytes
    # yet, so the metadata is empty, as Rails' is until `analyze` runs.
    def self.create_before_direct_upload!(filename, byte_size, checksum, content_type)
      key = generate_key(filename, byte_size)
      metadata = BlobMetadata.new(0, 0)
      id = ActiveRecord.adapter.insert("active_storage_blobs", {
        "key" => key,
        "filename" => filename,
        "content_type" => content_type,
        "metadata" => metadata.to_json,
        "service_name" => "local",
        "byte_size" => byte_size,
        "checksum" => checksum,
        "created_at" => ActiveSupport.db_now,
      })
      Blob.new(id, key, filename, content_type, byte_size, metadata)
    end

    # `ActiveStorage::Blob.count` — a test's `assert_difference`
    # around a direct upload. The blob table is not a model, so the
    # relation's `count` does not reach it; the same SQL, here.
    def self.count
      rows = ActiveRecord.adapter.select_rows("SELECT COUNT(*) AS n FROM active_storage_blobs")
      rows.length == 0 ? 0 : rows[0]["n"].to_i
    end

    # Rails' attachable coercion: what `record.avatar = x` and
    # `create!(avatar: x)` accept — an uploaded file, a blob, a signed
    # blob id. Narrowing an untyped value by class is the ruby family's
    # to do (`runtime/spinel/active_storage_disk.rb` reopens this); the
    # shared runtime declines rather than guessing at a type it cannot
    # test for.
    def self.from_attachable(value)
      raise NotImplementedError,
            "ActiveStorage::Blob.from_attachable: attachable coercion is " \
            "a per-target seam — no multipart body reaches this target"
    end

    def download
      Blob.service.download(@key)
    end

    # The bytes and the row — and the blob's VARIANT RECORDS first, each
    # with its own image blob and attachment row: the variant table has
    # a foreign key onto this one, and a thumbnail whose original is
    # gone is a file nothing can reach.
    def purge
      VariantWithRecord.purge_records_of(@id)
      # The poster goes with its video — Rails' `has_one_attached
      # :preview_image` cascades the same way.
      preview_image.purge
      Blob.service.delete(@key)
      ActiveRecord.adapter.delete("active_storage_blobs", @id)
      nil
    end

    # Rails' `blob.variant(transformations)`: the blob under a
    # Variation (`lower::attached` builds one from an inline hash).
    def variant(variation)
      VariantWithRecord.new(self, variation)
    end

    # Rails' `purge_later`: the purge as an `ActiveStorage::PurgeJob`.
    def purge_later
      PurgeJob.perform_later(self)
    end

    def video?
      @content_type.start_with?("video/")
    end

    # Rails: a previewer accepts this content type. The video previewer
    # is the one modeled (ffmpeg); a PDF has none here.
    def previewable?
      video?
    end

    # Rails' `has_one_attached :preview_image` on the Blob: the poster a
    # `Preview` draws, attached to the video's own blob.
    def preview_image
      Attached.new("ActiveStorage::Blob", @id, "preview_image", [])
    end

    def image?
      @content_type.start_with?("image/")
    end

    def audio?
      @content_type.start_with?("audio/")
    end

    def variable?
      ActiveStorage.variable_content_type?(@content_type)
    end

    # The blob's own route: `rails_blob_path(blob)`. A `disposition` of
    # "attachment" rides as the query Rails puts it in.
    def redirect_url(disposition)
      service_route("redirect", disposition)
    end

    # `rails_storage_proxy_path(blob)`: the engine's other blob route,
    # whose controller answers with the bytes instead of a redirect.
    def proxy_url(disposition)
      service_route("proxy", disposition)
    end

    # Rails' `Blob::Servable`, with activestorage 8.1.4's default
    # lists: an uploaded type a browser would RUN (HTML, SVG, XML, ...)
    # is served as `application/octet-stream`, and any type outside the
    # inline list is an attachment whatever the URL asks. The content
    # type is the uploader's word, so serving it inline as declared lets
    # an upload script the app's origin.
    def content_type_for_serving
      ActiveStorage.content_types_to_serve_as_binary.include?(@content_type) ? "application/octet-stream" : @content_type
    end

    # "attachment" when Rails forces it, "" when the caller's
    # disposition stands.
    def forced_disposition_for_serving
      if ActiveStorage.content_types_to_serve_as_binary.include?(@content_type) || !ActiveStorage.content_types_allowed_inline.include?(@content_type)
        "attachment"
      else
        ""
      end
    end

    def service_route(kind, disposition)
      base = "/rails/active_storage/blobs/" + kind + "/" + signed_id + "/" +
             ActiveStorage.url_filename(@filename)
      disposition == "" ? base : base + "?disposition=" + disposition
    end

    # Rails' `Blob#url`: the SERVICE's url for the bytes — for the disk
    # service, its own signed route, which the redirect route above
    # answers with a 302 to. `rails_blob_path` is the redirect and this
    # is where it lands; an app that reads `blob.url` (or a test that
    # fetches it anonymously) gets the bytes in one hop, as in Rails.
    def url(disposition = "inline")
      DiskKey.disk_url(self, disposition)
    end
  end

  # What Rails' `DiskService#url` signs into the disk route: the key
  # and the disposition to serve it with (Rails also signs the content
  # type and filename; here the blob row answers those, found by key).
  # One envelope under Active Storage's salt, purpose `disk_key`, five
  # minutes to live — Rails' own `urls_expire_in`. The payload is a
  # JSON STRING (`"key|disposition"`) because the envelope's `data`
  # reader stops at the first comma or brace of a bare value.
  #
  # Shared, not a per-target seam: signing is string work the shared
  # verifier already does, and `Blob#url` above needs it on every
  # target. Serving the route it names is the ruby family's
  # (`runtime/spinel/active_storage_disk.rb`).
  module DiskKey
    # The envelope's `exp`: five minutes out, quoted as the JSON string
    # the verifier writes.
    def self.expiry
      "\"" + ActionController::MessageVerifier.iso8601_ms(Time.now + 300) + "\""
    end

    # Only `inline` or `attachment` is ever signed — Rails'
    # `content_disposition_with` (`presence_in(%w[attachment inline]) ||
    # "inline"`). The blob redirect route takes the disposition from a
    # query param, and what is signed here comes back out as the disk
    # route's Content-Disposition header: anything else signed as asked
    # was a header line of the requester's choosing.
    def self.encode(key, disposition)
      disposition = "inline" unless disposition == "attachment"
      ActionController::MessageVerifier.data_envelope(
        Rails.application.secret_key_base, "ActiveStorage",
        ActionController::MessageVerifier.json_string(key + "|" + disposition),
        "disk_key", expiry, false
      )
    end

    # `[key, disposition]`, or an empty key when the token is bad or
    # stale.
    #
    # Built by push onto an empty Array so Spinel keeps `Array[String]`
    # (`sp_StrArray *`). A four- or two-element literal whose slots are
    # `parts[i].to_s` widens to a poly array and fails the C compile
    # against the RBS return type.
    def self.decode(token)
      json = ActionController::MessageVerifier.verified_data_json(
        Rails.application.secret_key_base, "ActiveStorage", token, "disk_key", false
      )
      out = []
      if json != ""
        parts = ActionController::MessageVerifier.json_value(json).split("|")
        if parts.length == 2
          out << parts[0].to_s
          out << parts[1].to_s
          return out
        end
      end
      out << +""
      out << +""
      out
    end

    # Rails' `Blob#url` signs `forced_disposition_for_serving ||
    # disposition`, so a forced attachment holds on the disk route too.
    def self.disk_url(blob, disposition)
      forced = blob.forced_disposition_for_serving
      ActiveStorage::Current.base_url + "/rails/active_storage/disk/" +
        encode(blob.key, forced == "" ? disposition : forced) + "/" + ActiveStorage.url_filename(blob.filename.to_s)
    end

    # The token a direct upload's PUT carries (Rails' `DiskService#
    # url_for_direct_upload`): the key plus what the browser declared —
    # content type, length, MD5 checksum — signed under purpose
    # `blob_token`, so the disk controller can hold the bytes to the
    # blob's own row. Same envelope, five minutes, `|`-joined (a
    # content type has no `|`).
    def self.encode_upload(key, content_type, content_length, checksum)
      ActionController::MessageVerifier.data_envelope(
        Rails.application.secret_key_base, "ActiveStorage",
        ActionController::MessageVerifier.json_string(
          key + "|" + content_type + "|" + content_length.to_s + "|" + checksum
        ),
        "blob_token", expiry, false
      )
    end

    # `[key, content_type, content_length, checksum]`, or an empty key
    # when the token is bad or stale. Same push shape as `decode`.
    def self.decode_upload(token)
      json = ActionController::MessageVerifier.verified_data_json(
        Rails.application.secret_key_base, "ActiveStorage", token, "blob_token", false
      )
      out = []
      if json != ""
        parts = ActionController::MessageVerifier.json_value(json).split("|")
        if parts.length == 4
          out << parts[0].to_s
          out << parts[1].to_s
          out << parts[2].to_s
          out << parts[3].to_s
          return out
        end
      end
      out << +""
      out << +""
      out << +""
      out << +""
      out
    end

    def self.upload_url(blob, checksum)
      ActiveStorage::Current.base_url + "/rails/active_storage/disk/" +
        encode_upload(blob.key, blob.content_type, blob.byte_size, checksum)
    end
  end

  # Rails' `ActiveStorage::Current` — `url_options` is what the disk
  # service's urls are built against: Active Storage's controllers set
  # it from the request (`ActiveStorage::SetCurrent`, here `set_current`
  # in each engine controller), and code outside a request sets it
  # itself (a job; campfire's download test). `protocol:` and `host:`
  # as Rails spells them, and `port:` when there is one.
  #
  # DIVERGENCE, named: Rails RAISES when the disk service is asked for
  # a url with no options set. Here the url is path-only instead —
  # the app's own `_url` helpers are host-less on every target, and a
  # browser resolves a path against the page it is on — so a caller
  # that never set them gets a url that works rather than an
  # exception.
  module Current
    def self.url_options
      @url_options
    end

    def self.url_options=(options)
      @url_options = options
    end

    # `protocol://host[:port]`, or "" with no options set. `protocol`
    # is taken with or without Rails' trailing `://` (`request.protocol`
    # carries it; a hand-written `protocol: "https"` does not).
    def self.base_url
      options = @url_options
      return "" if options.nil?
      host = options.fetch(:host, "")
      return "" if host == ""
      protocol = options.fetch(:protocol, "http").sub("://", "")
      port = options.fetch(:port, "")
      port == "" ? protocol + "://" + host : protocol + "://" + host + ":" + port
    end
  end

  # The filename segment of a blob URL: Rails writes the filename as
  # the last path segment (`*filename`, cosmetic — the key is in the
  # signed id). URI-component encoded so a name with a space or a
  # slash cannot break the path.
  # activestorage 8.1.4's `content_types_to_serve_as_binary` and
  # `content_types_allowed_inline` defaults (engine.rb), read by
  # `Blob#content_type_for_serving` / `#forced_disposition_for_serving`.
  def self.content_types_to_serve_as_binary
    ["text/html", "image/svg+xml", "application/postscript",
     "application/x-shockwave-flash", "text/xml", "application/xml",
     "application/xhtml+xml", "application/mathml+xml", "text/cache-manifest"]
  end

  def self.content_types_allowed_inline
    ["image/webp", "image/avif", "image/png", "image/gif", "image/jpeg",
     "image/tiff", "image/bmp", "image/vnd.adobe.photoshop",
     "image/vnd.microsoft.icon", "application/pdf"]
  end

  def self.url_filename(filename)
    ActionView::ViewHelpers.url_encode_component(filename)
  end

  # The dimensions of an image, or `[0, 0]` when nothing here can
  # read them. A bytes question: the shared runtime's String is code
  # points, so this is a per-target seam (the ruby family reopens it
  # over `getbyte`). `[0, 0]` is Rails' own state for a blob no
  # analyzer identified — `metadata[:width]` is nil and the view's
  # guard takes its no-dimensions branch.
  class ImageAnalyzer
    def self.dimensions(data, content_type)
      [0, 0]
    end
  end

  # Rails' `ActiveStorage::VariantWithRecord`, the value `variant(:x)`
  # and `representation(:x)` answer: a blob and a variation, and —
  # once `processed` — the variant RECORD that pairs them, whose
  # `image` attachment is the transformed blob. `blob` is nil when
  # nothing is attached (Rails' `allow_nil` delegation); `variation`
  # is nil for the identity variant (an inline transformation hash,
  # which nothing lowers), which is served as the original.
  #
  # `processed` is Rails' find-or-create: the record by
  # `(blob_id, variation_digest)`, else download → `Processor
  # .transform` → `Blob.create_and_upload!` → the record and its
  # `image` attachment row, in that order. `key` and `image` process
  # on demand, as a route that never called `processed` would expect;
  # `url` does not — the representation route processes when it is
  # asked, exactly as Rails' does.
  class VariantWithRecord
    def initialize(blob, variation)
      @blob = blob
      @variation = variation
      @record_id = 0
      @image_blob = nil
    end

    def blob
      @blob
    end

    def variation
      @variation
    end

    def processed
      process
      self
    end

    # The columns of a variant record joined to its image blob, so the
    # lookup here and the purge cascade cannot disagree about the shape.
    def self.record_select(where)
      "SELECT vr.id AS variant_record_id, a.id AS attachment_id, " + Blob.columns("b") +
        " FROM active_storage_variant_records vr" +
        " JOIN active_storage_attachments a ON a.record_type = 'ActiveStorage::VariantRecord'" +
        " AND a.name = 'image' AND a.record_id = vr.id" +
        " JOIN active_storage_blobs b ON b.id = a.blob_id WHERE " + where
    end

    # Every variant of a blob, gone with it — see `Blob#purge`.
    def self.purge_records_of(blob_id)
      rows = ActiveRecord.adapter.select_rows(
        record_select("vr.blob_id = " + ActiveRecord.adapter.escape_value(blob_id))
      )
      rows.each do |row|
        ActiveRecord.adapter.delete("active_storage_attachments", row["attachment_id"].to_i)
        ActiveRecord.adapter.delete("active_storage_variant_records", row["variant_record_id"].to_i)
        Blob.from_row(row).purge
      end
      nil
    end

    # Rails: the variant record exists. Looks it up and does not make
    # it — campfire's presentation shows a thumbnail only when posting
    # made one, rather than making it on view.
    def processed?
      return true if @record_id != 0
      b = @blob
      v = @variation
      return false if b.nil? || v.nil?
      rows = ActiveRecord.adapter.select_rows(
        VariantWithRecord.record_select(
          "vr.blob_id = " + ActiveRecord.adapter.escape_value(b.id) +
          " AND vr.variation_digest = " + ActiveRecord.adapter.escape_value(v.digest) + " LIMIT 1"
        )
      )
      return false if rows.length == 0
      @record_id = rows[0]["variant_record_id"].to_i
      @image_blob = Blob.from_row(rows[0])
      true
    end

    def process
      return nil if processed?
      b = @blob
      v = @variation
      return nil if b.nil? || v.nil?
      digest = v.digest
      data = Processor.transform(Blob.service.download(b.key), b.content_type, v)
      image = Blob.create_and_upload!(
        data,
        ActiveStorage.filename_base(b.filename.to_s) + "." + v.output_format(b.content_type),
        v.output_content_type(b.content_type)
      )
      record_id = ActiveRecord.adapter.insert("active_storage_variant_records", {
        "blob_id" => b.id,
        "variation_digest" => digest,
      })
      ActiveRecord.adapter.insert("active_storage_attachments", {
        "name" => "image",
        "record_type" => "ActiveStorage::VariantRecord",
        "record_id" => record_id,
        "blob_id" => image.id,
        "created_at" => ActiveSupport.db_now,
      })
      @record_id = record_id
      @image_blob = image
      nil
    end

    # Rails: the variant record's `image` attachment — an `Attached`
    # proxy over the transformed blob, or nil while there is no record
    # (the identity variant, nothing attached, or not made yet). A
    # lookup, as Rails' `record&.image` is: it makes nothing, so asking
    # it of a file that cannot be decoded answers nil instead of raising
    # the decode error again (campfire keeps such an image unpreviewed).
    def image
      processed? ? Attached.new("ActiveStorage::VariantRecord", @record_id, "image", []) : nil
    end

    # The transformed blob, once processed; the original for the
    # identity variant. What `Blob.service.path_for(variant.key)`
    # serves.
    def image_blob
      process
      ib = @image_blob
      ib.nil? ? @blob : ib
    end

    def key
      ib = image_blob
      ib.nil? ? "" : ib.key
    end

    # Rails: "<original base>.<format>".
    def filename
      b = @blob
      return "" if b.nil?
      v = @variation
      v.nil? ? b.filename.to_s : ActiveStorage.filename_base(b.filename.to_s) + "." + v.output_format(b.content_type)
    end

    # `url_for(variant)` / `polymorphic_url(variant)`: Rails'
    # representation route, with the variation's own encoding where
    # Rails puts its signed transformation key. Serving it processes
    # (`Representations::RedirectController`), so building it does not.
    def url
      b = @blob
      return "" if b.nil?
      v = @variation
      "/rails/active_storage/representations/redirect/" + b.signed_id +
        "/" + (v.nil? ? "original" : v.encode) + "/" + ActiveStorage.url_filename(filename)
    end
  end

  class Attached
    # Constructed with the three columns Rails scopes an attachment on,
    # NOT with a pre-computed boolean: a boolean argument would have
    # meant folding a `where(...).exists?` chain into the reader — which
    # the query specializer inlines into a multi-statement SQL block that
    # cannot sit in an argument position. Raw SQL through the adapter,
    # the way `Relation` itself composes, keeps the reader a plain
    # constructor call.
    #
    # The row is read ONCE and remembered, as Rails' `Attached::One`
    # remembers its attachment until `reload`. An earlier version of
    # this class argued the other way — a record can be attached to
    # between two reads, so ask every time — and that argument was
    # overturned deliberately: it cost two round trips per message on
    # campfire's room page (`content_type` asks `attached?` twice), and
    # it is not what Rails does. `attach` and `purge` forget the row, so
    # a write through this proxy is seen by its next read.
    #
    # `variations` are the `attachable.variant …` declarations of the
    # `has_one_attached` block, lowered into the reader's constructor
    # call (`lower::attached`); a declaration without a block passes
    # none.
    def initialize(record_type, record_id, name, variations)
      @record_type = record_type
      @record_id = record_id
      @name = name
      @variations = variations
      @row_loaded = false
      @attachment_id = 0
      @blob = nil
    end

    def variations
      @variations
    end

    # The id of the record this proxy reads for. The model's reader
    # compares it with the record's id before it reuses the proxy.
    def record_id
      @record_id
    end

    # The attachment row and its blob, in one join. `attachment_id` 0
    # means nothing is attached.
    def load_row
      return nil if @row_loaded
      @row_loaded = true
      sql = "SELECT a.id AS attachment_id, " + Blob.columns("b") +
            " FROM active_storage_attachments a " +
            "JOIN active_storage_blobs b ON b.id = a.blob_id WHERE a.record_type = " +
            ActiveRecord.adapter.escape_value(@record_type) +
            " AND a.record_id = " + ActiveRecord.adapter.escape_value(@record_id) +
            " AND a.name = " + ActiveRecord.adapter.escape_value(@name) + " LIMIT 1"
      rows = ActiveRecord.adapter.select_rows(sql)
      if rows.length > 0
        @attachment_id = rows[0]["attachment_id"].to_i
        @blob = Blob.from_row(rows[0])
      end
      nil
    end

    # The batch loader's entry (`Model._preload_batch_<attr>_attachment`,
    # driven by `with_attached_<attr>`): the row for this record, found
    # in one query for the whole page, or `0` and no blob when the
    # page's query found none for it.
    def _preload_row(attachment_id, blob)
      @row_loaded = true
      @attachment_id = attachment_id
      @blob = blob
      nil
    end

    def attached?
      load_row
      @attachment_id != 0
    end

    # The blob, or nil when nothing is attached — Rails' `Attached::One`
    # delegates to its attachment with `allow_nil: true`.
    def blob
      load_row
      @blob
    end

    def filename
      b = blob
      b.nil? ? nil : b.filename
    end

    def content_type
      b = blob
      b.nil? ? nil : b.content_type
    end

    # The blob's bytes, or nil when nothing is attached — Rails'
    # `Attached::One` delegates to its attachment with `allow_nil: true`.
    def download
      b = blob
      b.nil? ? nil : b.download
    end

    def key
      b = blob
      b.nil? ? "" : b.key
    end

    def signed_id
      b = blob
      b.nil? ? "" : b.signed_id
    end

    def byte_size
      b = blob
      b.nil? ? 0 : b.byte_size
    end

    # `attachment.metadata[:width]` — an unattached proxy answers empty
    # metadata, so the read is nil rather than a NoMethodError.
    def metadata
      b = blob
      b.nil? ? BlobMetadata.new(0, 0) : b.metadata
    end

    # Rails' media predicates, which are content-type questions and so
    # metadata questions. All answer FALSE when nothing is attached,
    # which is what `allow_nil` delegation gives Rails and what lets
    # campfire's `case when attachment.video? … when attachment
    # .representable?` fall through to neither branch.
    def video?
      content_type.to_s.start_with?("video/")
    end

    def image?
      content_type.to_s.start_with?("image/")
    end

    def audio?
      content_type.to_s.start_with?("audio/")
    end

    # Rails: "can a variant be produced from this blob's content type?"
    # Answered from the content type, as Rails does — the processor
    # here is identity, so the answer decides which PATH a view takes
    # (inline image vs. download link), not whether pixels change.
    def variable?
      b = blob
      b.nil? ? false : b.variable?
    end

    # Rails: a previewer (ffmpeg for video, poppler/mutool for PDF)
    # can produce a still — the video one is modeled (`Preview`). The
    # answer decides which PATH a view takes (campfire's `<video
    # poster=…>` against a download link), as `variable?` does.
    def previewable?
      b = blob
      b.nil? ? false : b.previewable?
    end

    # Rails: `variable? || previewable?`.
    def representable?
      variable? || previewable?
    end

    # Rails' `analyze` reads the blob's bytes to fill its metadata.
    # The bytes were analyzed when they were uploaded (`Blob
    # .create_and_upload!`), so there is nothing left to do — nil is
    # the `allow_nil` delegation's own answer for an unattached one.
    def analyze
      nil
    end

    # Rails' `variant(:thumb)`: the declared variation by name, over
    # this attachment's blob — see the class header and
    # `VariantWithRecord`. A name the block never declared is Rails'
    # own ArgumentError. An inline transformation hash is not lowered
    # (nothing in the corpus writes one) and answers the identity
    # variant, the original served under the variant route.
    def variant(transformations)
      VariantWithRecord.new(blob, find_variation(transformations))
    end

    # Rails answers a `Preview` here for a previewable blob and a variant
    # otherwise; this stays the VARIANT so the reader has one type (a
    # union would box every image on the room page). campfire only asks
    # for a representation off the `video?`-guarded branch, and a video
    # reaches `preview` by name.
    def representation(transformations)
      VariantWithRecord.new(blob, find_variation(transformations))
    end

    # An index walk, not `each`: spinel keeps a typed ivar array
    # unboxed only while every use is one the unboxed array supports,
    # and `each` from a block is not on that list.
    def find_variation(transformations)
      return transformations if transformations.is_a?(Variation)
      return nil unless transformations.is_a?(Symbol)
      name = transformations.to_s
      i = 0
      while i < @variations.length
        v = @variations[i]
        return v if v.name == name
        i += 1
      end
      raise ArgumentError, "Cannot find variant :" + name + " for " + @record_type + "#" + @name
    end

    # Rails' `preview(transformations)`: the poster frame of a video,
    # as a `Preview` over this attachment's blob. `transformations` is
    # an `ActiveStorage::Variation` — `lower::attached` builds one from
    # the inline `format: :webp, resize_to_limit: [w, h]` hash at the
    # call site — or nil for the poster as drawn. On a blob that is not
    # previewable the previewer itself refuses (ffmpeg has no poster
    # for an image), which is where Rails' `UnpreviewableError` lands.
    # A declared NAME resolves here, as `variant(:thumb)` does:
    # campfire's `preview(:poster)` names a variant of its
    # `has_one_attached` block, which the poster is then served under.
    def preview(transformations)
      Preview.new(blob, find_variation(transformations))
    end

    # `url_for(attachment)` / `polymorphic_url(attachment)`: the blob's
    # own route, inline.
    def url
      b = blob
      b.nil? ? "" : b.redirect_url("")
    end

    # Rails' `attach`, the row half: point this record at `blob` under
    # `@name`. `has_one_attached` REPLACES, so the prior attachment goes
    # first. Rails detaches the old blob and leaves it for a purge job;
    # there is no job here and an orphaned blob row would make
    # `attached?` answer for a file no longer attached, so the row and
    # its bytes go with it — except when `blob` is ALREADY attached:
    # re-attaching the same Blob must not purge its bytes.
    def attach_blob(blob)
      load_row
      current = @blob
      if !(current.nil?) && current.id == blob.id
        return nil
      end
      purge
      ActiveRecord.adapter.insert("active_storage_attachments", {
        "name" => @name,
        "record_type" => @record_type,
        "record_id" => @record_id,
        "blob_id" => blob.id,
        "created_at" => ActiveSupport.db_now,
      })
      @row_loaded = false
      nil
    end

    # `logo.attach io:, filename:, content_type:` — the blob is created
    # and uploaded, then attached. DATA, NOT AN IO: `lower::attached
    # ::apply_attach_lowering` rewrites Rails' `attach(io: f, …)` to
    # `attach(f.read, …)` at the call site (see `Blob
    # .create_and_upload!` for why).
    def attach(data, filename, content_type)
      attach_blob(Blob.create_and_upload!(data, filename, content_type))
    end

    # Detach and delete: the attachment row, the blob row, and the
    # bytes — see `attach_blob` on why the blob goes too.
    def purge
      detach_each.each { |blob| blob.purge }
      nil
    end

    # Rails' default on the owner's destroy (`dependent: :purge_later`):
    # the join row goes now, the blob in an `ActiveStorage::PurgeJob`.
    def purge_later
      detach_each.each { |blob| blob.purge_later }
      nil
    end

    # Delete the join row(s) and answer the blobs they held.
    def detach_each
      sql = "SELECT a.id AS attachment_id, " + Blob.columns("b") +
            " FROM active_storage_attachments a " +
            "JOIN active_storage_blobs b ON b.id = a.blob_id WHERE a.record_type = " +
            ActiveRecord.adapter.escape_value(@record_type) +
            " AND a.record_id = " + ActiveRecord.adapter.escape_value(@record_id) +
            " AND a.name = " + ActiveRecord.adapter.escape_value(@name)
      blobs = []
      ActiveRecord.adapter.select_rows(sql).each do |row|
        ActiveRecord.adapter.delete("active_storage_attachments", row["attachment_id"].to_i)
        blobs.push(Blob.from_row(row))
      end
      @row_loaded = false
      @attachment_id = 0
      @blob = nil
      blobs
    end

    # `account.logo.destroy` — Rails' `Attached::One` has no `destroy`
    # of its own; the call falls through to the ATTACHMENT record, and
    # destroying that removes the join row while leaving the blob to a
    # `purge_later` job. There is no job here, so this is `purge`
    # under Rails' other name.
    def destroy
      purge
    end
  end

  # One join row behind `AttachedMany#attachments`. The Attachment
  # MODEL lives under `app/models/` (synthesized); the runtime cannot
  # name it without going gradual, so this value mirrors the surface
  # `uploads.attachments.last` needs — `id` / `blob` / `filename` /
  # `url` — via the same raw-SQL join One already uses.
  class ManyAttachment
    def initialize(id, blob)
      @id = id
      @blob = blob
    end

    def id
      @id
    end

    def blob
      @blob
    end

    def filename
      b = @blob
      b.nil? ? nil : b.filename
    end

    def content_type
      b = @blob
      b.nil? ? nil : b.content_type
    end

    def url
      b = @blob
      b.nil? ? "" : b.redirect_url("")
    end
  end

  # What a `has_many_attached :uploads` reader hands back. Always
  # constructed — never nil — so `uploads.attach` / `uploads.attachments`
  # need no nil guard. Unlike `Attached` (One), `attach_blob` APPENDS:
  # prior rows under the same name stay.
  class AttachedMany
    def initialize(record_type, record_id, name)
      @record_type = record_type
      @record_id = record_id
      @name = name
      @rows = []
      @rows_loaded = false
    end

    # The id of the record this proxy reads for — see `Attached#record_id`.
    def record_id
      @record_id
    end

    def attached?
      attachments.length > 0
    end

    # Every join row for this name on this record — Rails'
    # `Attached::Many#attachments`. Raw SQL (not Relation over the
    # synthesized Attachment MODEL) so the body stays fully typed.
    #
    # A preloaded proxy (`with_attached_<attr>`, or the rich-text
    # `_and_embeds` scope) answers the rows its batch installed through
    # `_preload_rows` without a query; any write below drops them.
    def attachments
      return @rows if @rows_loaded
      sql = "SELECT a.id AS attachment_id, " + Blob.columns("b") +
            " FROM active_storage_attachments a " +
            "JOIN active_storage_blobs b ON b.id = a.blob_id WHERE a.record_type = " +
            ActiveRecord.adapter.escape_value(@record_type) +
            " AND a.record_id = " + ActiveRecord.adapter.escape_value(@record_id) +
            " AND a.name = " + ActiveRecord.adapter.escape_value(@name)
      out = []
      ActiveRecord.adapter.select_rows(sql + " ORDER BY a.id").each do |row|
        out.push(ManyAttachment.new(row["attachment_id"].to_i, Blob.from_row(row)))
      end
      out
    end

    # Rails' `Attached::Many` delegates the collection reads to its
    # attachments: `message.body.embeds.first.blob`.
    def first
      attachments.first
    end

    # The batch loader's setter: the rows one `IN` query found for this
    # record, in attachment order.
    def _preload_rows(rows)
      @rows = rows
      @rows_loaded = true
      nil
    end

    # Rails' `Attached::Many` hands every Enumerable call to
    # `attachments` (`delegate_missing_to`); `each` is the one the
    # corpus makes — campfire's `message.body.embeds.each(&:filename)`.
    def each
      rows = attachments
      i = 0
      n = rows.length
      while i < n
        yield rows[i]
        i += 1
      end
      rows
    end

    # More of the same delegation: a jbuilder `json.pictures(record
    # .pictures) do |picture| … end` maps the proxy, and `size` /
    # `empty?` are the reads a view guards it with.
    def map
      out = []
      rows = attachments
      i = 0
      n = rows.length
      while i < n
        out.push(yield rows[i])
        i += 1
      end
      out
    end

    def size
      attachments.length
    end

    def empty?
      attachments.length == 0
    end

    # `self.embeds = blobs` for blob ids, in order: Rails' replace on
    # assign to a `has_many_attached`. A row whose blob is not listed
    # is detached; a listed blob not yet attached is attached once; an
    # id naming no blob (a stale reference in stored markup) is
    # skipped. Detaching leaves the blob, where Rails would
    # `purge_later` it once nothing else references it.
    def _sync_blob_ids(blob_ids)
      @rows_loaded = false
      kept = []
      attachments.each do |att|
        b = att.blob
        bid = b.nil? ? 0 : b.id
        if blob_ids.include?(bid) && !kept.include?(bid)
          kept.push(bid)
        else
          ActiveRecord.adapter.delete("active_storage_attachments", att.id)
        end
      end
      blob_ids.each do |bid|
        next if kept.include?(bid)
        kept.push(bid)
        blob = Blob.find(bid)
        attach_blob(blob) unless blob.nil?
      end
      nil
    end

    # APPEND — prior attachments under `@name` stay. One's `attach_blob`
    # purges first; Many must not.
    def attach_blob(blob)
      @rows_loaded = false
      ActiveRecord.adapter.insert("active_storage_attachments", {
        "name" => @name,
        "record_type" => @record_type,
        "record_id" => @record_id,
        "blob_id" => blob.id,
        "created_at" => ActiveSupport.db_now,
      })
      nil
    end

    # DATA, NOT AN IO: `lower::attached::apply_attach_lowering` grounds
    # `attach(io: …)` / `attach([…])` at the call site.
    def attach(data, filename, content_type)
      attach_blob(Blob.create_and_upload!(data, filename, content_type))
    end

    def purge
      detach_each.each { |blob| blob.purge }
      nil
    end

    def purge_later
      detach_each.each { |blob| blob.purge_later }
      nil
    end

    def detach_each
      blobs = []
      attachments.each do |att|
        blob = att.blob
        ActiveRecord.adapter.delete("active_storage_attachments", att.id)
        blobs.push(blob) unless blob.nil?
      end
      @rows_loaded = false
      blobs
    end

    def destroy
      purge
    end
  end

  # Rails' `ActiveStorage::VariantRecord`, the model behind
  # `active_storage_variant_records`, as far as a test reads it:
  # campfire asserts that serving a poster made when the message was
  # posted makes no further variant (`assert_no_difference ->
  # { ActiveStorage::VariantRecord.count }`).
  class VariantRecord
    def self.count
      rows = ActiveRecord.adapter.select_rows("SELECT count(*) AS n FROM active_storage_variant_records")
      rows.length == 0 ? 0 : rows[0]["n"].to_i
    end
  end

  # Rails' `ActiveStorage::PurgeJob`, in the shape a lowered app job's
  # `perform_later` takes: recorded by name (`assert_enqueued_jobs
  # only: ActiveStorage::PurgeJob`), run inline, queued behind the
  # request, or held for the test adapter. The work is `perform`, as in
  # Rails, so an app that reopens the job to change it is the one that
  # runs (`emit::ruby::reopen`).
  class PurgeJob
    def perform(blob)
      blob.purge
      nil
    end

    def self.perform_later(blob)
      ActiveJob.record_performed("ActiveStorage::PurgeJob")
      if !ActiveJob.enqueue_only
        if ActiveJob.drain_registered
          ActiveJob.enqueue(-> {
            new.perform(blob)
            nil
          })
        else
          new.perform(blob)
        end
      else
        ActiveJob.hold("ActiveStorage::PurgeJob", -> {
          new.perform(blob)
          nil
        })
      end
      nil
    end
  end
end

# Active Storage's ROUTE helpers, reopened onto the app's generated
# `RouteHelpers` module.
#
# They live here rather than in `lower::routes_to_library` because they
# are not the app's routes: Rails mounts them from the Active Storage
# engine, so `config/routes.rb` never names them and the generator that
# reads it cannot know they exist. The routes themselves are served by
# the ruby family's `ActiveStorage::Routes` (the engine's three
# controllers), which is why the URL shapes here are Rails' own:
#
#   /rails/active_storage/blobs/redirect/:signed_id/*filename
#   /rails/active_storage/blobs/proxy/:signed_id/*filename
#   /rails/active_storage/representations/redirect/:signed_blob_id/:variation_key/*filename
#   /rails/active_storage/disk/:encoded_key/*filename
#   /rails/active_storage/direct_uploads              (POST)
#   /rails/active_storage/disk/:encoded_token         (PUT)
#
# `disposition` and `only_path` are spelled out because those are the
# two options an ingested app has written. `_url` is the same string as
# `_path`: the app's own `_url` helpers are lowered host-less too.
module RouteHelpers
  # Rails' `rails_blob_path` takes a Blob, an Attachment or an Attached
  # (`resolve("ActiveStorage::Blob")` and `resolve("ActiveStorage::Attachment")`
  # route each to the blob's redirect route), as `rails_storage_redirect_path`
  # below does.
  def self.rails_blob_path(model, disposition: nil, only_path: nil)
    b = storage_blob(model)
    b.nil? ? "" : b.redirect_url(disposition.to_s)
  end

  # The direct-upload endpoint (`POST`), which Rails mounts on every
  # app; campfire's suite asserts its guard.
  def self.rails_direct_uploads_path
    "/rails/active_storage/direct_uploads"
  end

  def self.rails_direct_uploads_url
    rails_direct_uploads_path
  end

  def self.rails_blob_url(model, disposition: nil, only_path: nil)
    rails_blob_path(model, disposition: disposition, only_path: only_path)
  end

  # The engine's two `direct` routes over a blob. `rails_storage_redirect`
  # is the route `rails_blob` resolves to under Rails' default
  # `resolve_model_to_route`; `rails_storage_proxy` names the proxy
  # route, which serves the bytes through the app. Rails' blocks take
  # whatever answers `signed_id`: the Blob itself or its attachment.
  def self.rails_storage_proxy_path(model, disposition: nil, only_path: nil)
    b = storage_blob(model)
    b.nil? ? "" : b.proxy_url(disposition.to_s)
  end

  def self.rails_storage_proxy_url(model, disposition: nil, only_path: nil)
    rails_storage_proxy_path(model, disposition: disposition, only_path: only_path)
  end

  def self.rails_storage_redirect_path(model, disposition: nil, only_path: nil)
    b = storage_blob(model)
    b.nil? ? "" : b.redirect_url(disposition.to_s)
  end

  def self.rails_storage_redirect_url(model, disposition: nil, only_path: nil)
    rails_storage_redirect_path(model, disposition: disposition, only_path: only_path)
  end

  # nil when there is none: a link to a missing file (`record.file.blob`
  # when nothing is attached) gets an empty href rather than raising.
  def self.storage_blob(model)
    return nil if model.nil?
    model.is_a?(ActiveStorage::Blob) ? model : model.blob
  end

  def self.rails_representation_path(variant, only_path: nil)
    variant.url
  end

  def self.rails_representation_url(variant, only_path: nil)
    variant.url
  end
end
