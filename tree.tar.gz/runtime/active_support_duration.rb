# frozen_string_literal: true
# ActiveSupport::Duration for the spinel (AOT) tree.
#
# The value class HALF of the CRuby overlay's
# `ruby_overlay/runtime/active_support_duration.rb` — same constants,
# same builders, same seconds-based arithmetic. What it deliberately
# omits is that file's `class Time` reopen (Duration-aware `<=>`/`-`/`+`
# via `alias_method` and Rational math): reopening a built-in's
# operators is CRuby-only forever, and spinel's subset rejects the
# Rational literals it leans on. Sites that need Time±Duration under
# AOT get grounded at emit instead (`.ago`/`.from_now` live here and
# cover the corpus's dominant shape).
#
# On the CRuby/JRuby trees the overlay file replaces this one wholesale
# (same emitted path, dedupe-last-wins), so the two never coexist.
#
# Seconds-based. days/hours/minutes/weeks are exact; months/years use
# Rails' average-length constants (a month is 1/12 of a 365.2425-day
# year) — close enough for the comparisons the corpus makes, not a
# calendar engine.
module ActiveSupport
  class Duration
    SECONDS_PER_MINUTE = 60
    SECONDS_PER_HOUR = 3600
    SECONDS_PER_DAY = 86400
    SECONDS_PER_WEEK = 604800
    SECONDS_PER_MONTH = 2629746
    SECONDS_PER_YEAR = 31556952

    def initialize(seconds)
      @seconds = seconds
    end

    def self.time_operand(value)
      value.is_a?(Duration) ? value.seconds : value
    end

    def self.seconds(n)
      new(n)
    end

    def self.second(n)
      new(n)
    end

    def self.minutes(n)
      new(n * SECONDS_PER_MINUTE)
    end

    def self.minute(n)
      new(n * SECONDS_PER_MINUTE)
    end

    def self.hours(n)
      new(n * SECONDS_PER_HOUR)
    end

    def self.hour(n)
      new(n * SECONDS_PER_HOUR)
    end

    def self.days(n)
      new(n * SECONDS_PER_DAY)
    end

    def self.day(n)
      new(n * SECONDS_PER_DAY)
    end

    def self.weeks(n)
      new(n * SECONDS_PER_WEEK)
    end

    def self.week(n)
      new(n * SECONDS_PER_WEEK)
    end

    def self.fortnights(n)
      new(n * SECONDS_PER_WEEK * 2)
    end

    def self.fortnight(n)
      new(n * SECONDS_PER_WEEK * 2)
    end

    def self.months(n)
      new(n * SECONDS_PER_MONTH)
    end

    def self.month(n)
      new(n * SECONDS_PER_MONTH)
    end

    def self.years(n)
      new(n * SECONDS_PER_YEAR)
    end

    def self.year(n)
      new(n * SECONDS_PER_YEAR)
    end

    # A Time minus seconds is a Time, so `ago`/`from_now` (and the
    # Rails aliases `until`/`since`) stay Time-typed for callers like
    # `created_at > 70.days.ago`.
    # `ActiveSupport.now`, not `Time.now` — the runtime's one clock, so
    # `travel_to` in a test moves what `70.days.ago` means. See the
    # TEST CLOCK block in active_support_time_parsing.rb.
    def ago
      ActiveSupport.now.utc - @seconds
    end

    def until
      ActiveSupport.now.utc - @seconds
    end

    def from_now
      ActiveSupport.now.utc + @seconds
    end

    def since
      ActiveSupport.now.utc + @seconds
    end

    def to_i
      @seconds.to_i
    end

    def to_f
      @seconds.to_f
    end

    # Numeric predicates Rails' Duration answers by delegating to its
    # value — net/http asks `zero?` of a timeout, and campfire passes
    # `7.seconds` as one (Opengraph::Fetch).
    def zero?
      @seconds == 0
    end

    def positive?
      @seconds > 0
    end

    def negative?
      @seconds < 0
    end

    # Rails parity: Duration#to_s is the seconds VALUE's to_s
    # (`30.minutes.to_s == "1800"`). Also what string interpolation
    # calls — lobsters' cache keys embed durations
    # (`"aggregates_#{interval}_#{cache_time}"`), and matching Rails
    # here keeps those keys byte-identical.
    def to_s
      @seconds.to_s
    end

    def seconds
      @seconds
    end

    def value
      @seconds
    end

    # Rails parity, the overlay's rule: a Duration IS its seconds count
    # for equality, so `assert_equal 1.year, response.cache_control
    # [:max_age].to_i` (campfire's QR code test) holds against an
    # Integer. Ruby's `!=` is the negation of this.
    def ==(other)
      other.is_a?(Duration) ? @seconds == other.seconds : @seconds == other
    end

    # Ordering, the same rule: Rails' Duration compares as its seconds
    # against a Numeric or another Duration. spinel's net/http reads a
    # campfire webhook's `open_timeout = 7.seconds` as `limit <= 0`
    # before it connects, which raised "comparison of Duration with 0
    # failed" the moment #4492 let that path be reached. Spelled out
    # rather than through `Comparable` so every operator is a plain
    # method on this lane.
    def <=>(other)
      @seconds <=> (other.is_a?(Duration) ? other.seconds : other)
    end

    def coerce(other)
      [other, @seconds]
    end

    def <(other)
      (self <=> other) < 0
    end

    def <=(other)
      (self <=> other) <= 0
    end

    def >(other)
      (self <=> other) > 0
    end

    def >=(other)
      (self <=> other) >= 0
    end
  end
end
