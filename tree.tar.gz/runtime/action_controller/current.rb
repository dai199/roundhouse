# frozen_string_literal: true
# Per-request context reachable from module-function helpers. Rails
# helpers run in the view context, which delegates `request` to the
# controller; the emitted helpers are module functions with no such
# context, so the dispatcher parks the request/controller here (the
# ActiveSupport::CurrentAttributes pattern) and the Ruby emit path
# rewrites bare `request` reads in helper/view module bodies to
# `ActionController::Current.request`. Single-threaded dispatch —
# plain module state, reset by assignment each request.
#
# Module-ivar statics rather than `class << self` (the overlay's
# shape): explicit `def self.` accessors are the statically-resolvable
# form every ingest/AOT path handles. The controller is parked (not
# its session) because the controller's @session can be swapped
# (a test's `session=`) — a parked session reference would go stale.
module ActionController
  class Base
    def request
      @_request
    end

    def request=(value)
      @_request = value
    end

    def request_host_for_redirect
      r = @_request
      return "" if r.nil?
      # Same authority as `request.host` / `request.url`
      # (`Request#raw_host_with_port`): last `X-Forwarded-Host` from a
      # loopback or private peer, otherwise the Host header.
      r.raw_host_with_port.to_s
    end

    def request_protocol_for_url
      r = @_request
      return "http://" if r.nil?
      r.protocol
    end

    def request_for_csrf
      @_request
    end

    def csrf_header_token
      req = @_request
      return "" if req.nil?
      req.env.fetch("HTTP_X_CSRF_TOKEN", "").to_s
    end
  end

  module Current
    def self.request
      @_request
    end

    def self.request=(value)
      @_request = value
    end

    def self.controller
      @controller
    end

    def self.controller=(value)
      @controller = value
    end

    # The current request's session, or nil outside a dispatch (unit
    # tests construct view helpers without a controller; they get the
    # shared runtime's empty-token behavior).
    def self.session
      c = @controller
      return nil if c.nil?
      c.session
    end
  end
end
