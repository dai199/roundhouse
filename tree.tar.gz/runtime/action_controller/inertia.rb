# frozen_string_literal: true
# Props are held as JSON text, not as a Hash of values, and a lazy prop
# is a condition around its expression, not a Proc: a strict target can
# compile neither a mixed-value Hash nor a Proc.
module ActionController
  class InertiaPage
    attr_reader :version

    def initialize
      @component = +""
      @version = +""
      @encrypt_history = false
      @partial = false
      @only = []
      @except = []
      @keys = []
      @values = []
      @shared_keys = []
      @deferred_groups = []
      @deferred_keys = []
      @clear_history = false
      @preserve_fragment = false
    end

    def requested?(key)
      (@only.empty? || @only.include?(key)) && !@except.include?(key)
    end

    def eager?(key)
      !@partial || requested?(key)
    end

    def optional?(key)
      @partial && requested?(key)
    end

    def deferred?(key, group)
      unless @partial
        @deferred_groups << group
        @deferred_keys << key
        return false
      end
      requested?(key)
    end

    def prop_json(key, json)
      i = @keys.index(key)
      if i.nil?
        @keys << key
        @values << json
      else
        @values[i] = json
      end
      nil
    end

  end

  class Base
    def inertia_page
      page = @inertia_page_object
      return page unless page.nil?
      fresh = ActionController::InertiaPage.new
      @inertia_page_object = fresh
      fresh
    end

    # A false or nil option stores nothing, so it does not delete a flag
    # an earlier redirect already stored.
    def inertia_clear_history(flag)
      session["inertia_clear_history"] = "true" if flag
      nil
    end

    def inertia_preserve_fragment(flag)
      session["inertia_preserve_fragment"] = "true" if flag
      nil
    end

    def merge_inertia_props(hash)
      raise TypeError, "inertia props must be a Hash" unless hash.is_a?(Hash)
      page = inertia_page
      hash.keys.each do |key|
        apply_inertia_prop(page, key.to_s, hash[key])
      end
      nil
    end

    def apply_inertia_prop(page, name, raw)
      if raw.is_a?(InertiaRails::Prop)
        kind = raw.kind
        if kind == "defer"
          if page.deferred?(name, raw.group)
            page.prop_json(name, raw.call(self))
          end
        elsif kind == "optional"
          if page.optional?(name)
            page.prop_json(name, raw.call(self))
          end
        elsif kind == "always"
          page.prop_json(name, raw.call(self))
        end
      elsif raw.is_a?(Proc)
        if page.eager?(name)
          page.prop_json(name, inertia_exec(raw))
        end
      elsif page.eager?(name)
        # Same encoder a literal prop is lowered to. It walks a Hash or
        # Array and calls `as_json` on a record. The method lives in the
        # JSON runtime, so this file does not define it.
        page.prop_json(name, ActionController::JsonRender.encode_escaped(raw))
      end
      nil
    end

    # A computed prop proc is built in a controller method, so its
    # `self` is already that controller (`-> { @stamp }`). `call` runs
    # it and encodes the value. `instance_exec` would rebind a proc
    # that was built on some other object; Spinel has no compile path
    # for `instance_exec` of a proc that is not a literal at the call,
    # and this method is the one body every target runs.
    def inertia_exec(work)
      ActionController::JsonRender.encode_escaped(work.call)
    end

  end
end

# The objects a computed props hash can hold. A literal hash never
# builds these: the lowerer sees `-> { }`, `InertiaRails.optional`,
# `.defer`, and `.always` and emits the gate itself. A helper that
# returns the same wrappers builds them here, and `merge_inertia_props`
# reads `kind`.
module InertiaRails
  class Prop
    def initialize(kind, group)
      @kind = kind
      @group = group
      @block = nil
    end

    def kind
      @kind
    end

    def group
      @group
    end

    def store(work)
      @block = work
      nil
    end

    def call(controller)
      controller.inertia_exec(@block)
    end
  end

  def self.optional(&block)
    prop = Prop.new("optional", "")
    prop.store(block)
    prop
  end

  def self.defer(group: "default", &block)
    prop = Prop.new("defer", group)
    prop.store(block)
    prop
  end

  def self.always(&block)
    prop = Prop.new("always", "")
    prop.store(block)
    prop
  end
end
