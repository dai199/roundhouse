# frozen_string_literal: true
# The app's own statements from config/initializers/ (generated — see
# ingest::boot_program), in Rails' load order.
ViewComponent::Compiler.development_mode = Rails.env.development? || Rails.env.test?
ViewComponent::Base.descendants.each { |x| x.compile } if Rails.application.eager_load
