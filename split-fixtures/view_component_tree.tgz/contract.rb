require_relative "boot"
puts "booted"
begin
ComponentReport.lines.each { |line| puts line }
UiReport.lines.each { |line| puts line }
rescue => e
  puts e.class.name
  puts e.message
  puts e.backtrace.to_a.first(15)
  raise
end

puts "\nroundhouse emit-and-run: script completed"
