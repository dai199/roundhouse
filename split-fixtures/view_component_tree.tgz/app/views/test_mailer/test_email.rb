module Views
  module TestMailer
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/test_mailer/test_email.html.erb:1
    def self.test_email_into(io, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << ActionView::ViewHelpers.html_escape((render MailerComponent.new).to_s)
      io << "\n"
      ActiveSupport::Notifications.render_finish("render_template.action_view", "app/views/test_mailer/test_email.html.erb", __render_started)
      nil
    end

    def self.test_email(notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_TestMailer_test_email)
      Views::TestMailer.test_email_into(io, notice, alert)
      ViewBufferCap.store(:cap_Views_TestMailer_test_email, io.bytesize)
      io
    end
  end
end
