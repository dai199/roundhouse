module Views
  module ViewComponents
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:1
    def self.preview_source_into(io, view_component, example_name, preview, render_args, view_renderer, notice, alert)
      __render_started = ActiveSupport::Notifications.render_start
      io << "<link href=\""
      io << PreviewHelper.prism_css_source_url.to_s
      io << "\" media=\"screen\" rel=\"stylesheet\" type=\"text/css\">\n<div class=\"view-component-source-example\">\n  <h2>Source:</h2>\n  <pre class=\"source\">\n"
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:5
      if render_args[:component]
        io << "      <code class=\"language-ruby\">\n        "
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:7
        io << ActionView::ViewHelpers.html_escape(preview.preview_source(example_name).to_s)
        io << "\n      </code>\n"
      else
        template_data = PreviewHelper.find_template_data_for_preview_source(lookup_context: view_renderer.lookup_context, template_identifier: render_args[:template])
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:11
        io << "      <code class=\"language-"
        io << ActionView::ViewHelpers.html_escape(template_data[:prism_language_name].to_s)
        io << "\">\n        "
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:12
        io << ActionView::ViewHelpers.html_escape(template_data[:source].to_s)
        io << "\n      </code>\n"
      end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:15
      io << "  </pre>\n</div>\n<script type=\"text/javascript\" src=\""
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:17
      io << PreviewHelper.prism_js_source_url.to_s
      io << "\"></script>\n"
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/app/views/view_components/_preview_source.html.erb:1
      ActiveSupport::Notifications.render_finish("render_partial.action_view", "app/views/view_components/_preview_source.html.erb", __render_started)
      nil
    end

    def self.preview_source(view_component, example_name, preview, render_args, view_renderer, notice = nil, alert = nil)
      io = ViewBufferCap.alloc(:cap_Views_ViewComponents_preview_source)
      Views::ViewComponents.preview_source_into(io, view_component, example_name, preview, render_args, view_renderer, notice, alert)
      ViewBufferCap.store(:cap_Views_ViewComponents_preview_source, io.bytesize)
      io
    end
  end
end
