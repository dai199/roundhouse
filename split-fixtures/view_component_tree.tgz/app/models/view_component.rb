module ViewComponent
  DEPRECATION_HORIZON = "4.0.0"
  Deprecation = ActiveSupport::Deprecation.new(ViewComponent::DEPRECATION_HORIZON, "ViewComponent")
end

module ViewComponent
end
