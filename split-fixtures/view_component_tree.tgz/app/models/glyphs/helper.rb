module Glyphs
  module Helper
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/helper.rb:3
    def glyph_tag(named, **options)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/helper.rb:4
      ActionView::ViewHelpers.content_tag(:svg, Glyphs::Store.glyph(named).html_safe, Glyphs.default_options.merge(**options))
    end
  end
end
