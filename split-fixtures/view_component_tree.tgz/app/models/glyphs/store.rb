module Glyphs
  module Store
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:5
    def self.glyph(named)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:6
      __rh_named = named.to_s
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:7
      if all.key?(__rh_named)
        nil
      else
        raise ArgumentError, "Unknown glyph #{__rh_named}"
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:9
      all[__rh_named]
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:12
    def self.all
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:13
      return @all if @all

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:15
      data = ActiveSupport::Gzip.decompress(File.read(Glyphs::ROOT.join("data/glyphs.bin.gz")))
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:16
      @all = data.split("\0").to_h { |x| x.split(",", 2) }
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:5
    def glyph(named)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:6
      __rh_named = named.to_s
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:7
      if all.key?(__rh_named)
        nil
      else
        raise ArgumentError, "Unknown glyph #{__rh_named}"
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:9
      all[__rh_named]
    end
    private :glyph

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:12
    def all
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:13
      return @all if @all

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:15
      data = ActiveSupport::Gzip.decompress(File.read(Glyphs::ROOT.join("data/glyphs.bin.gz")))
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs/store.rb:16
      @all = data.split("\0").to_h { |x| x.split(",", 2) }
    end
    private :all
  end
end
