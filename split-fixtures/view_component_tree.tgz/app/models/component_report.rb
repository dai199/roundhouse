class ComponentReport
#<SPINEL_SOURCE>app/app/lib/component_report.rb:2
  def self.lines
#<SPINEL_SOURCE>app/app/lib/component_report.rb:3
    view = ActionView::Base.new
#<SPINEL_SOURCE>app/app/lib/component_report.rb:4
    greeting = GreetingComponent.new(name: "blog", count: 0).render_in(view)
#<SPINEL_SOURCE>app/app/lib/component_report.rb:5
    card = CardComponent.new(tone: "warm").render_in(view) do |c|
      c.with_header { "Title <b>" }
#<SPINEL_SOURCE>app/app/lib/component_report.rb:7
      c.with_item { "one" }
#<SPINEL_SOURCE>app/app/lib/component_report.rb:8
      c.with_item { "two" }
#<SPINEL_SOURCE>app/app/lib/component_report.rb:9
      c.with_footer(note: "fine <print>")
#<SPINEL_SOURCE>app/app/lib/component_report.rb:10
      "\n  Body text\n"
    end
#<SPINEL_SOURCE>app/app/lib/component_report.rb:12
    [greeting.to_s, card.to_s]
  end
end
