require_relative "base_button"

module Ui
  class Link < Ui::BaseButton
#<SPINEL_SOURCE>app/app/components/ui/link.html.erb:1
    def call
      _buf = +""
      _buf = _buf + ActionView::ViewHelpers.html_escape("<a#{ActionView::ViewHelpers.render_attrs(**{ class: classes }.merge(opts))} href=\"#{ActionView::ViewHelpers.html_escape(href)}\">#{_vc_cap1 = ""
      _vc_cap1 = _vc_cap1 + "\n  "
#<SPINEL_SOURCE>app/app/components/ui/link.html.erb:2
      _vc_cap1 = _vc_cap1 + ApplicationHelper.icon(icon).to_s if icon
      _vc_cap1 = _vc_cap1 + "\n  "
#<SPINEL_SOURCE>app/app/components/ui/link.html.erb:3
      _vc_cap1 = _vc_cap1 + ActionView::ViewHelpers.html_escape(text.to_s)
      _vc_cap1 = _vc_cap1 + "\n"
#<SPINEL_SOURCE>app/app/components/ui/link.html.erb:1
      _cap = ActionView::ViewHelpers.raw(_vc_cap1).to_s
      _cap}</a>".html_safe.to_s)
#<SPINEL_SOURCE>app/app/components/ui/link.html.erb:4
      ActionView::ViewHelpers.raw(_buf)
    end
  end
end
