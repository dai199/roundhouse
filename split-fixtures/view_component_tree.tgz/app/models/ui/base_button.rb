require_relative "../view_component/base"
require_relative "../../route_helpers"

module Ui
  class BaseButton < ViewComponent::Base
    include RouteHelpers

    TONES = { solid: "bg-ink text-paper", quiet: "text-ink" }.freeze

#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:4
    def tone
      @tone
    end

    def href
      @href
    end

    def icon
      @icon
    end

    def text
      @text
    end

    def extra_classes
      @extra_classes
    end

    def opts
      @opts
    end

#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:6
    def initialize(tone: :solid, href: nil, text: nil, icon: nil, **opts)
#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:7
      @tone = tone.to_sym
#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:8
      @href = href
#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:9
      @text = text
#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:10
      @icon = icon
#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:11
      @extra_classes = opts.delete(:class)
#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:12
      @opts = opts
    end
    private :initialize

#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:15
    def classes
#<SPINEL_SOURCE>app/app/components/ui/base_button.rb:16
      ActionView::ViewHelpers.class_names("btn", Ui::BaseButton::TONES[tone], extra_classes, ("btn-icon" if icon))
    end
  end
end
