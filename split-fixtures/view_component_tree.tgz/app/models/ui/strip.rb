require_relative "../view_component/base"
require_relative "../../route_helpers"
require_relative "link"

module Ui
  class Strip < ViewComponent::Base
    include RouteHelpers

    def call
      _buf = +""
      _buf = _buf + ActionView::ViewHelpers.html_escape("<nav class=\"#{"strip"}\">#{_vc_cap1 = ""
      _vc_cap1 = _vc_cap1 + "\n"
      tabs.each do |tab|
        _vc_cap1 = _vc_cap1 + "    "
        _vc_cap1 = _vc_cap1 + ActionView::ViewHelpers.html_escape(tab.to_s)
        _vc_cap1 = _vc_cap1 + "\n"
      end
      links.each do |link|
        _vc_cap1 = _vc_cap1 + "    "
        _vc_cap1 = _vc_cap1 + ActionView::ViewHelpers.html_escape(link.to_s)
        _vc_cap1 = _vc_cap1 + "\n"
      end
      _cap = ActionView::ViewHelpers.raw(_vc_cap1).to_s
      _cap}</nav>".html_safe.to_s)
      ActionView::ViewHelpers.raw(_buf)
    end


#<SPINEL_SOURCE>app/app/components/ui/strip.rb:13
    def _call_tabs(id:, label:, &block)
      "<button#{ActionView::ViewHelpers.tag_attr("id", id)} type=\"#{"button"}\"#{ActionView::ViewHelpers.tag_attr("class", if id == active
        "on"
      else
        "off"
      end)}>#{if block.nil?
        ActionView::ViewHelpers.html_escape(label.to_s)
      else
        ActionView::ViewHelpers.capture(&block)
      end}</button>".html_safe
    end


    def with_tab(*args, **kwargs, &block)
      set_slot(:tabs, nil, *args, **kwargs, &block)
    end


    def with_tab_content(content)
      with_tab { content.to_s }
      self
    end


    def with_tabs(collection_args = nil, &block)
      collection_args.map do |args|
        if args.respond_to?(:to_hash)
          set_slot(:tabs, nil, **args, &block)
        else
          set_slot(:tabs, nil, *args, &block)
        end
      end
    end


    def tabs
      get_slot(:tabs)
    end


    def tabs?
      ActiveSupport.present?(get_slot(:tabs))
    end


    def with_link(*args, **kwargs, &block)
      set_slot(:links, nil, *args, **kwargs, &block)
    end


    def with_link_content(content)
      with_link { content.to_s }
      self
    end


    def with_links(collection_args = nil, &block)
      collection_args.map do |args|
        if args.respond_to?(:to_hash)
          set_slot(:links, nil, **args, &block)
        else
          set_slot(:links, nil, *args, &block)
        end
      end
    end


    def links
      get_slot(:links)
    end


    def links?
      ActiveSupport.present?(get_slot(:links))
    end


    def __vc_call_slot_function(slot_name, *args, **kwargs, &block)
      case slot_name
      when :tabs
        _call_tabs(*args, **kwargs, &block)
      else
        super
      end
    end

    renders_many :tabs, -> {  }
    renders_many :links, Ui::Link

#<SPINEL_SOURCE>app/app/components/ui/strip.rb:19
    def active
      @active
    end


#<SPINEL_SOURCE>app/app/components/ui/strip.rb:21
    def initialize(active:)
#<SPINEL_SOURCE>app/app/components/ui/strip.rb:22
      @active = active
    end
    private :initialize

  end
end
