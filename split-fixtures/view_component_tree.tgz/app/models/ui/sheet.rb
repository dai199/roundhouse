require_relative "../view_component/base"
require_relative "../../route_helpers"

module Ui
  class Sheet < ViewComponent::Base
    include RouteHelpers

    def call
      _buf = +""
      _buf = _buf + ActionView::ViewHelpers.html_escape(ActionView::ViewHelpers.content_tag(:section, (_vc_cap1 = ""
      _vc_cap1 = _vc_cap1 + "\n  "
      _vc_cap1 = _vc_cap1 + ActionView::ViewHelpers.html_escape(header.to_s)
      _vc_cap1 = _vc_cap1 + "\n  "
      tabs.each do |tab| _vc_cap1 = _vc_cap1 + ActionView::ViewHelpers.html_escape(tab.to_s) end
      _vc_cap1 = _vc_cap1 + "\n"
      _cap = ActionView::ViewHelpers.raw(_vc_cap1).to_s
      _cap), **{ class: "sheet" }.merge(wrapper_opts)).html_safe.to_s)
      ActionView::ViewHelpers.raw(_buf)
    end


#<SPINEL_SOURCE>app/app/components/ui/sheet.rb:9
    def _call_header(title:, note: nil)
      "<header class=\"#{"panel-head"}\">#{close = render Ui::Button.new(text: "x", tone: :quiet)
      _cap = ActionView::ViewHelpers.safe_join(["<h2>#{ActionView::ViewHelpers.html_escape(title.to_s)}</h2>".html_safe, note, close].compact, " ").to_s
      _cap}</header>".html_safe
    end


    def with_header(*args, **kwargs, &block)
      set_slot(:header, nil, *args, **kwargs, &block)
    end


    def with_header_content(content)
      with_header { content.to_s }
      self
    end


    def header
      get_slot(:header)
    end


    def header?
      ActiveSupport.present?(get_slot(:header))
    end


    def _call_tabs(label:)
      "<span class=\"#{"tab"}\">#{ActionView::ViewHelpers.html_escape(label.to_s)}</span>".html_safe
    end


    def with_tab(*args, **kwargs, &block)
      set_slot(:tabs, nil, *args, **kwargs, &block)
    end


    def with_tab_content(content)
      with_tab { content.to_s }
      self
    end


    def with_tabs(collection_args = nil, &block)
      collection_args.map do |args|
        if args.respond_to?(:to_hash)
          set_slot(:tabs, nil, **args, &block)
        else
          set_slot(:tabs, nil, *args, &block)
        end
      end
    end


    def tabs
      get_slot(:tabs)
    end


    def tabs?
      ActiveSupport.present?(get_slot(:tabs))
    end


    def __vc_call_slot_function(slot_name, *args, **kwargs, &block)
      case slot_name
      when :header
        _call_header(*args, **kwargs, &block)
      when :tabs
        _call_tabs(*args, **kwargs, &block)
      else
        super
      end
    end

    renders_one :header, -> {  }
    renders_many :tabs, -> {  }

#<SPINEL_SOURCE>app/app/components/ui/sheet.rb:20
    def wrapper_opts
#<SPINEL_SOURCE>app/app/components/ui/sheet.rb:21
      { data: { controller: "sheet" }, id: "p1" }
    end

  end
end
