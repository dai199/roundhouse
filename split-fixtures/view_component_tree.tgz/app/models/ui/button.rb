require_relative "base_button"

module Ui
  class Button < Ui::BaseButton
#<SPINEL_SOURCE>app/app/components/ui/button.rb:2
    def confirm
      @confirm
    end

#<SPINEL_SOURCE>app/app/components/ui/button.rb:4
    def initialize(confirm: nil, **opts)
#<SPINEL_SOURCE>app/app/components/ui/button.rb:5
      super(**opts)
#<SPINEL_SOURCE>app/app/components/ui/button.rb:6
      @confirm = confirm
    end
    private :initialize

#<SPINEL_SOURCE>app/app/components/ui/button.rb:9
    def container(&block)
#<SPINEL_SOURCE>app/app/components/ui/button.rb:10
      data = if confirm
        { turbo_confirm: confirm }
      else
        {}
      end
#<SPINEL_SOURCE>app/app/components/ui/button.rb:11
      if href
        ActionView::ViewHelpers.button_to_html(href, if block.nil?
          ""
        else
          ActionView::ViewHelpers.capture(&block)
        end, **opts.merge(class: classes, data: data)).html_safe
      else
        ActionView::ViewHelpers.content_tag(:button, if block.nil?
          ""
        else
          ActionView::ViewHelpers.capture(&block)
        end, **opts.merge(class: classes, data: data)).html_safe
      end
    end

#<SPINEL_SOURCE>app/app/components/ui/button.html.erb:1
    def call
      _buf = +""
      _buf = _buf + ActionView::ViewHelpers.html_escape(container do
        _vc_cap1 = ""
        _vc_cap1 = _vc_cap1 + "\n  "
#<SPINEL_SOURCE>app/app/components/ui/button.html.erb:2
        _vc_cap1 = _vc_cap1 + ApplicationHelper.icon(icon, size: :sm, class: "fg-ink").to_s if icon
        _vc_cap1 = _vc_cap1 + "\n  <span>"
#<SPINEL_SOURCE>app/app/components/ui/button.html.erb:3
        _vc_cap1 = _vc_cap1 + ActionView::ViewHelpers.html_escape(text.to_s)
        _vc_cap1 = _vc_cap1 + "</span>\n"
#<SPINEL_SOURCE>app/app/components/ui/button.html.erb:1
        ActionView::ViewHelpers.raw(_vc_cap1)
      end.to_s)
#<SPINEL_SOURCE>app/app/components/ui/button.html.erb:4
      ActionView::ViewHelpers.raw(_buf)
    end
  end
end
