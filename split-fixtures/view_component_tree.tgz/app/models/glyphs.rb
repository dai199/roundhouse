require "pathname"
module Glyphs
  DEFAULT_OPTIONS = { "aria-hidden" => "true", "viewBox" => "0 0 24 24", "fill" => "none" }.freeze
  ROOT = Pathname.new(File.dirname(File.expand_path("../../.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs.rb", __dir__))).join("..")

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs.rb:13
  def self.default_options
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs.rb:14
    Glyphs::DEFAULT_OPTIONS
  end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs.rb:13
  def default_options
#<SPINEL_SOURCE>app/.roundhouse/source_gems/glyphs-0.1.0/lib/glyphs.rb:14
    Glyphs::DEFAULT_OPTIONS
  end
  private :default_options
end
