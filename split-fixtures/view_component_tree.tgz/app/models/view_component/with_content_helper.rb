module ViewComponent
  module WithContentHelper
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/with_content_helper.rb:5
    def with_content(value)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/with_content_helper.rb:6
      raise ViewComponent::NilWithContentError if value.nil?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/with_content_helper.rb:8
      @__vc_content_set_by_with_content = value
      @__vc_content_set_by_with_content_defined = true

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/with_content_helper.rb:10
      self
    end
  end
end
