require_relative "../action_view/base"
require_relative "inline_template"
require_relative "use_helpers"
require_relative "slotable"
require_relative "translatable"
require_relative "with_content_helper"
require_relative "../../../runtime/inflector"
require_relative "../view_component"
require_relative "compiler"
require_relative "config"

module ViewComponent
  class Base < ActionView::Base
    include ViewComponent::InlineTemplate
    include ViewComponent::UseHelpers
    include ViewComponent::Slotable
    include ViewComponent::Translatable
    include ViewComponent::WithContentHelper

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:16
    def self.i18n_backend
      if @i18n_backend__written
        @i18n_backend
      else
        superclass.i18n_backend
      end
    end

    def self.i18n_backend=(value)
      @i18n_backend__written = true
      @i18n_backend = value
    end

    def i18n_backend
      if @i18n_backend__written
        @i18n_backend
      else
        self.class.i18n_backend
      end
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:19
    def self.registered_slots
      if @registered_slots__written
        @registered_slots
      else
        superclass.registered_slots
      end
    end

    def self.registered_slots=(value)
      @registered_slots__written = true
      @registered_slots = value
    end

    def self.registered_slots?
      !(!(registered_slots))
    end

    def registered_slots
      if @registered_slots__written
        @registered_slots
      else
        self.class.registered_slots
      end
    end

    def registered_slots=(value)
      @registered_slots__written = true
      @registered_slots = value
    end

    def registered_slots?
      !(!(registered_slots))
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:9
    def self.method_missing(method, *args)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:10
      return super if !(method.end_with?("_template"))

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:12
      raise ViewComponent::MultipleInlineTemplatesError if @__vc_inline_template_defined_defined && @__vc_inline_template_defined

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:16
      raise ArgumentError, "wrong number of arguments (given #{args.size}, expected 1)" if args.size != 1

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:20
      ext = method.to_s.gsub("_template", "")
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:21
      template = args.first
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:23
      @__vc_inline_template_language = ext
      @__vc_inline_template_language_defined = true

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:25
      caller = caller_locations(1..1)[0]
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:26
      @__vc_inline_template = ViewComponent::InlineTemplate::Template.new(template, ext, caller.absolute_path || caller.path, caller.lineno)
      @__vc_inline_template_defined = true
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:33
      @__vc_inline_template_defined = true
      @__vc_inline_template_defined_defined = true
      @__vc_inline_template_defined
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:37
    def self.respond_to_missing?(method, include_all = false)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:38
      method.end_with?("_template") || super
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:41
    def self.inline_template
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:42
      @__vc_inline_template if @__vc_inline_template_defined
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:45
    def self.inline_template_language
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/inline_template.rb:46
      @__vc_inline_template_language if @__vc_inline_template_language_defined
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:7
    def self.use_helpers(*args, from: nil, prefix: false)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:8
      args.each { |helper_method| use_helper(helper_method, from: from, prefix: prefix) }
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:26
    def self.full_helper_method_name(helper_method, prefix: false, source: nil)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:27
      if !(!(prefix))
        nil
      else
        return helper_method
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:29
      if !(!(prefix)) == prefix
        "#{ActiveSupport.underscore(source.to_s)}_#{helper_method}"
      else
        "#{prefix}_#{helper_method}"
      end
    end
    private_class_method :full_helper_method_name

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:36
    def self.define_helper(helper_method:, source:)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:37
      if ActiveSupport.present?(source)
        nil
      else
        return "__vc_original_view_context.#{helper_method}(*args, &block)"
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/use_helpers.rb:39
      "#{source}.instance_method(:#{helper_method}).bind(self).call(*args, &block)"
    end
    private_class_method :define_helper

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:191
    def self.slot_type(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:192
      registered_slot = registered_slots[slot_name]
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:193
      if registered_slot
        if registered_slot[:collection]
          :collection
        else
          :single
        end
      else
        plural_slot_name = ActiveSupport::Inflector.pluralize(slot_name).to_sym
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:197
        plural_registered_slot = registered_slots[plural_slot_name]
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:198
        :collection_item if plural_registered_slot && plural_registered_slot.fetch(:collection)
      end
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:272
    def self.register_default_slots
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:273
      registered_slots.each do |slot_name, config|
        config[:default_method] = instance_methods.find { |method_name| method_name == "default_#{slot_name}".to_sym }
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:276
        registered_slots[slot_name] = config
      end
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:282
    def self.register_slot(slot_name, **kwargs)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:283
      registered_slots[slot_name] = define_slot(slot_name, **kwargs)
    end
    private_class_method :register_slot

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:309
    def self.validate_plural_slot_name(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:310
      raise ViewComponent::ReservedPluralSlotNameError.new(name, slot_name) if ViewComponent::Slotable::RESERVED_NAMES[:plural].include?(slot_name.to_sym)

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:314
      raise_if_slot_name_uncountable(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:315
      raise_if_slot_conflicts_with_call(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:316
      raise_if_slot_ends_with_question_mark(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:317
      raise_if_slot_registered(slot_name)
    end
    private_class_method :validate_plural_slot_name

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:320
    def self.validate_singular_slot_name(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:321
      raise ViewComponent::ContentSlotNameError.new(name) if slot_name.to_sym == :content

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:325
      raise ViewComponent::ReservedSingularSlotNameError.new(name, slot_name) if ViewComponent::Slotable::RESERVED_NAMES[:singular].include?(slot_name.to_sym)

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:329
      raise_if_slot_conflicts_with_call(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:330
      raise_if_slot_ends_with_question_mark(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:331
      raise_if_slot_registered(slot_name)
    end
    private_class_method :validate_singular_slot_name

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:334
    def self.raise_if_slot_registered(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:335
      raise ViewComponent::RedefinedSlotError.new(name, slot_name) if registered_slots.key?(slot_name)
    end
    private_class_method :raise_if_slot_registered

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:340
    def self.raise_if_slot_ends_with_question_mark(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:341
      raise ViewComponent::SlotPredicateNameError.new(name, slot_name) if slot_name.to_s.end_with?("?")
    end
    private_class_method :raise_if_slot_ends_with_question_mark

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:344
    def self.raise_if_slot_conflicts_with_call(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:345
      raise ViewComponent::InvalidSlotNameError, "Slot cannot start with 'call_'. Please rename #{slot_name}" if slot_name.start_with?("call_")
    end
    private_class_method :raise_if_slot_conflicts_with_call

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:350
    def self.raise_if_slot_name_uncountable(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:351
      __rh_slot_name = slot_name.to_s
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:352
      raise ViewComponent::UncountableSlotNameError.new(name, __rh_slot_name) if Inflector.pluralize_word(__rh_slot_name, nil) == ActiveSupport.singularize(__rh_slot_name)
    end
    private_class_method :raise_if_slot_name_uncountable

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:20
    def self.i18n_scope
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:21
      @i18n_scope ||= virtual_path.sub(/^\//, "").gsub(/\/_?/, ".")
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:44
    def self.i18n_key(key, scope = nil)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:45
      __rh_scope = if scope.is_a? Array
        scope.join(".")
      else
        scope
      end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:46
      __rh_key = if key.is_a?(String)
        key
      else
        key && key.to_s
      end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:47
      __rh_key_2 = if __rh_scope
        "#{__rh_scope}.#{__rh_key}"
      else
        __rh_key
      end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:48
      __rh_key = if __rh_key_2.start_with?(".")
        "#{i18n_scope}#{__rh_key_2}"
      else
        __rh_key_2
      end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:49
      __rh_key
    end

    def render_template_for(variant = nil, format = nil)
      call
    end

    def self.inherited(child)
      compile
      location = caller_locations(1, 10).to_a.reject { |l| l.base_label == "inherited" }.first
      child.identifier = if location.nil?
        nil
      else
        location.path
      end
      child.virtual_path = child.identifier.gsub(Regexp.new("(.*#{Regexp.quote(ViewComponent::Base.config.view_component_path)})|(\\.rb)"), "") if Rails.application && !(child.identifier.nil?)
      child.with_collection_parameter provided_collection_parameter
      child.registered_slots = registered_slots.clone
      super
    end

    def self.renders_one(slot_name, callable = nil)
      validate_singular_slot_name(slot_name)
      validate_plural_slot_name(ActiveSupport::Inflector.pluralize(slot_name).to_sym)
      register_slot(slot_name, collection: false, callable: callable)
    end

    def self.renders_many(slot_name, callable = nil)
      validate_plural_slot_name(slot_name)
      validate_singular_slot_name(ActiveSupport::Inflector.singularize(slot_name).to_sym)
      register_slot(slot_name, collection: true, callable: callable)
    end

    def self.define_slot(slot_name, collection:, callable:)
      slot = { collection: collection }
      if callable
        nil
      else
        return slot
      end
      if callable.is_a?(Module) && callable.method_defined?(:render_in)
        slot[:renderable] = callable
      else
        if callable.is_a?(String)
          slot[:renderable_class_name] = callable
        else
          if callable.respond_to?(:call)
            slot[:renderable_function] = slot_name
          else
            raise(InvalidSlotDefinitionError)
          end
        end
      end
      slot
    end

    def self.register_polymorphic_slot(slot_name, types, collection:)
      raise NotImplementedError, "roundhouse: polymorphic slots are not supported"
    end

    def self.use_helper(helper_method, from: nil, prefix: false)
      raise NotImplementedError, "roundhouse: use_helpers is not supported"
    end

    def __vc_call_slot_function(slot_name, *args, **kwargs, &block)
      raise(InvalidSlotDefinitionError)
    end

    def self.build_i18n_backend
      nil
    end

    def self.translate(key = nil, **options)
      raise NotImplementedError, "roundhouse: component translations are not supported"
    end

    def self.t(key = nil, **options)
      raise NotImplementedError, "roundhouse: component translations are not supported"
    end

    @i18n_backend__written = true
    @i18n_backend = nil
    @registered_slots__written = true
    @registered_slots = {}

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:22
    def capture_compatibility_patch_enabled
      config.capture_compatibility_patch_enabled
    end


    def default_preview_layout
      config.default_preview_layout
    end


    def test_controller
      config.test_controller
    end


    def preview_paths
      config.preview_paths
    end


    def show_previews
      config.show_previews
    end


    def component_parent_class
      config.component_parent_class
    end


    def view_component_path
      config.view_component_path
    end


    def render_monkey_patch_enabled
      config.render_monkey_patch_enabled
    end


    def use_deprecated_instrumentation_name
      config.use_deprecated_instrumentation_name
    end


    def instrumentation_enabled
      config.instrumentation_enabled
    end


    def show_previews_source
      config.show_previews_source
    end


    def preview_route
      config.preview_route
    end


    def preview_controller
      config.preview_controller
    end


    def generate
      config.generate
    end

    ViewComponent::Config.defaults

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:27
    def self.config
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:28
      module_parents.each do |module_parent|
        if module_parent.respond_to?(:config)
          nil
        else
          next
        end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:30
        module_parent_config = module_parent.config && module_parent.config.view_component
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:31
        return module_parent_config if module_parent_config
      end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:33
      ViewComponent::Config.current
    end

    RESERVED_PARAMETER = :content
    VC_INTERNAL_DEFAULT_FORMAT = :html

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:47
    def config
      helpers.config
    end


    def protect_against_forgery?
      helpers.protect_against_forgery?
    end


    def form_authenticity_token
      helpers.form_authenticity_token
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:50
    def content_security_policy_nonce
      helpers.content_security_policy_nonce
    end

    @__vc_strip_trailing_whitespace__written = true
    @__vc_strip_trailing_whitespace = nil

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:53
    def self.__vc_strip_trailing_whitespace
      if @__vc_strip_trailing_whitespace__written
        @__vc_strip_trailing_whitespace
      else
        superclass.__vc_strip_trailing_whitespace
      end
    end


    def self.__vc_strip_trailing_whitespace=(value)
      @__vc_strip_trailing_whitespace__written = true
      @__vc_strip_trailing_whitespace = value
    end

    self.__vc_strip_trailing_whitespace = false

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:56
    def __vc_original_view_context
      @__vc_original_view_context
    end


    def __vc_original_view_context=(value)
      @__vc_original_view_context = value
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:67
    def set_original_view_context(view_context)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:68
      self.__vc_original_view_context = view_context
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:79
    def render_in(view_context, &block)
      begin
        self.class.compile(raise_errors: true)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:82
        @view_context = view_context
        @view_context_defined = true
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:83
        self.__vc_original_view_context ||= view_context
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:85
        @output_buffer = ActionView::OutputBuffer.new
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:87
        @lookup_context ||= view_context.lookup_context
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:90
        @view_renderer ||= view_context.view_renderer
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:93
        @view_flow ||= view_context.view_flow
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:96
        @virtual_path ||= virtual_path
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:99
        @__vc_variant ||= @lookup_context.variants.first
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:102
        if defined?(@current_template)
          nil
        else
          @current_template = nil
        end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:103
        old_current_template = @current_template
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:104
        @current_template = self
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:106
        raise ViewComponent::DuplicateContentError.new(self.class.name) if block && @__vc_content_set_by_with_content_defined
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:110
        @__vc_content_evaluated = false
        @__vc_content_evaluated_defined = true
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:111
        @__vc_render_in_block = block
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:113
        before_render
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:115
        if render?
          rendered_template = render_template_for(@__vc_variant, (__safe_nav4070 = (__safe_nav4062 = __vc_request) && __safe_nav4062.format) && __safe_nav4070.to_sym).to_s
          
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:119
          if ActiveSupport.blank?(output_preamble) && ActiveSupport.blank?(output_postamble)
            rendered_template
          else
            safe_output_preamble + rendered_template + safe_output_postamble
          end
        else
          ""
        end
      ensure
        @current_template = old_current_template
      end
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:142
    def render_parent
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:143
      render_parent_to_string
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:144
      nil
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:157
    def render_parent_to_string
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:158
      @__vc_parent_render_level ||= 0

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:160
      begin
        target_render = self.class.instance_variable_get(:@__vc_ancestor_calls)[@__vc_parent_render_level]
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:162
        @__vc_parent_render_level += 1
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:164
        target_render.bind_call(self, @__vc_variant)
      ensure
        @__vc_parent_render_level -= 1
      end
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:173
    def output_preamble
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:174
      @@default_output_preamble ||= "".html_safe
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:180
    def output_postamble
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:181
      @@default_output_postamble ||= "".html_safe
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:188
    def before_render
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:195
    def render?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:196
      true
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:202
    def initialize(*__anon_rest_6568)
    end
    private :initialize


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:212
    def render(options = {}, args = {}, &block)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:213
      if options.respond_to?(:set_original_view_context)
        options.set_original_view_context(self.__vc_original_view_context)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:215
        super
      else
        __vc_original_view_context.render(options, args, &block)
      end
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:225
    def controller
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:226
      raise ViewComponent::ControllerCalledBeforeRenderError if view_context.nil?

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:228
      @__vc_controller ||= view_context.controller
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:235
    def helpers
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:236
      raise ViewComponent::HelpersCalledBeforeRenderError if view_context.nil?

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:245
      @__vc_helpers ||= __vc_original_view_context || controller.view_context
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:267
    def virtual_path
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:268
      self.class.virtual_path
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:273
    def view_cache_dependencies
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:274
      []
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:280
    def format
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:281
      @__vc_variant if defined?(@__vc_variant)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:288
    def request
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:289
      __vc_request
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:295
    def __vc_request
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:296
      @__vc_request ||= controller.request if controller.respond_to?(:request)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:302
    def content
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:303
      @__vc_content_evaluated = true
      @__vc_content_evaluated_defined = true
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:304
      return @__vc_content if @__vc_content_defined
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:306
      @__vc_content = if __vc_render_in_block_provided?
        view_context.capture(self, &@__vc_render_in_block)
      else
        @__vc_content_set_by_with_content if __vc_content_set_by_with_content_defined?
      end
      @__vc_content_defined = true
      @__vc_content
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:317
    def content?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:318
      __vc_render_in_block_provided? || __vc_content_set_by_with_content_defined?
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:323
    def view_context
      @view_context
    end
    private :view_context


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:325
    def __vc_render_in_block_provided?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:326
      @view_context_defined && @view_context && @__vc_render_in_block
    end
    private :__vc_render_in_block_provided?


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:329
    def __vc_content_set_by_with_content_defined?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:330
      @__vc_content_set_by_with_content_defined
    end
    private :__vc_content_set_by_with_content_defined?


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:333
    def content_evaluated?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:334
      @__vc_content_evaluated_defined && @__vc_content_evaluated
    end
    private :content_evaluated?


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:337
    def maybe_escape_html(text)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:338
      return text if __vc_request && !(__vc_request.format.html?)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:339
      return text if ActiveSupport.blank?(text)

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:341
      if text.html_safe?
        text
      else
        yield
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:345
        html_escape(text)
      end
    end
    private :maybe_escape_html


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:349
    def safe_output_preamble
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:350
      maybe_escape_html(output_preamble) do Kernel.warn("WARNING: The #{self.class} component was provided an HTML-unsafe preamble. The preamble will be automatically escaped, but you may want to investigate.") end
    end
    private :safe_output_preamble


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:355
    def safe_output_postamble
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:356
      maybe_escape_html(output_postamble) do Kernel.warn("WARNING: The #{self.class} component was provided an HTML-unsafe postamble. The postamble will be automatically escaped, but you may want to investigate.") end
    end
    private :safe_output_postamble


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:459
    def self.identifier
      @identifier
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:462
    def self.identifier=(value)
      @identifier = value
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:465
    def self.virtual_path
      @virtual_path
    end


    def self.virtual_path=(value)
      @virtual_path = value
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:474
    def self.sidecar_files(extensions)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:475
      if identifier
        nil
      else
        return []
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:477
      __rh_extensions = extensions.join(",")

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:480
      directory = File.dirname(identifier)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:481
      filename = File.basename(identifier, ".rb")
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:482
      component_name = ActiveSupport.underscore(ActiveSupport.demodulize(name))

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:494
      nested_component_files = if name.include?("::") && component_name != filename
        Dir["#{directory}/#{filename}/#{component_name}.*{#{__rh_extensions}}"]
      else
        []
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:502
      sidecar_files = Dir["#{directory}/#{component_name}.*{#{__rh_extensions}}"]

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:504
      sidecar_directory_files = Dir["#{directory}/#{component_name}/#{filename}.*{#{__rh_extensions}}"]

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:506
      (sidecar_files - [identifier] + sidecar_directory_files + nested_component_files).uniq
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:518
    def self.with_collection(collection, spacer_component: nil, **args)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:519
      ViewComponent::Collection.new(self, collection, spacer_component, **args)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:578
    def self.compiled?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:579
      compiler.compiled?
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:583
    def self.ensure_compiled
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:584
      if compiled?
        nil
      else
        compile
      end
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:588
    def self.compile(raise_errors: false, force: false)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:589
      compiler.compile(raise_errors: raise_errors, force: force)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:593
    def self.compiler
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:594
      @__vc_compiler ||= ViewComponent::Compiler.new(self)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:604
    def self.with_collection_parameter(parameter)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:605
      @provided_collection_parameter = parameter
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:606
      @initialize_parameters = nil
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:618
    def self.strip_trailing_whitespace(value = true)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:619
      self.__vc_strip_trailing_whitespace = value
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:625
    def self.strip_trailing_whitespace?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:626
      __vc_strip_trailing_whitespace
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:635
    def self.validate_collection_parameter!(validate_default: false)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:636
      parameter = if validate_default
        collection_parameter
      else
        provided_collection_parameter
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:638
      if parameter
        nil
      else
        return
      end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:639
      return if initialize_parameter_names.include?(parameter) || splatted_keyword_argument_present?

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:644
      raise ViewComponent::EmptyOrInvalidInitializerError.new(name, parameter) if initialize_parameters.empty?

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:648
      raise ViewComponent::MissingCollectionArgumentError.new(name, parameter)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:655
    def self.validate_initialization_parameters!
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:656
      if initialize_parameter_names.include?(ViewComponent::Base::RESERVED_PARAMETER)
        nil
      else
        return
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:658
      raise ViewComponent::ReservedParameterError.new(name, ViewComponent::Base::RESERVED_PARAMETER)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:662
    def self.collection_parameter
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:663
      provided_collection_parameter || name && ActiveSupport.underscore(ActiveSupport.demodulize(name)).chomp("_component").to_sym
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:667
    def self.collection_counter_parameter
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:668
      "#{collection_parameter}_counter".to_sym
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:672
    def self.counter_argument_present?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:673
      initialize_parameter_names.include?(collection_counter_parameter)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:677
    def self.collection_iteration_parameter
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:678
      "#{collection_parameter}_iteration".to_sym
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:682
    def self.iteration_argument_present?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:683
      initialize_parameter_names.include?(collection_iteration_parameter)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:688
    def self.splatted_keyword_argument_present?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:689
      initialize_parameters.flatten.include?(:keyrest) && !(initialize_parameters.include?([:keyrest, :**]))
    end
    private_class_method :splatted_keyword_argument_present?


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:693
    def self.initialize_parameter_names
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:694
      return attribute_names.map { |x| x.to_sym } if respond_to?(:attribute_names)

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:696
      return attribute_types.keys.map { |x| x.to_sym } if 8 <= 5 && respond_to?(:attribute_types)

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:698
      initialize_parameters.map { |x| x.last }
    end
    private_class_method :initialize_parameter_names


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:701
    def self.initialize_parameters
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:702
      @initialize_parameters ||= instance_method(:initialize).parameters
    end
    private_class_method :initialize_parameters


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:705
    def self.provided_collection_parameter
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/base.rb:706
      @provided_collection_parameter ||= nil
    end
    private_class_method :provided_collection_parameter


  end
end
