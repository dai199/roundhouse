module ViewComponent
  module Slotable
    RESERVED_NAMES = { singular: %i[content render].freeze, plural: %i[contents renders].freeze }.freeze

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:358
    def get_slot(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:359
      if content_evaluated?
        nil
      else
        content
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:361
      slot = self.class.registered_slots[slot_name]
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:362
      @__vc_set_slots ||= {}

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:364
      return @__vc_set_slots[slot_name] if @__vc_set_slots[slot_name]

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:368
      [] if slot[:collection]
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:431
    def set_polymorphic_slot(slot_name, poly_type = nil, *args, &block)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:432
      slot_definition = self.class.registered_slots[slot_name]

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:434
      raise ViewComponent::ContentAlreadySetForPolymorphicSlotError.new(slot_name) if !(slot_definition[:collection]) && defined?(@__vc_set_slots) && @__vc_set_slots[slot_name]

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:438
      poly_def = slot_definition[:renderable_hash][poly_type]

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slotable.rb:440
      set_slot(slot_name, poly_def, *args, &block)
    end

    def set_slot(slot_name, slot_definition = nil, *args, **kwargs, &block)
      slot_definition ||= self.class.registered_slots[slot_name]
      slot = Slot.new(self)
      slot.__vc_content_block = block if block
      if slot_definition[:renderable]
        slot.__vc_component_instance = slot_definition[:renderable].new(*args, **kwargs)
      else
        if slot_definition[:renderable_class_name]
          slot.__vc_component_instance = self.class.const_get(slot_definition[:renderable_class_name]).new(*args, **kwargs)
        else
          if slot_definition[:renderable_function]
            renderable_value = if block
              __vc_call_slot_function(slot_definition[:renderable_function], *args, **kwargs) do |*rargs| view_context.capture(*rargs, &block) end
            else
              __vc_call_slot_function(slot_definition[:renderable_function], *args, **kwargs)
            end
            if renderable_value.respond_to?(:render_in)
              slot.__vc_component_instance = renderable_value
            else
              slot.__vc_content = renderable_value
            end
          end
        end
      end
      @__vc_set_slots ||= {}
      if slot_definition[:collection]
        @__vc_set_slots[slot_name] ||= []
        @__vc_set_slots[slot_name].push(slot)
      else
        @__vc_set_slots[slot_name] = slot
      end
      slot
    end
  end
end
