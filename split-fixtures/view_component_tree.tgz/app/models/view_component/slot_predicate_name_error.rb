require_relative "invalid_slot_name_error"

module ViewComponent
  class SlotPredicateNameError < ViewComponent::InvalidSlotNameError
    MESSAGE = "COMPONENT declares a slot named SLOT_NAME, which ends with a question mark.\n\nThis isn't allowed because the ViewComponent framework already provides predicate methods ending in `?`.\n\nTo fix this issue, choose a different name."

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:119
    def initialize(klass_name, slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:120
      super(ViewComponent::SlotPredicateNameError::MESSAGE.gsub("COMPONENT", klass_name.to_s).gsub("SLOT_NAME", slot_name.to_s))
    end
    private :initialize
  end
end
