module ViewComponent
  class InvalidSlotNameError < StandardError
  end
end
