module ViewComponent
  class Collection
    include Enumerable

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:8
    def component
      @component
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:12
    def __vc_original_view_context
      @__vc_original_view_context
    end

    def __vc_original_view_context=(value)
      @__vc_original_view_context = value
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:14
    def set_original_view_context(view_context)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:15
      self.__vc_original_view_context = view_context
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:18
    def render_in(view_context, &block)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:19
      components.map do |component|
        component.set_original_view_context(__vc_original_view_context)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:21
        component.render_in(view_context, &block)
      end.join(rendered_spacer(view_context)).html_safe
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:25
    def components
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:26
      return @components if @components_defined

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:28
      iterator = (raise "roundhouse: constant not supported (all targets)").new(@collection.size)

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:30
      component.validate_collection_parameter!(validate_default: true)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:32
      @components = @collection.map do |item| component.new(**component_options(item, iterator)).tap do |component| iterator.iterate! end end
      @components_defined = true
      @components
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:39
    def each(&block)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:40
      components.each(&block)
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:45
    def format
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:46
      nil
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:51
    def initialize(component, object, spacer_component, **options)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:52
      @component = component
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:53
      @collection = collection_variable(object || [])
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:54
      @spacer_component = spacer_component
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:55
      @options = options
    end
    private :initialize

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:58
    def collection_variable(object)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:59
      if object.respond_to?(:to_ary)
        object.to_ary
      else
        raise ViewComponent::InvalidCollectionArgumentError
      end
    end
    private :collection_variable

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:66
    def component_options(item, iterator)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:67
      item_options = { component.collection_parameter => item }
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:68
      item_options[component.collection_counter_parameter] = iterator.index if component.counter_argument_present?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:69
      item_options[component.collection_iteration_parameter] = iterator.dup if component.iteration_argument_present?

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:71
      @options.merge(item_options)
    end
    private :component_options

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:74
    def rendered_spacer(view_context)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:75
      if @spacer_component
        @spacer_component.set_original_view_context(__vc_original_view_context)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:77
        @spacer_component.render_in(view_context)
      else
        ""
      end
    end
    private :rendered_spacer

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/collection.rb:10
    def size
      @collection.size
    end
  end
end
