require_relative "base_error"

module ViewComponent
  class NilWithContentError < ViewComponent::BaseError
    MESSAGE = "No content provided to `\#with_content` for #{self}.\n\nTo fix this issue, pass a value."
  end
end
