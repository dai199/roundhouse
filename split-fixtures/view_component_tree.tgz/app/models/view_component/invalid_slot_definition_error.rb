require_relative "base_error"

module ViewComponent
  class InvalidSlotDefinitionError < ViewComponent::BaseError
    MESSAGE = "Invalid slot definition. Please pass a class, string, or callable (that is proc, lambda, etc)"
  end
end
