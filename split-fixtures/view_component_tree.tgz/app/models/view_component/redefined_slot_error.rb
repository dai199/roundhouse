module ViewComponent
  class RedefinedSlotError < StandardError
    MESSAGE = "COMPONENT declares the SLOT_NAME slot multiple times.\n\nTo fix this issue, choose a different slot name."

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:129
    def initialize(klass_name, slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:130
      super(ViewComponent::RedefinedSlotError::MESSAGE.gsub("COMPONENT", klass_name.to_s).gsub("SLOT_NAME", slot_name.to_s))
    end
    private :initialize
  end
end
