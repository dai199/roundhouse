module ViewComponent
  module InlineTemplate
    class Template
      def source
        @source
      end

      def source=(value)
        @source = value
      end

      def language
        @language
      end

      def language=(value)
        @language = value
      end

      def path
        @path
      end

      def path=(value)
        @path = value
      end

      def lineno
        @lineno
      end

      def lineno=(value)
        @lineno = value
      end

      def initialize(source = nil, language = nil, path = nil, lineno = nil)
        @source = source
        @language = language
        @path = path
        @lineno = lineno
      end
      private :initialize
    end
  end
end
