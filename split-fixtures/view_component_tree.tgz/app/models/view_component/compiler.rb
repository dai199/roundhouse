module ViewComponent
  class Compiler
    def compile(raise_errors: false, force: false)
      if compiled? && !(force)
        nil
      else
        return if @component == ViewComponent::Base
        @component.validate_initialization_parameters! if raise_errors
        @component.register_default_slots
        @component.build_i18n_backend
        CompileCache.register(@component)
      end
    end

    @development_mode__written = true
    @development_mode = false

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compiler.rb:11
    def self.development_mode
      if @development_mode__written
        @development_mode
      else
        superclass.development_mode
      end
    end


    def self.development_mode=(value)
      @development_mode__written = true
      @development_mode = value
    end


    def self.development_mode?
      !(!(development_mode))
    end


    def development_mode
      if @development_mode__written
        @development_mode
      else
        self.class.development_mode
      end
    end


    def development_mode=(value)
      @development_mode__written = true
      @development_mode = value
    end


    def development_mode?
      !(!(development_mode))
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compiler.rb:13
    def initialize(component)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compiler.rb:14
      @component = component
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compiler.rb:15
      @lock = Mutex.new
    end
    private :initialize


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compiler.rb:18
    def compiled?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compiler.rb:19
      ViewComponent::CompileCache.compiled?(@component)
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compiler.rb:60
    def templates
      @templates
    end
    private :templates

  end
end
