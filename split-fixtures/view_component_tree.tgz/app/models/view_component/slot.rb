require_relative "with_content_helper"

module ViewComponent
  class Slot
    include ViewComponent::WithContentHelper

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:9
    def __vc_component_instance=(value)
      @__vc_component_instance = value
      @__vc_component_instance_defined = true
      @__vc_component_instance
    end

    def __vc_content_block=(value)
      @__vc_content_block = value
      @__vc_content_block_defined = true
      @__vc_content_block
    end

    def __vc_content=(value)
      @__vc_content = value
      @__vc_content_defined = true
      @__vc_content
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:11
    def initialize(parent)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:12
      @parent = parent
    end
    private :initialize

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:15
    def content?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:16
      return true if @__vc_content_defined && ActiveSupport.present?(@__vc_content)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:17
      return true if @__vc_content_set_by_with_content_defined && ActiveSupport.present?(@__vc_content_set_by_with_content)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:18
      return true if @__vc_content_block_defined && ActiveSupport.present?(@__vc_content_block)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:19
      return false if !(__vc_component_instance?)

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:21
      @__vc_component_instance.content?
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:24
    def with_content(args)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:25
      if __vc_component_instance?
        @__vc_component_instance.with_content(args)
      else
        super
      end
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:104
    def method_missing(symbol, *args, &block)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:105
      @__vc_component_instance.public_send(symbol, *args, &block)
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:109
    def html_safe?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:111
      to_s.html_safe?
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:115
    def respond_to_missing?(symbol, include_all = false)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:116
      __vc_component_instance? && @__vc_component_instance.respond_to?(symbol, include_all)
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:121
    def __vc_component_instance?
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/slot.rb:122
      @__vc_component_instance_defined
    end
    private :__vc_component_instance?

    def to_s
      return @content if @content_defined
      view_context = @parent.send(:view_context)
      raise DuplicateSlotContentError.new(self.class.name) if @__vc_content_block_defined && @__vc_content_set_by_with_content_defined
      @content = if __vc_component_instance?
        @__vc_component_instance.__vc_original_view_context = @parent.__vc_original_view_context
        if @__vc_content_block_defined
          @__vc_component_instance.render_in(view_context) do |*args| @__vc_content_block.call(*args) end
        else
          @__vc_component_instance.render_in(view_context)
        end
      else
        if @__vc_content_defined
          @__vc_content
        else
          if @__vc_content_block_defined
            view_context.capture(&@__vc_content_block)
          else
            @__vc_content_set_by_with_content if @__vc_content_set_by_with_content_defined
          end
        end
      end
      @content_defined = true
      @content = @content.to_s
      @content_defined = true
      @content
    end
  end
end
