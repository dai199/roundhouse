module ViewComponent
  class ContentSlotNameError < StandardError
    MESSAGE = "COMPONENT declares a slot named content, which is a reserved word in ViewComponent.\n\nContent passed to a ViewComponent as a block is captured and assigned to the `content` accessor without having to create an explicit slot.\n\nTo fix this issue, either use the `content` accessor directly or choose a different slot name."

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:98
    def initialize(klass_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:99
      super(ViewComponent::ContentSlotNameError::MESSAGE.gsub("COMPONENT", klass_name.to_s))
    end
    private :initialize
  end
end
