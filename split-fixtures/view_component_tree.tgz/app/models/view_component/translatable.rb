require "erb"
require_relative "../../../runtime/i18n_locale"

module ViewComponent
  module Translatable
    HTML_SAFE_TRANSLATION_KEY = /(?:_|\b)html\z/
    TRANSLATION_EXTENSIONS = %w[yml yaml].freeze

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:123
    def i18n_scope
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:124
      self.class.i18n_scope
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:129
    def html_safe_translation(translation)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:130
      if translation.respond_to?(:map)
        translation.map { |element| html_safe_translation(element) }
      else
        translation.html_safe
      end
    end
    private :html_safe_translation

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:140
    def html_escape_translation_options!(options)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:141
      options.except(*(raise "roundhouse: constant not supported (all targets)")).each do |name, value|
        next if name == :count && value.is_a?(Numeric)
        
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:144
        options[name] = ERB::Util.html_escape(value.to_s)
      end
    end
    private :html_escape_translation_options!

    def translate(key = nil, **options)
      raise NotImplementedError, "roundhouse: component translations are not supported"
    end

    def t(key = nil, **options)
      raise NotImplementedError, "roundhouse: component translations are not supported"
    end
  end
end
