module ViewComponent
  module UseHelpers
  end
end
