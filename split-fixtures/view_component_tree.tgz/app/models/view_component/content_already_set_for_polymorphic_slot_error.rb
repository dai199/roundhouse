module ViewComponent
  class ContentAlreadySetForPolymorphicSlotError < StandardError
    MESSAGE = "Content for slot SLOT_NAME has already been provided."

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:167
    def initialize(slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:168
      super(ViewComponent::ContentAlreadySetForPolymorphicSlotError::MESSAGE.gsub("SLOT_NAME", slot_name.to_s))
    end
    private :initialize
  end
end
