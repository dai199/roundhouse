module ViewComponent
  class DuplicateSlotContentError < StandardError
    MESSAGE = "It looks like a block was provided after calling `with_content` on COMPONENT, which means that ViewComponent doesn't know which content to use.\n\nTo fix this issue, use either `with_content` or a block."

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:14
    def initialize(klass_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:15
      super(ViewComponent::DuplicateSlotContentError::MESSAGE.gsub("COMPONENT", klass_name.to_s))
    end
    private :initialize
  end
end
