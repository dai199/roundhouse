require_relative "invalid_slot_name_error"

module ViewComponent
  class ReservedPluralSlotNameError < ViewComponent::InvalidSlotNameError
    MESSAGE = "COMPONENT declares a slot named SLOT_NAME, which is a reserved word in the ViewComponent framework.\n\nTo fix this issue, choose a different name."

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:149
    def initialize(klass_name, slot_name)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:150
      super(ViewComponent::ReservedPluralSlotNameError::MESSAGE.gsub("COMPONENT", klass_name.to_s).gsub("SLOT_NAME", slot_name.to_s))
    end
    private :initialize
  end
end
