require_relative "base_error"

module ViewComponent
  class HelpersCalledBeforeRenderError < ViewComponent::BaseError
    MESSAGE = "`\#helpers` can't be used before rendering as it depends on the view context that only exists once a ViewComponent is passed to the Rails render pipeline.\n\nIt's sometimes possible to fix this issue by moving code dependent on `\#helpers` to a [`\#before_render` method](https://viewcomponent.org/api.html\#before_render--void)."
  end
end
