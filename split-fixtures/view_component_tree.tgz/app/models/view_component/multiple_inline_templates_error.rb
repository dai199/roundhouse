require_relative "base_error"

module ViewComponent
  class MultipleInlineTemplatesError < ViewComponent::BaseError
    MESSAGE = "Inline templates can only be defined once per-component."
  end
end
