module ViewComponent
  class Config

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:13
    def self.defaults
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:14
      ActiveSupport::OrderedOptions.new.merge!({ generate: default_generate_options, preview_controller: "ViewComponentsController", preview_route: "/rails/view_components", show_previews_source: false, instrumentation_enabled: false, use_deprecated_instrumentation_name: true, render_monkey_patch_enabled: true, view_component_path: "app/components", component_parent_class: nil, show_previews: Rails.env.development? || Rails.env.test?, preview_paths: default_preview_paths, test_controller: "ApplicationController", default_preview_layout: nil, capture_compatibility_patch_enabled: false })
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:176
    def self.default_preview_paths
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:177
      (default_rails_preview_paths + default_rails_engines_preview_paths).uniq
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:180
    def self.default_rails_preview_paths
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:181
      if Dir.exist?("#{Rails.root}/test/components/previews")
        nil
      else
        return []
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:183
      ["#{Rails.root}/test/components/previews"]
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:186
    def self.default_rails_engines_preview_paths
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:187
      if defined?(Rails::Engine)
        nil
      else
        return []
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:189
      registered_rails_engines_with_previews.map do |descendant| "#{descendant.root}/test/components/previews" end
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:194
    def self.registered_rails_engines_with_previews
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:195
      (raise "roundhouse: constant not supported (all targets)").descendants.filter do |descendant| defined?(descendant.root) && Dir.exist?("#{descendant.root}/test/components/previews") end
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:200
    def self.default_generate_options
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:201
      options = ActiveSupport::OrderedOptions.new(false)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:202
      options.method_missing(:preview_path=, "")
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:203
      options
    end

    @current__written = true
    @current = defaults

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:213
    def self.current
      if @current__written
        @current
      else
        superclass.current
      end
    end


    def self.current=(value)
      @current__written = true
      @current = value
    end


    def current
      if @current__written
        @current
      else
        self.class.current
      end
    end


    def current=(value)
      @current__written = true
      @current = value
    end


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:215
    def initialize
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:216
      @config = self.class.defaults
    end
    private :initialize


#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/config.rb:223
    def config
      @config
    end
    private :config

  end
end
