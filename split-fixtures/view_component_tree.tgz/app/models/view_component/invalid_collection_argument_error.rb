require_relative "base_error"

module ViewComponent
  class InvalidCollectionArgumentError < ViewComponent::BaseError
    MESSAGE = "The value of the first argument passed to `with_collection` isn't a valid collection. Make sure it responds to `to_ary`."
  end
end
