module ViewComponent
  class BaseError < StandardError
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:3
    def initialize
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:4
      super(self.class::MESSAGE)
    end
    private :initialize
  end
end
