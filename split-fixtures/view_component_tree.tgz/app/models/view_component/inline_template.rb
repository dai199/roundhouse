module ViewComponent
  module InlineTemplate
  end
end
