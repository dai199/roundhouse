module ViewComponent
  class EmptyOrInvalidInitializerError < StandardError
    MESSAGE = "The COMPONENT initializer is empty or invalid. It must accept the parameter `PARAMETER` to render it as a collection.\n\nTo fix this issue, update the initializer to accept `PARAMETER`.\n\nSee [the collections docs](https://viewcomponent.org/guide/collections.html) for more information on rendering collections."

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:59
    def initialize(klass_name, parameter)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/errors.rb:60
      super(ViewComponent::EmptyOrInvalidInitializerError::MESSAGE.gsub("COMPONENT", klass_name.to_s).gsub("PARAMETER", parameter.to_s))
    end
    private :initialize
  end
end
