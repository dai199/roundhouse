module ViewComponent
  module Translatable
    class I18nBackend < I18n::Backend::Simple
      EMPTY_HASH = {}.freeze

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:69
      def initialize(i18n_scope:, load_paths:)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:70
        @i18n_scope = i18n_scope.split(".").map { |x| x.to_sym }
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:71
        @load_paths = load_paths
      end
      private :initialize

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:75
      def load_translations
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:76
        super(@load_paths)
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:79
      def scope_data(data)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:80
        @i18n_scope.reverse_each do |part| data = { part => data } end
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:83
        data
      end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:86
      def store_translations(locale, data, options = ViewComponent::Translatable::I18nBackend::EMPTY_HASH)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/translatable.rb:87
        super(locale, scope_data(data), options)
      end
    end
  end
end
