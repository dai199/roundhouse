require "set"
module ViewComponent
  module CompileCache
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:7
    def self.cache
      @cache
    end

    def self.cache=(value)
      @cache = value
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:13
    def self.register(klass)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:14
      cache << klass
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:17
    def self.compiled?(klass)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:18
      cache.include? klass
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:21
    def self.invalidate_class!(klass)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:22
      cache.delete(klass)
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:25
    def self.invalidate!
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:26
      cache.clear
    end

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:13
    def register(klass)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:14
      cache << klass
    end
    private :register

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:17
    def compiled?(klass)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:18
      cache.include? klass
    end
    private :compiled?

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:21
    def invalidate_class!(klass)
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:22
      cache.delete(klass)
    end
    private :invalidate_class!

#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:25
    def invalidate!
#<SPINEL_SOURCE>app/.roundhouse/source_gems/view_component-3.23.2/lib/view_component/compile_cache.rb:26
      cache.clear
    end
    private :invalidate!

    @cache = Set.new
  end
end
