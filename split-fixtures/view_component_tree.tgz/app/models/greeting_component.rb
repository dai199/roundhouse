require_relative "view_component/base"
require_relative "../route_helpers"
require_relative "../../runtime/inflector"

class GreetingComponent < ViewComponent::Base
  include RouteHelpers

#<SPINEL_SOURCE>app/app/components/greeting_component.rb:2
  def initialize(name:, count: 0)
#<SPINEL_SOURCE>app/app/components/greeting_component.rb:3
    @name = name
#<SPINEL_SOURCE>app/app/components/greeting_component.rb:4
    @count = count
  end
  private :initialize

#<SPINEL_SOURCE>app/app/components/greeting_component.rb:7
  def shout
    @name.upcase
  end

#<SPINEL_SOURCE>app/app/components/greeting_component.rb:9
  def render?
    @count >= 0
  end

#<SPINEL_SOURCE>app/app/components/greeting_component.html.erb:1
  def call
    _buf = +""
    _buf = _buf + "<p class=\"greeting\">Hello, "
    _buf = _buf + ActionView::ViewHelpers.html_escape(shout.to_s)
    _buf = _buf + "! ("
    _buf = _buf + ActionView::ViewHelpers.html_escape(Inflector.pluralize_formatted(@count.to_s, "article").to_s)
    _buf = _buf + ")</p>\n"
#<SPINEL_SOURCE>app/app/components/greeting_component.html.erb:2
    ActionView::ViewHelpers.raw(_buf)
  end
end
