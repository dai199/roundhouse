require_relative "view_component/base"
require_relative "../route_helpers"

class CardComponent < ViewComponent::Base
  include RouteHelpers

#<SPINEL_SOURCE>app/app/components/card_component.html.erb:1
  def call
    _buf = +""
    _buf = _buf + "<div class=\"card card-"
    _buf = _buf + ActionView::ViewHelpers.html_escape(@tone.to_s)
    _buf = _buf + "\">\n  "
#<SPINEL_SOURCE>app/app/components/card_component.html.erb:2
    if header?
      _buf = _buf + "<h2>"
      _buf = _buf + ActionView::ViewHelpers.html_escape(header.to_s)
      _buf = _buf + "</h2>"
    end
    _buf = _buf + "\n  <ul>"
#<SPINEL_SOURCE>app/app/components/card_component.html.erb:3
    items.each do |item|
      _buf = _buf + "<li>"
      _buf = _buf + ActionView::ViewHelpers.html_escape(item.to_s)
      _buf = _buf + "</li>"
    end
    _buf = _buf + "</ul>\n  <div class=\"body\">"
#<SPINEL_SOURCE>app/app/components/card_component.html.erb:4
    _buf = _buf + ActionView::ViewHelpers.html_escape(content.to_s)
    _buf = _buf + "</div>\n  "
#<SPINEL_SOURCE>app/app/components/card_component.html.erb:5
    _buf = _buf + ActionView::ViewHelpers.html_escape(footer.to_s)
    _buf = _buf + "\n</div>\n"
#<SPINEL_SOURCE>app/app/components/card_component.html.erb:7
    ActionView::ViewHelpers.raw(_buf)
  end


#<SPINEL_SOURCE>app/app/components/card_component.rb:2
  def with_header(*args, **kwargs, &block)
    set_slot(:header, nil, *args, **kwargs, &block)
  end


  def with_header_content(content)
    with_header { content.to_s }
    self
  end


  def header
    get_slot(:header)
  end


  def header?
    ActiveSupport.present?(get_slot(:header))
  end


  def with_item(*args, **kwargs, &block)
    set_slot(:items, nil, *args, **kwargs, &block)
  end


  def with_item_content(content)
    with_item { content.to_s }
    self
  end


  def with_items(collection_args = nil, &block)
    collection_args.map do |args|
      if args.respond_to?(:to_hash)
        set_slot(:items, nil, **args, &block)
      else
        set_slot(:items, nil, *args, &block)
      end
    end
  end


  def items
    get_slot(:items)
  end


  def items?
    ActiveSupport.present?(get_slot(:items))
  end


  def _call_footer(note:, &block)
    "<small>#{note}</small>".html_safe
  end


  def with_footer(*args, **kwargs, &block)
    set_slot(:footer, nil, *args, **kwargs, &block)
  end


  def with_footer_content(content)
    with_footer { content.to_s }
    self
  end


  def footer
    get_slot(:footer)
  end


  def footer?
    ActiveSupport.present?(get_slot(:footer))
  end


  def __vc_call_slot_function(slot_name, *args, **kwargs, &block)
    case slot_name
    when :footer
      _call_footer(*args, **kwargs, &block)
    else
      super
    end
  end

  renders_one :header
  renders_many :items
  renders_one :footer, -> {  }

#<SPINEL_SOURCE>app/app/components/card_component.rb:6
  def initialize(tone: "plain")
#<SPINEL_SOURCE>app/app/components/card_component.rb:7
    @tone = tone
  end
  private :initialize

end
