require_relative "../../../runtime/action_view"
require_relative "../glyphs/helper"

module ActionView
  class Base
    include Glyphs::Helper
  end
end
