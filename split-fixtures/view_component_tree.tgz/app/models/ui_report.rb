class UiReport
#<SPINEL_SOURCE>app/app/lib/ui_report.rb:2
  def self.lines
#<SPINEL_SOURCE>app/app/lib/ui_report.rb:3
    view = ActionView::Base.new
#<SPINEL_SOURCE>app/app/lib/ui_report.rb:4
    [ Ui::Button.new(text: "Save <now>", tone: :quiet).render_in(view), Ui::Button.new(text: "Add", icon: "plus", confirm: "Sure?", class: "btn").render_in(view), Ui::Link.new(text: "Home", href: "/home", icon: "minus").render_in(view), Ui::Button.new(text: "Drop", href: "/items/1", method: :delete, confirm: "Gone?").render_in(view), Ui::Strip.new(active: "a").render_in(view) do |s|
      s.with_tab(id: "a", label: "One <1>")
#<SPINEL_SOURCE>app/app/lib/ui_report.rb:11
      s.with_tab(id: "b", label: "Two") { "2 > 1" }
#<SPINEL_SOURCE>app/app/lib/ui_report.rb:12
      s.with_link(text: "Out", href: "/out", tone: :quiet)
    end, Ui::Sheet.new.render_in(view) do |p|
      p.with_header(title: "Edit <it>", note: "a and b")
#<SPINEL_SOURCE>app/app/lib/ui_report.rb:16
      p.with_tab(label: "Only")
    end ].map { |x| x.to_s }
  end
end
