require_relative "../../runtime/action_mailer"

class ApplicationMailer < ActionMailer::Base
  def default_params
    ActionMailer::Base.base_default_params.merge({ from: "from@example.com" })
  end

  def _prefixes
    ["application_mailer"]
  end
end
