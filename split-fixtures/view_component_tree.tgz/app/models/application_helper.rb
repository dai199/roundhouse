module ApplicationHelper
#<SPINEL_SOURCE>app/app/helpers/application_helper.rb:2
  def self.icon(key, size: "md", **opts)
#<SPINEL_SOURCE>app/app/helpers/application_helper.rb:3
    extra = opts.delete(:class)
#<SPINEL_SOURCE>app/app/helpers/application_helper.rb:4
    sizes = { sm: "w-4 h-4", md: "w-5 h-5" }
#<SPINEL_SOURCE>app/app/helpers/application_helper.rb:5
    ActionView::Base.new.glyph_tag(key, **{ class: ActionView::ViewHelpers.class_names("shrink-0", sizes[size.to_sym], extra) }.merge(opts))
  end
end
